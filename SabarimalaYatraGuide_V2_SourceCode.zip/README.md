# Sabarimala Yatra Guide (சபரிமலை யாத்திரை வழிகாட்டி) — Version 2.0.0

## What's Upgraded in Version 2.0.0
1. **AndroidX Media3 Audio-Only Playback (`ExoPlayer` + `MediaSessionService`)**
   - Strictly audio-only (`C.TRACK_TYPE_VIDEO` disabled), zero video playback.
   - Background playback & playback while screen is locked (`WAKE_MODE_LOCAL` + `FOREGROUND_SERVICE_MEDIA_PLAYBACK`).
   - System Android Media Notification, Lock-Screen Controls, and Bluetooth AVRCP media controls via `MediaSession` + `MediaButtonReceiver`.
   - Automatic Audio Focus management (`handleAudioFocus = true`) for incoming calls/interruptions and automatic pause on headphone/Bluetooth disconnect (`setHandleAudioBecomingNoisy(true)`).
   - Automatic playback state restoration (`onPlaybackResumption` + `YatraPreferencesStore`).
   - Full controls: Play/Pause, Next, Previous, Seek Bar, Live Duration, Shuffle, Repeat (`OFF`/`ALL`/`ONE`), Favorites, Playlists (create/delete/add/remove/play), Recently Played, Real-Time Search, Queue Management, Persistent Mini-Player, Sleep Timer, Tamil TTS Chant, and Local Audio Import (`OpenMultipleDocuments` with persistable URI permissions).
2. **Future-Ready Song Library (`assets/songs/catalog.json`)**
   - Preserves all 6 non-copyrighted devotional `.wav` tracks.
   - Drop future Ayyappan `.mp3`/`.wav`/`.m4a`/`.ogg` files into `app/src/main/assets/songs/` (and optionally add metadata/lyrics in `catalog.json`) — automatically discovered offline.
3. **Honest Updates & Alerts Framework (`TrustedUpdatesRepository`)**
   - Structured categories: Temple Announcements, Opening/Closing, Mandala/Makaravilakku, Travel, Route, Weather, Crowd, Emergency.
   - Never displays fabricated crowd levels or fake alerts; transparently shows live feed availability and links to official reference portals (`sabarimalaonline.org`, Kerala Police, IMD Kerala, KSRTC).
   - Implement `TrustedUpdatesProvider` to connect verified live APIs in future updates.
4. **Notification Framework (`YatraNotificationManager`)**
   - 5 Android Notification Channels: Temple Updates, Travel Updates, Weather Alerts, Emergency Notifications, Important Announcements.
   - Android 13+ (`POST_NOTIFICATIONS`) runtime permission handling, per-category toggles persisted natively, and zero unnecessary background polling.
5. **Upgraded Devotional UI & Accessibility**
   - 4 themes (`Temple Dark`, `Night AMOLED`, `Saffron Light`, `High Contrast`), `Normal`/`Large` text scaling, Tamil/English toggle, and low-end device optimization.
6. **JUnit 4 Unit Tests**
   - Covers `YatraPreferencesStore`, `SongLibraryRepository`, `TrustedUpdatesRepository`, and `PlaybackStateMapper`.

## Building the APK
- **GitHub Actions (No PC Required):** Push this extracted project (including `.github/workflows/build-apk.yml`) to GitHub → open **Actions** → download **`SabarimalaYatraGuide-V2-APK`**.
- **Android Studio / Local Gradle 8.7 + JDK 17:**
  ```bash
  gradle testDebugUnitTest assembleDebug
  ```
  *(Note: `gradle/wrapper/gradle-wrapper.jar` binary is intentionally omitted from this source archive; `gradlew` automatically delegates to system `gradle` if installed, or run `gradle wrapper --gradle-version 8.7` to generate the wrapper JAR.)*
