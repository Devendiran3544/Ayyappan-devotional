package com.sabarimala.yatraguide

import android.Manifest
import android.annotation.SuppressLint
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.webkit.WebViewAssetLoader
import com.google.common.util.concurrent.ListenableFuture
import com.sabarimala.yatraguide.audio.DevotionalPlaybackService
import com.sabarimala.yatraguide.audio.PlaybackStateMapper
import com.sabarimala.yatraguide.data.SongLibraryRepository
import com.sabarimala.yatraguide.data.TrustedUpdatesRepository
import com.sabarimala.yatraguide.data.YatraPreferencesStore
import com.sabarimala.yatraguide.model.AlertCategory
import com.sabarimala.yatraguide.model.NotificationCategory
import com.sabarimala.yatraguide.model.SongItem
import com.sabarimala.yatraguide.notifications.YatraNotificationManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var store: YatraPreferencesStore
    private lateinit var repository: SongLibraryRepository
    private lateinit var updatesRepository: TrustedUpdatesRepository
    private lateinit var notificationManager: YatraNotificationManager

    private var controllerFuture: ListenableFuture<MediaController>? = null
    private var mediaController: MediaController? = null
    private var artworkBytes: ByteArray? = null

    private var tts: TextToSpeech? = null
    private var ttsTamilReady: Boolean = false
    private var webPageLoaded: Boolean = false

    private val mainHandler = Handler(Looper.getMainLooper())
    private var sleepTimerRunnable: Runnable? = null
    private var sleepTimerEndEpochMs: Long = 0L

    private val progressTicker = object : Runnable {
        override fun run() {
            val ctrl = mediaController
            if (ctrl != null && ctrl.isPlaying) {
                pushPlayerStateToWeb()
                mainHandler.postDelayed(this, 500L)
            }
        }
    }

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(isPlaying: Boolean) {
            pushPlayerStateToWeb()
            mainHandler.removeCallbacks(progressTicker)
            if (isPlaying) {
                mainHandler.postDelayed(progressTicker, 500L)
            }
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            pushPlayerStateToWeb()
            pushLibraryToWeb()
        }

        override fun onPlaybackStateChanged(playbackState: Int) {
            pushPlayerStateToWeb()
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            pushPlayerStateToWeb()
        }

        override fun onRepeatModeChanged(repeatMode: Int) {
            pushPlayerStateToWeb()
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            pushPlayerStateToWeb()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { _ ->
        pushNotificationStatusToWeb()
    }

    private val localAudioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        if (uris.isEmpty()) return@registerForActivityResult
        var firstAddedId: String? = null
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {
            }
            val displayName = queryDisplayName(uri) ?: "Devotional Audio"
            val added = repository.addLocalAudio(displayName, uri.toString())
            if (firstAddedId == null) firstAddedId = added.id
        }
        pushLibraryToWeb()
        firstAddedId?.let { id ->
            playSongFromAllLibrary(id)
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        store = YatraPreferencesStore(this)
        repository = SongLibraryRepository(this, store)
        updatesRepository = TrustedUpdatesRepository()
        notificationManager = YatraNotificationManager(this, store)
        notificationManager.ensureChannelsCreated()
        artworkBytes = loadLauncherArtworkBytes()

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale("ta", "IN"))
                ttsTamilReady = (res != TextToSpeech.LANG_MISSING_DATA &&
                    res != TextToSpeech.LANG_NOT_SUPPORTED)
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                webPageLoaded = true
                pushLibraryToWeb()
                pushPlayerStateToWeb()
                pushNotificationStatusToWeb()
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme == "tel") {
                    openSafeIntent(Intent(Intent.ACTION_DIAL, uri))
                    return true
                }
                if (uri.host != "appassets.androidplatform.net") {
                    openSafeIntent(Intent(Intent.ACTION_VIEW, uri))
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = WebChromeClient()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    override fun onStart() {
        super.onStart()
        val sessionToken = SessionToken(
            this,
            ComponentName(this, DevotionalPlaybackService::class.java)
        )
        val future = MediaController.Builder(this, sessionToken).buildAsync()
        controllerFuture = future
        future.addListener({
            try {
                val controller = future.get()
                mediaController = controller
                controller.addListener(playerListener)
                ensureQueueRestoredIfEmpty(controller)
                pushPlayerStateToWeb()
                if (controller.isPlaying) {
                    mainHandler.removeCallbacks(progressTicker)
                    mainHandler.postDelayed(progressTicker, 500L)
                }
            } catch (_: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        mainHandler.removeCallbacks(progressTicker)
        mediaController?.removeListener(playerListener)
        mediaController = null
        controllerFuture?.let { MediaController.releaseFuture(it) }
        controllerFuture = null
        super.onStop()
    }

    override fun onDestroy() {
        sleepTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        mainHandler.removeCallbacks(progressTicker)
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun ensureQueueRestoredIfEmpty(controller: MediaController) {
        if (controller.mediaItemCount > 0) return
        val allSongs = repository.getAllSongs()
        if (allSongs.isEmpty()) return
        val saved = store.getPlaybackState()
        val startIndex = if (!saved.lastSongId.isNullOrBlank()) {
            allSongs.indexOfFirst { it.id == saved.lastSongId }.coerceAtLeast(0)
        } else {
            0
        }
        val expectedDuration = allSongs.getOrNull(startIndex)?.durationMs ?: 0L
        val safePos = PlaybackStateMapper.clampResumePosition(saved.lastPositionMs, expectedDuration)
        val items = allSongs.map { DevotionalPlaybackService.toMediaItem(it, artworkBytes) }
        controller.setMediaItems(items, startIndex, safePos)
        controller.prepare()
    }

    private fun playSongList(songs: List<SongItem>, startSongId: String?) {
        val controller = mediaController ?: return
        if (songs.isEmpty()) return
        val startIdx = if (!startSongId.isNullOrBlank()) {
            songs.indexOfFirst { it.id == startSongId }.coerceAtLeast(0)
        } else {
            0
        }
        val items = songs.map { DevotionalPlaybackService.toMediaItem(it, artworkBytes) }
        controller.setMediaItems(items, startIdx, 0L)
        controller.prepare()
        controller.play()
        pushPlayerStateToWeb()
    }

    private fun playSongFromAllLibrary(songId: String) {
        val controller = mediaController ?: return
        // If already in current queue, seek directly to preserve queue order
        for (i in 0 until controller.mediaItemCount) {
            if (controller.getMediaItemAt(i).mediaId == songId) {
                controller.seekTo(i, 0L)
                controller.prepare()
                controller.play()
                pushPlayerStateToWeb()
                return
            }
        }
        playSongList(repository.getAllSongs(), songId)
    }

    private fun buildPlayerStateJson(): JSONObject {
        val ctrl = mediaController
        val queueArr = JSONArray()
        var currentSongId = store.getPlaybackState().lastSongId ?: ""
        var currentIndex = -1
        var isPlaying = false
        var positionMs = 0L
        var durationMs = 0L
        var shuffleEnabled = store.getPlaybackState().shuffleEnabled
        var repeatMode = store.getPlaybackState().repeatMode

        if (ctrl != null) {
            currentSongId = ctrl.currentMediaItem?.mediaId ?: currentSongId
            currentIndex = ctrl.currentMediaItemIndex
            isPlaying = ctrl.isPlaying
            positionMs = ctrl.currentPosition.coerceAtLeast(0L)
            durationMs = if (ctrl.duration > 0L) ctrl.duration else 0L
            shuffleEnabled = ctrl.shuffleModeEnabled
            repeatMode = ctrl.repeatMode
            for (i in 0 until ctrl.mediaItemCount) {
                val item = ctrl.getMediaItemAt(i)
                queueArr.put(JSONObject().apply {
                    put("index", i)
                    put("id", item.mediaId)
                    put("title", item.mediaMetadata.title?.toString() ?: item.mediaId)
                    put("artist", item.mediaMetadata.artist?.toString() ?: "")
                })
            }
        }

        val sleepRemainingMin = if (sleepTimerEndEpochMs > System.currentTimeMillis()) {
            ((sleepTimerEndEpochMs - System.currentTimeMillis()) / 60000L + 1L).toInt()
        } else {
            0
        }

        return JSONObject().apply {
            put("connected", ctrl != null)
            put("currentSongId", currentSongId)
            put("currentQueueIndex", currentIndex)
            put("isPlaying", isPlaying)
            put("positionMs", positionMs)
            put("durationMs", durationMs)
            put("shuffleEnabled", shuffleEnabled)
            put("repeatMode", repeatMode)
            put("repeatLabel", PlaybackStateMapper.repeatModeLabel(repeatMode))
            put("sleepRemainingMin", sleepRemainingMin)
            put("queue", queueArr)
        }
    }

    private fun pushPlayerStateToWeb() {
        if (!webPageLoaded) return
        val json = buildPlayerStateJson().toString()
        val escaped = JSONObject.quote(json)
        runOnUiThread {
            webView.evaluateJavascript("window.onNativePlayerState && window.onNativePlayerState(JSON.parse($escaped));", null)
        }
    }

    private fun pushLibraryToWeb() {
        if (!webPageLoaded) return
        val json = repository.buildLibrarySnapshotJson().toString()
        val escaped = JSONObject.quote(json)
        runOnUiThread {
            webView.evaluateJavascript("window.onNativeLibraryUpdate && window.onNativeLibraryUpdate(JSON.parse($escaped));", null)
        }
    }

    private fun pushNotificationStatusToWeb() {
        if (!webPageLoaded) return
        val json = notificationManager.getStatusJson().toString()
        val escaped = JSONObject.quote(json)
        runOnUiThread {
            webView.evaluateJavascript("window.onNativeNotificationStatus && window.onNativeNotificationStatus(JSON.parse($escaped));", null)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) cursor.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun openSafeIntent(intent: Intent) {
        try {
            startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun loadLauncherArtworkBytes(): ByteArray? {
        return try {
            val drawable = ContextCompat.getDrawable(this, R.mipmap.ic_launcher) ?: return null
            val bitmap = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 90, out)
            bitmap.recycle()
            out.toByteArray()
        } catch (_: Exception) {
            null
        }
    }

    inner class AndroidBridge {

        // --- Audio Playback (Media3 MediaController) ---
        @JavascriptInterface
        fun getPlayerStateJson(): String = buildPlayerStateJson().toString()

        @JavascriptInterface
        fun playSongById(songId: String) {
            runOnUiThread { playSongFromAllLibrary(songId) }
        }

        @JavascriptInterface
        fun playFavorites(startSongId: String) {
            runOnUiThread {
                val favs = repository.getFavoriteSongs()
                playSongList(favs, startSongId.ifBlank { null })
            }
        }

        @JavascriptInterface
        fun playPlaylist(playlistId: String, startSongId: String) {
            runOnUiThread {
                val songs = repository.getSongsForPlaylist(playlistId)
                playSongList(songs, startSongId.ifBlank { null })
            }
        }

        @JavascriptInterface
        fun playQueueIndex(index: Int) {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (index in 0 until ctrl.mediaItemCount) {
                    ctrl.seekTo(index, 0L)
                    ctrl.prepare()
                    ctrl.play()
                    pushPlayerStateToWeb()
                }
            }
        }

        @JavascriptInterface
        fun togglePlayPause() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (ctrl.isPlaying) {
                    ctrl.pause()
                } else {
                    if (ctrl.mediaItemCount == 0) {
                        ensureQueueRestoredIfEmpty(ctrl)
                    }
                    ctrl.prepare()
                    ctrl.play()
                }
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun nextTrack() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (ctrl.hasNextMediaItem()) {
                    ctrl.seekToNextMediaItem()
                    ctrl.play()
                } else if (ctrl.mediaItemCount > 0) {
                    ctrl.seekTo(0, 0L)
                    ctrl.play()
                }
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun prevTrack() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (ctrl.currentPosition > 3000L) {
                    ctrl.seekTo(0L)
                } else if (ctrl.hasPreviousMediaItem()) {
                    ctrl.seekToPreviousMediaItem()
                } else if (ctrl.mediaItemCount > 0) {
                    ctrl.seekTo(ctrl.mediaItemCount - 1, 0L)
                }
                ctrl.play()
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun seekTo(positionMs: Long) {
            runOnUiThread {
                mediaController?.seekTo(positionMs.coerceAtLeast(0L))
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun toggleShuffle() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.shuffleModeEnabled = !ctrl.shuffleModeEnabled
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun cycleRepeatMode() {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.repeatMode = PlaybackStateMapper.nextRepeatMode(ctrl.repeatMode)
                pushPlayerStateToWeb()
            }
        }

        @JavascriptInterface
        fun addToQueue(songId: String): Boolean {
            val song = repository.getSongById(songId) ?: return false
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                ctrl.addMediaItem(DevotionalPlaybackService.toMediaItem(song, artworkBytes))
                pushPlayerStateToWeb()
            }
            return true
        }

        @JavascriptInterface
        fun removeFromQueue(index: Int) {
            runOnUiThread {
                val ctrl = mediaController ?: return@runOnUiThread
                if (index in 0 until ctrl.mediaItemCount && ctrl.mediaItemCount > 1) {
                    ctrl.removeMediaItem(index)
                    pushPlayerStateToWeb()
                }
            }
        }

        @JavascriptInterface
        fun setSleepTimerMinutes(minutes: Int) {
            runOnUiThread {
                sleepTimerRunnable?.let { mainHandler.removeCallbacks(it) }
                sleepTimerRunnable = null
                if (minutes <= 0) {
                    sleepTimerEndEpochMs = 0L
                } else {
                    sleepTimerEndEpochMs = System.currentTimeMillis() + minutes * 60_000L
                    val r = Runnable {
                        sleepTimerEndEpochMs = 0L
                        mediaController?.pause()
                        tts?.stop()
                        pushPlayerStateToWeb()
                    }
                    sleepTimerRunnable = r
                    mainHandler.postDelayed(r, minutes * 60_000L)
                }
                pushPlayerStateToWeb()
            }
        }

        // --- Library, Search, Favorites, Playlists, Local Files ---
        @JavascriptInterface
        fun getLibraryJson(): String = repository.buildLibrarySnapshotJson().toString()

        @JavascriptInterface
        fun searchSongsJson(query: String): String {
            val favs = store.getFavorites()
            val arr = JSONArray()
            repository.searchSongs(query).forEach {
                arr.put(it.toJson(isFavorite = favs.contains(it.id)))
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun toggleFavorite(songId: String): Boolean {
            val added = store.toggleFavorite(songId)
            pushLibraryToWeb()
            return added
        }

        @JavascriptInterface
        fun createPlaylist(name: String): Boolean {
            val created = store.createPlaylist(name) != null
            if (created) pushLibraryToWeb()
            return created
        }

        @JavascriptInterface
        fun deletePlaylist(playlistId: String): Boolean {
            val deleted = store.deletePlaylist(playlistId)
            if (deleted) pushLibraryToWeb()
            return deleted
        }

        @JavascriptInterface
        fun addSongToPlaylist(playlistId: String, songId: String): Boolean {
            val ok = store.addSongToPlaylist(playlistId, songId)
            if (ok) pushLibraryToWeb()
            return ok
        }

        @JavascriptInterface
        fun removeSongFromPlaylist(playlistId: String, songId: String): Boolean {
            val ok = store.removeSongFromPlaylist(playlistId, songId)
            if (ok) pushLibraryToWeb()
            return ok
        }

        @JavascriptInterface
        fun removeLocalSong(songId: String): Boolean {
            val ok = store.removeLocalSong(songId)
            if (ok) pushLibraryToWeb()
            return ok
        }

        @JavascriptInterface
        fun requestImportLocalSongs() {
            runOnUiThread {
                try {
                    localAudioPickerLauncher.launch(arrayOf("audio/*"))
                } catch (_: Exception) {
                }
            }
        }

        // --- Tamil Voice Chant (TTS) ---
        @JavascriptInterface
        fun speakTamil(text: String, rate: Float): Boolean {
            return try {
                tts?.setSpeechRate(rate.coerceIn(0.5f, 1.3f))
                tts?.setPitch(0.95f)
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sabarimala_tamil_chant")
                ttsTamilReady
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun stopTamil() {
            try {
                tts?.stop()
            } catch (_: Exception) {
            }
        }

        // --- Updates & Alerts Framework ---
        @JavascriptInterface
        fun getUpdatesFeedJson(categoryId: String): String {
            val category = if (categoryId.isBlank() || categoryId == "all") {
                null
            } else {
                AlertCategory.fromId(categoryId)
            }
            return updatesRepository.getUpdates(category).toJson().toString()
        }

        // --- Notification Channels & Preferences ---
        @JavascriptInterface
        fun getNotificationStatusJson(): String = notificationManager.getStatusJson().toString()

        @JavascriptInterface
        fun setNotificationCategoryEnabled(categoryId: String, enabled: Boolean) {
            val cat = NotificationCategory.fromId(categoryId) ?: return
            store.setNotificationCategoryEnabled(cat, enabled)
            pushNotificationStatusToWeb()
        }

        @JavascriptInterface
        fun requestNotificationPermission() {
            runOnUiThread {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                } else {
                    openAppNotificationSettings()
                }
            }
        }

        @JavascriptInterface
        fun openAppNotificationSettings() {
            runOnUiThread {
                val intent = Intent().apply {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        action = Settings.ACTION_APP_NOTIFICATION_SETTINGS
                        putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                    } else {
                        action = Settings.ACTION_APPLICATION_DETAILS_SETTINGS
                        data = Uri.fromParts("package", packageName, null)
                    }
                }
                openSafeIntent(intent)
            }
        }

        @JavascriptInterface
        fun sendTestNotification(categoryId: String): Boolean {
            val cat = NotificationCategory.fromId(categoryId) ?: return false
            return notificationManager.sendUserRequestedTestNotification(cat, store.getLanguage())
        }

        // --- Persistent User Preferences ---
        @JavascriptInterface
        fun getUserPrefsJson(): String = store.getUserPrefsJson().toString()

        @JavascriptInterface
        fun setLanguage(lang: String) = store.setLanguage(lang)

        @JavascriptInterface
        fun setThemeMode(theme: String) = store.setThemeMode(theme)

        @JavascriptInterface
        fun setFontScale(scale: String) = store.setFontScale(scale)

        @JavascriptInterface
        fun setJapaCount(count: Int) = store.setJapaCount(count)

        @JavascriptInterface
        fun setChecklistJson(json: String) = store.setChecklistJson(json)

        // --- System Utilities ---
        @JavascriptInterface
        fun openDialer(phone: String) {
            runOnUiThread {
                openSafeIntent(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
            }
        }

        @JavascriptInterface
        fun openMaps(url: String) {
            runOnUiThread {
                openSafeIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        }

        @JavascriptInterface
        fun openExternalUrl(url: String) {
            runOnUiThread {
                openSafeIntent(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        }

        @JavascriptInterface
        fun setKeepScreenOn(enable: Boolean) {
            runOnUiThread {
                if (enable) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }
    }
}
