package com.sabarimala.yatraguide.data

import android.content.Context
import android.content.SharedPreferences
import com.sabarimala.yatraguide.model.NotificationCategory
import com.sabarimala.yatraguide.model.Playlist
import com.sabarimala.yatraguide.model.SongItem
import org.json.JSONArray
import org.json.JSONObject

interface KeyValueStorage {
    fun getString(key: String, defaultValue: String?): String?
    fun putString(key: String, value: String)
    fun getBoolean(key: String, defaultValue: Boolean): Boolean
    fun putBoolean(key: String, value: Boolean)
    fun getInt(key: String, defaultValue: Int): Int
    fun putInt(key: String, value: Int)
    fun getLong(key: String, defaultValue: Long): Long
    fun putLong(key: String, value: Long)
}

class SharedPrefsStorage(private val prefs: SharedPreferences) : KeyValueStorage {
    override fun getString(key: String, defaultValue: String?): String? =
        prefs.getString(key, defaultValue)

    override fun putString(key: String, value: String) {
        prefs.edit().putString(key, value).apply()
    }

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean =
        prefs.getBoolean(key, defaultValue)

    override fun putBoolean(key: String, value: Boolean) {
        prefs.edit().putBoolean(key, value).apply()
    }

    override fun getInt(key: String, defaultValue: Int): Int =
        prefs.getInt(key, defaultValue)

    override fun putInt(key: String, value: Int) {
        prefs.edit().putInt(key, value).apply()
    }

    override fun getLong(key: String, defaultValue: Long): Long =
        prefs.getLong(key, defaultValue)

    override fun putLong(key: String, value: Long) {
        prefs.edit().putLong(key, value).apply()
    }
}

data class SavedPlaybackState(
    val lastSongId: String?,
    val lastPositionMs: Long,
    val shuffleEnabled: Boolean,
    val repeatMode: Int
)

class YatraPreferencesStore(private val storage: KeyValueStorage) {

    constructor(context: Context) : this(
        SharedPrefsStorage(
            context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        )
    )

    // --- Favorites ---
    fun getFavorites(): Set<String> {
        val raw = storage.getString(KEY_FAVORITES, "[]") ?: "[]"
        val out = LinkedHashSet<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val id = arr.optString(i, "").trim()
                if (id.isNotEmpty()) out.add(id)
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun toggleFavorite(songId: String): Boolean {
        val current = LinkedHashSet(getFavorites())
        val added = if (current.contains(songId)) {
            current.remove(songId)
            false
        } else {
            current.add(songId)
            true
        }
        val arr = JSONArray()
        current.forEach { arr.put(it) }
        storage.putString(KEY_FAVORITES, arr.toString())
        return added
    }

    // --- Recently Played (MRU, max 30) ---
    fun getRecentlyPlayed(): List<String> {
        val raw = storage.getString(KEY_RECENTLY_PLAYED, "[]") ?: "[]"
        val out = mutableListOf<String>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val id = arr.optString(i, "").trim()
                if (id.isNotEmpty() && !out.contains(id)) out.add(id)
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun addRecentlyPlayed(songId: String) {
        val trimmed = songId.trim()
        if (trimmed.isEmpty()) return
        val list = getRecentlyPlayed().toMutableList()
        list.remove(trimmed)
        list.add(0, trimmed)
        val capped = if (list.size > MAX_RECENT_SONGS) list.subList(0, MAX_RECENT_SONGS) else list
        val arr = JSONArray()
        capped.forEach { arr.put(it) }
        storage.putString(KEY_RECENTLY_PLAYED, arr.toString())
    }

    // --- Playlists ---
    fun getPlaylists(): List<Playlist> {
        val raw = storage.getString(KEY_PLAYLISTS, "[]") ?: "[]"
        val out = mutableListOf<Playlist>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                Playlist.fromJson(obj)?.let { out.add(it) }
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun savePlaylists(playlists: List<Playlist>) {
        val arr = JSONArray()
        playlists.forEach { arr.put(it.toJson()) }
        storage.putString(KEY_PLAYLISTS, arr.toString())
    }

    fun createPlaylist(name: String, nowMs: Long = System.currentTimeMillis()): Playlist? {
        val clean = name.trim()
        if (clean.isEmpty()) return null
        val playlists = getPlaylists().toMutableList()
        val pl = Playlist(
            id = "pl_${nowMs}_${playlists.size + 1}",
            name = clean,
            songIds = emptyList(),
            createdAt = nowMs
        )
        playlists.add(0, pl)
        savePlaylists(playlists)
        return pl
    }

    fun deletePlaylist(playlistId: String): Boolean {
        val playlists = getPlaylists().toMutableList()
        val removed = playlists.removeAll { it.id == playlistId }
        if (removed) savePlaylists(playlists)
        return removed
    }

    fun addSongToPlaylist(playlistId: String, songId: String): Boolean {
        val playlists = getPlaylists().toMutableList()
        val idx = playlists.indexOfFirst { it.id == playlistId }
        if (idx < 0) return false
        val pl = playlists[idx]
        if (pl.songIds.contains(songId)) return true
        playlists[idx] = pl.copy(songIds = pl.songIds + songId)
        savePlaylists(playlists)
        return true
    }

    fun removeSongFromPlaylist(playlistId: String, songId: String): Boolean {
        val playlists = getPlaylists().toMutableList()
        val idx = playlists.indexOfFirst { it.id == playlistId }
        if (idx < 0) return false
        val pl = playlists[idx]
        playlists[idx] = pl.copy(songIds = pl.songIds.filterNot { it == songId })
        savePlaylists(playlists)
        return true
    }

    // --- Local Imported Songs ---
    fun getLocalSongs(): List<SongItem> {
        val raw = storage.getString(KEY_LOCAL_SONGS, "[]") ?: "[]"
        val out = mutableListOf<SongItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                SongItem.fromJson(obj)?.let { out.add(it) }
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun saveLocalSongs(songs: List<SongItem>) {
        val arr = JSONArray()
        songs.forEach { arr.put(it.toJson()) }
        storage.putString(KEY_LOCAL_SONGS, arr.toString())
    }

    fun addLocalSong(song: SongItem) {
        val existing = getLocalSongs().toMutableList()
        if (existing.none { it.uriString == song.uriString }) {
            existing.add(0, song)
            saveLocalSongs(existing)
        }
    }

    fun removeLocalSong(songId: String): Boolean {
        val existing = getLocalSongs().toMutableList()
        val removed = existing.removeAll { it.id == songId }
        if (removed) {
            saveLocalSongs(existing)
            // Also clean up from playlists & favorites
            val favs = getFavorites().toMutableSet()
            if (favs.remove(songId)) {
                val arr = JSONArray()
                favs.forEach { arr.put(it) }
                storage.putString(KEY_FAVORITES, arr.toString())
            }
            val updatedPlaylists = getPlaylists().map { pl ->
                pl.copy(songIds = pl.songIds.filterNot { it == songId })
            }
            savePlaylists(updatedPlaylists)
        }
        return removed
    }

    // --- Playback State ---
    fun savePlaybackState(
        songId: String?,
        positionMs: Long,
        shuffleEnabled: Boolean,
        repeatMode: Int
    ) {
        if (!songId.isNullOrBlank()) {
            storage.putString(KEY_LAST_SONG_ID, songId)
        }
        storage.putLong(KEY_LAST_POSITION_MS, positionMs.coerceAtLeast(0L))
        storage.putBoolean(KEY_SHUFFLE_ENABLED, shuffleEnabled)
        storage.putInt(KEY_REPEAT_MODE, repeatMode)
    }

    fun getPlaybackState(): SavedPlaybackState {
        return SavedPlaybackState(
            lastSongId = storage.getString(KEY_LAST_SONG_ID, null),
            lastPositionMs = storage.getLong(KEY_LAST_POSITION_MS, 0L),
            shuffleEnabled = storage.getBoolean(KEY_SHUFFLE_ENABLED, false),
            repeatMode = storage.getInt(KEY_REPEAT_MODE, DEFAULT_REPEAT_MODE)
        )
    }

    // --- Notification Preferences ---
    fun isNotificationCategoryEnabled(category: NotificationCategory): Boolean {
        return storage.getBoolean(KEY_NOTIF_PREFIX + category.id, category.defaultEnabled)
    }

    fun setNotificationCategoryEnabled(category: NotificationCategory, enabled: Boolean) {
        storage.putBoolean(KEY_NOTIF_PREFIX + category.id, enabled)
    }

    // --- General User Preferences (Language, Theme, Font Scale, Japa, Checklist) ---
    fun getLanguage(): String = storage.getString(KEY_LANGUAGE, "ta") ?: "ta"
    fun setLanguage(lang: String) = storage.putString(KEY_LANGUAGE, lang)

    fun getThemeMode(): String = storage.getString(KEY_THEME_MODE, "temple_dark") ?: "temple_dark"
    fun setThemeMode(theme: String) = storage.putString(KEY_THEME_MODE, theme)

    fun getFontScale(): String = storage.getString(KEY_FONT_SCALE, "normal") ?: "normal"
    fun setFontScale(scale: String) = storage.putString(KEY_FONT_SCALE, scale)

    fun getJapaCount(): Int = storage.getInt(KEY_JAPA_COUNT, 0)
    fun setJapaCount(count: Int) = storage.putInt(KEY_JAPA_COUNT, count.coerceIn(0, 108))

    fun getChecklistJson(): String = storage.getString(KEY_CHECKLIST_JSON, "{}") ?: "{}"
    fun setChecklistJson(json: String) = storage.putString(KEY_CHECKLIST_JSON, json)

    fun getUserPrefsJson(): JSONObject {
        return JSONObject().apply {
            put("language", getLanguage())
            put("themeMode", getThemeMode())
            put("fontScale", getFontScale())
            put("japaCount", getJapaCount())
            put("checklistJson", getChecklistJson())
        }
    }

    companion object {
        const val PREFS_NAME = "sabarimala_yatra_v2_prefs"
        const val MAX_RECENT_SONGS = 30
        const val DEFAULT_REPEAT_MODE = 2 // Player.REPEAT_MODE_ALL

        private const val KEY_FAVORITES = "favorites_json"
        private const val KEY_RECENTLY_PLAYED = "recently_played_json"
        private const val KEY_PLAYLISTS = "playlists_json"
        private const val KEY_LOCAL_SONGS = "local_songs_json"
        private const val KEY_LAST_SONG_ID = "last_song_id"
        private const val KEY_LAST_POSITION_MS = "last_position_ms"
        private const val KEY_SHUFFLE_ENABLED = "shuffle_enabled"
        private const val KEY_REPEAT_MODE = "repeat_mode"
        private const val KEY_NOTIF_PREFIX = "notif_cat_"
        private const val KEY_LANGUAGE = "user_language"
        private const val KEY_THEME_MODE = "user_theme_mode"
        private const val KEY_FONT_SCALE = "user_font_scale"
        private const val KEY_JAPA_COUNT = "user_japa_count"
        private const val KEY_CHECKLIST_JSON = "user_checklist_json"
    }
}
