# Sabarimala Yatra Guide (சபரிமலை யாத்திரை வழிகாட்டி) — Android APK Project

## Features Included
1. **Direct Offline Tamil Ayyappan Devotional Songs Player**: 6 built-in 100% non-copyrighted Carnatic devotional `.wav` tracks + Tamil Lyrics + Native Android Tamil Voice Chant (`ta-IN` TTS) + Phone MP3 Import + Auto-detects any extra `.mp3` files you drop into `app/src/main/assets/songs/`.
2. **Sabarimala 2026–27 Details**: Mandala–Makaravilakku dates, Daily Darshan/Pooja timings, Virtual Queue info, Interactive Irumudi Checklist, 18 Holy Steps.
3. **Routes**: Pamba Chinna Pathai, Erumeli Periya Pathai, Pullumedu Forest Route, Nilakkal Parking & Shuttle.
4. **From → To Distance, Time & Way**: 24+ cities with Car/Bus time, KSRTC shuttle + trek breakdown, highway waypoints & Google Maps Navigation.
5. **Helplines & Bus Facilities**: 1-tap Call/Copy Sabarimala helplines + KSRTC, TNSTC/SETC, TGSRTC & Railway Hub bus details.

## How to Get the Installable `.apk` in 2 Minutes (Zero PC / Zero Android Studio)
1. Create a new repository on [GitHub](https://github.com/new) (e.g., `SabarimalaYatraGuide`).
2. Extract this ZIP and upload all files & folders (including the `.github` folder!) to your repository.
   - *(Optional)* Before uploading, drop any extra `.mp3` Tamil Ayyappan songs into `app/src/main/assets/songs/` — the app will automatically list and play them offline!
3. Open the **Actions** tab on GitHub → wait ~2 minutes for **Build Sabarimala Yatra Guide APK** to turn green → click **SabarimalaYatraGuide-Installable-APK** under **Artifacts** to download and install on your Android phone!
