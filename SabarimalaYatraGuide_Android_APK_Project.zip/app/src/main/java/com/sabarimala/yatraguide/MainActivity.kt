package com.sabarimala.yatraguide

import android.annotation.SuppressLint
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private val audioLock = Any()
    private var currentVolume: Float = 0.9f
    private var tts: TextToSpeech? = null
    private var ttsTamilReady: Boolean = false
    private var pendingFileCallback: ValueCallback<Array<Uri>>? = null

    private val audioPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris: List<Uri> ->
        val callback = pendingFileCallback
        pendingFileCallback = null
        if (callback != null) {
            if (uris.isNotEmpty()) {
                callback.onReceiveValue(uris.toTypedArray())
            } else {
                callback.onReceiveValue(null)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val res = tts?.setLanguage(Locale("ta", "IN"))
                ttsTamilReady = (res != TextToSpeech.LANG_MISSING_DATA &&
                    res != TextToSpeech.LANG_NOT_SUPPORTED)
            }
        }

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView = WebView(this)
        setContentView(webView)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE

        webView.addJavascriptInterface(AndroidBridge(), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? {
                return assetLoader.shouldInterceptRequest(request.url)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: WebResourceRequest
            ): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: ""
                if (scheme == "tel") {
                    startActivity(Intent(Intent.ACTION_DIAL, uri))
                    return true
                }
                if (uri.host != "appassets.androidplatform.net") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                    } catch (_: Exception) {
                    }
                    return true
                }
                return false
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                pendingFileCallback?.onReceiveValue(null)
                pendingFileCallback = filePathCallback
                return try {
                    audioPickerLauncher.launch(arrayOf("audio/*"))
                    true
                } catch (_: Exception) {
                    pendingFileCallback = null
                    false
                }
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html")
    }

    inner class AndroidBridge {

        @JavascriptInterface
        fun playAssetAudio(assetPath: String, loop: Boolean): Boolean {
            synchronized(audioLock) {
                return try {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null

                    val afd = assets.openFd(assetPath)
                    val mp = MediaPlayer()
                    mp.setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
                    )
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                    mp.isLooping = loop
                    mp.setVolume(currentVolume, currentVolume)
                    mp.prepare()
                    mp.start()
                    mediaPlayer = mp
                    true
                } catch (e: Exception) {
                    e.printStackTrace()
                    false
                }
            }
        }

        @JavascriptInterface
        fun pauseAssetAudio() {
            synchronized(audioLock) {
                try {
                    if (mediaPlayer?.isPlaying == true) {
                        mediaPlayer?.pause()
                    }
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun resumeAssetAudio() {
            synchronized(audioLock) {
                try {
                    mediaPlayer?.start()
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun stopAssetAudio() {
            synchronized(audioLock) {
                try {
                    mediaPlayer?.stop()
                    mediaPlayer?.release()
                    mediaPlayer = null
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun seekAssetAudio(ms: Int) {
            synchronized(audioLock) {
                try {
                    mediaPlayer?.seekTo(ms)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun getAudioPosition(): Int {
            synchronized(audioLock) {
                return try {
                    mediaPlayer?.currentPosition ?: 0
                } catch (_: Exception) {
                    0
                }
            }
        }

        @JavascriptInterface
        fun getAudioDuration(): Int {
            synchronized(audioLock) {
                return try {
                    mediaPlayer?.duration ?: 0
                } catch (_: Exception) {
                    0
                }
            }
        }

        @JavascriptInterface
        fun isAudioPlaying(): Boolean {
            synchronized(audioLock) {
                return try {
                    mediaPlayer?.isPlaying ?: false
                } catch (_: Exception) {
                    false
                }
            }
        }

        @JavascriptInterface
        fun setAudioVolume(vol: Float) {
            synchronized(audioLock) {
                currentVolume = vol.coerceIn(0f, 1f)
                try {
                    mediaPlayer?.setVolume(currentVolume, currentVolume)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setLooping(loop: Boolean) {
            synchronized(audioLock) {
                try {
                    mediaPlayer?.isLooping = loop
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun speakTamil(text: String, rate: Float): Boolean {
            return try {
                tts?.setSpeechRate(rate.coerceIn(0.5f, 1.3f))
                tts?.setPitch(0.95f)
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sabarimala_tamil_chant")
                ttsTamilReady
            } catch (_: Exception) {
                false
            }
        }

        @JavascriptInterface
        fun stopTamil() {
            try {
                tts?.stop()
            } catch (_: Exception) {
            }
        }

        @JavascriptInterface
        fun isTamilTtsReady(): Boolean {
            return ttsTamilReady
        }

        @JavascriptInterface
        fun listBundledSongs(): String {
            val arr = JSONArray()
            try {
                val files = assets.list("songs") ?: emptyArray()
                files.sorted().forEach { name ->
                    val lower = name.lowercase(Locale.ROOT)
                    if (lower.endsWith(".mp3") || lower.endsWith(".wav") ||
                        lower.endsWith(".ogg") || lower.endsWith(".m4a")) {
                        arr.put(name)
                    }
                }
            } catch (_: Exception) {
            }
            return arr.toString()
        }

        @JavascriptInterface
        fun openDialer(phone: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun openMaps(url: String) {
            runOnUiThread {
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
        }

        @JavascriptInterface
        fun setKeepScreenOn(enable: Boolean) {
            runOnUiThread {
                if (enable) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }
        }
    }

    override fun onDestroy() {
        synchronized(audioLock) {
            try {
                mediaPlayer?.stop()
                mediaPlayer?.release()
                mediaPlayer = null
            } catch (_: Exception) {
            }
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }
}
