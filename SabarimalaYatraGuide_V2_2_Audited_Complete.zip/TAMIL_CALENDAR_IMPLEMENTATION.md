# Tamil Calendar & Panchangam Implementation Guide

## 1. Architecture Overview
The Tamil Calendar & Panchangam module follows the exact clean layered architecture of Sabarimala Yatra Guide V2 without introducing paid APIs, API keys, or external runtime network dependencies:

```
assets/index.html (UI: Calendar Tab + Today Card)
        │  window.AndroidBridge.*
        ▼
MainActivity.kt (JavascriptInterface Bridge)
        │
        ▼
PanchangamRepository.kt (LRU Day & Month Cache + Error Handling)
   ├── YatraPreferencesStore.kt (Persists selected location ID)
   ├── AstronomicalCalculator.kt (Jean Meeus + Lahiri + NOAA Sunrise)
   ├── SabarimalaEventsCatalog.kt (Astronomical Vrathams + 2026–27 Schedule)
   └── TamilCalendarNames.kt (Bilingual Tamil/English Lookup Tables)
```

## 2. Core Capabilities Implemented
1. **Location & Timezone-Aware Local Sunrise Rule:**
   - Default location is **Sabarimala Sannidhanam** (`9.4331°N, 77.0803°E`, `Asia/Kolkata`).
   - 10 built-in locations (Sabarimala, Pamba/Nilakkal, Erumeli, Chennai, Cuddalore/Tittagudi, Madurai, Tiruchirappalli, Coimbatore, Bengaluru, New Delhi).
   - Every day's primary Tithi, Nakshatra, Yoga, and Karana is evaluated at **local apparent upper-limb sunrise** (`zenith = 90°50'`), not midnight-to-midnight.
2. **Tamil Date & 60-Year Jovian Cycle:**
   - Computes sidereal solar longitude at local sunset to apply the traditional Tamil solar ingress rule: an ingress before local sunset starts the Tamil month on that civil date; an ingress after local sunset starts it on the next civil date.
   - 60-year cycle anchored to Prabhava = Chithirai 1987 (`2026–2027 = பராபவ / Parabhava`, `2027–2028 = பிலவங்க / Pilavanga`).
3. **Complete Daily Panchangam:**
   - Tithi + Paksha (Shukla/Krishna) + exact ending time + next Tithi.
   - Nakshatra + exact ending time + next Nakshatra.
   - Yoga + exact ending time + next Yoga.
   - Karana (all 11 Karanas across 60 half-tithis) + exact ending time + next Karana.
   - Vara (Weekday), Sunrise, Sunset.
   - Rahu Kalam, Yamagandam, Gulikai (computed dynamically as weekday-specific eighths of local daylight).
   - Brahma Muhurta & Abhijit Muhurta.
4. **Sabarimala Pilgrim Guidance & Devotional Events:**
   - Automatically detects Ekadashi, Pradosham, Shukla Sashti, Sankatahara Chaturthi, Pournami, Amavasya, Masik Karthigai, Tamil Month Day 1, and **Ayyappan Uthram Star Day**.
   - Highlights Mandala Pooja season, Mandala Pooja (Dec 27, 2026), Makaravilakku season, Makara Sankranti transit (Jan 14, 2027 evening) & Thai 1 / Pongal (Jan 15, 2027), and 2026–27 monthly poojas with transparent verification labels.
5. **Offline Performance & Caching:**
   - Zero network calls required; works 100% offline in Sabarimala forest/hill zones.
   - `PanchangamRepository` maintains synchronized LRU caches (180 days / 18 months) for instantaneous month browsing on low-end Android devices.
