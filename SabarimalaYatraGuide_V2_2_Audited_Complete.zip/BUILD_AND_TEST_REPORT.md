# Build & Test Report — Sabarimala Yatra Guide V2.2.0

## 1. Environment Limitation (Honest Disclosure)
- **Available in Sandbox:** `python3`, OpenJDK 17 runtime (`/usr/bin/java`).
- **Missing in Sandbox:** `javac`, `kotlinc`, `gradle`, Android SDK (`sdkmanager`, `aapt2`, `d8`, `apksigner`).
- **Build Result:** **Gradle unit tests and `assembleDebug` could NOT execute in this sandbox, and no `.apk` binary was produced here.**

## 2. Checks Actually Executed & Passed in Sandbox
1. **Python Mirror Verification of V2.2 Astronomical Fixes:** Verified all 5 independent reference dates (0–2 min across Sunrise, Sunset, Brahma Muhurta, Abhijit, Rahu/Yama/Gulikai, Tithi, Nakshatra, Yoga), 0-min delta on Makara Sankranti 2027, 3-min delta on Mesha Sankranti 2026, and Jan 1–14 Tamil year continuity (`Parabhava`).
2. **XML Validation:** Parsed all 4 XML files (`AndroidManifest.xml`, `strings.xml`, `styles.xml`, `ic_notification_lamp.xml`) — 0 errors.
3. **Audio & Catalog Integrity:** Verified `catalog.json` + all 6 `.wav` tracks intact.
4. **Kotlin Static Sanity Checks:** Verified package names, balanced braces, and zero citation artifacts across all 26 `.kt` files (17 main + 9 test files).
5. **AndroidBridge Audit:** Confirmed 100% of `window.AndroidBridge.*` calls in `assets/index.html` match `@JavascriptInterface` methods in `MainActivity.kt`.
6. **UI Regression Check:** Verified removal of stray `initCalendarModule()` calls from `tapJapa()`/`resetJapa()` and removal of stray calendar re-renders from `onNativeNotificationStatus`.
7. **ZIP Archive Integrity:** `zipfile.ZipFile.testzip()` passed with CRC OK across all entries.

## 3. JUnit 4 Test Suites Ready for Gradle Execution (8 Suites)
1. `AstronomicalCalculatorTest.kt` (UPDATED — 6 tests: sunrise/sunset/Rahu/Yama/Gulikai, spring/winter Brahma Muhurta, Tithi/Nakshatra/Yoga/Karana, local-sunrise rule, midnight rounding rollover, DST/leap-year/polar latitudes)
2. `TamilCalendarMappingTest.kt` (UPDATED — 3 tests: Parabhava month starts, Jan 1–14 Margazhi year continuity + Makara 09:14 PM ingress, Parabhava → Pilavanga transition)
3. `PanchangamRepositoryTest.kt` (3 tests: Sabarimala default & persistence, month navigation + LRU cache, invalid date/month handling)
4. `SecurityValidatorTest.kt` (NEW — 4 tests: phone sanitization, HTTPS-only URLs, Google Maps host restriction, WebView scheme allowlist)
5. `YatraPreferencesStoreTest.kt` (4 tests)
6. `SongLibraryRepositoryTest.kt` (2 tests)
7. `TrustedUpdatesRepositoryTest.kt` (2 tests)
8. `PlaybackStateMapperTest.kt` (3 tests)

## 4. How to Run Tests & Compile Installable Debug APK
- **GitHub Actions (Automated Cloud Android Build):** Push the extracted ZIP (including `.github/workflows/build-apk.yml`) to GitHub → **Actions** tab runs `gradle testDebugUnitTest --stacktrace` and `gradle assembleDebug --stacktrace` → download **`SabarimalaYatraGuide-V2.2-APK`** (`SabarimalaYatraGuide-v2.2.0.apk`).
- **Local / Android Studio (JDK 17 + Gradle 8.7 + Android SDK 34):**
  ```bash
  gradle testDebugUnitTest assembleDebug --stacktrace
  ```
