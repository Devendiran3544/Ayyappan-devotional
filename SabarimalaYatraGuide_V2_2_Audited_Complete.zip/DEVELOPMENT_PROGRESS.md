# Development Progress — Sabarimala Yatra Guide V2.2.0

## Completed in V2.2.0 (Audit & Hardening Continuation)
- [x] Full audit of V2.1 (`AstronomicalCalculator.kt`, `SabarimalaEventsCatalog.kt`, `MainActivity.kt`, `index.html`, tests).
- [x] Fixed critical Jan 1–14 Tamil year continuity bug (Margazhi in early January stays in prior Tamil year until Chithirai 1).
- [x] Corrected Lahiri Ayanamsa Mean J2000 constant + added `T1900` solar planetary perturbations & variable aberration (Makara 2027 error reduced to 0 min; Mesha 2026 reduced from 20 min to 3 min).
- [x] Upgraded Brahma Muhurta to Vedic night-length (`Ratrimana / 15`) formula.
- [x] Fixed midnight rounding rollover consistency and DST-safe day boundaries; added explicit UTC Gregorian helpers and polar-latitude disclosure flag.
- [x] Updated `SabarimalaEventsCatalog.kt` with verified 2026–Jan 2027 monthly pooja & festival dates and removed unverified post-Jan-2027 guesses.
- [x] Hardened WebView & `AndroidBridge` via testable `util/SecurityValidator.kt` + crash-resilience handlers (`onReceivedError`, `onRenderProcessGone`, API 26+ Safe Browsing).
- [x] Fixed UI performance & state bugs in `assets/index.html` (Japa counter calendar rebuild, notification callback re-render, Today card language/midnight rollover).
- [x] Expanded JUnit 4 unit test coverage to 8 suites (27 test methods).
- [x] Updated `AUDIT_REPORT.md`, `PANCHANGAM_VALIDATION.md`, `BUILD_AND_TEST_REPORT.md`, `README.md`, and `.github/workflows/build-apk.yml`.

## Pending (Requires Android SDK / Gradle Environment)
- [ ] Run `gradle testDebugUnitTest assembleDebug` via GitHub Actions or local Android Studio to execute all 8 JUnit 4 suites and package `SabarimalaYatraGuide-v2.2.0.apk`.
- [ ] Install and smoke-test `SabarimalaYatraGuide-v2.2.0.apk` on a physical Android device.
