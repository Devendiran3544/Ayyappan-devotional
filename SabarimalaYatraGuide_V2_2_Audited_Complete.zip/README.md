# Sabarimala Yatra Guide (சபரிமலை யாத்திரை வழிகாட்டி) — Version 2.2.0

## What's New in V2.2.0 (Audited & Hardened)
- **Audited Astronomical Engine (`AstronomicalCalculator.kt`):** Fixed Jan 1–14 Tamil year continuity, calibrated ICRC/Swiss Ephemeris Lahiri Ayanamsa + `T1900` solar perturbations (0 min Makara 2027 delta, 0–2 min lunar transitions), Vedic `Ratrimana/15` Brahma Muhurta, midnight rollover consistency, DST-safe day boundaries, and polar-latitude disclosures.
- **Verified 2026–Jan 2027 Sabarimala Calendar (`SabarimalaEventsCatalog.kt`):** Complete published 2026 monthly poojas, Panguni Uthram, Vishu, Onam, Thanka Anki, Mandala Pooja, Erumeli Petta Thullal, Thiruvabharanam, Pamba Vilakku, Makaravilakku & Thai 1 — with zero unverified post-Jan-2027 guesses.
- **Hardened WebView & Bridge (`MainActivity.kt`, `util/SecurityValidator.kt`):** Strict HTTPS/Maps/phone sanitization, API 26+ Safe Browsing, `allowContentAccess = false`, crash recovery, and UI performance bug fixes.
- **8 JUnit 4 Test Suites (27 Tests):** Covers astronomy, Tamil calendar mapping, caching, security validation, preferences, song library, updates, and playback state.
- **All Existing V2 Features Preserved:** Media3 audio-only background player, 6 offline devotional tracks, playlists/favorites/queue/search/local MP3 import, Tamil TTS chant, 5 notification channels, honest updates framework, pilgrimage guide, travel/distance calculator, SOS helplines, and 4 accessible themes.

## Build Installable Debug APK
- **GitHub Actions:** Push extracted ZIP (including `.github/workflows/build-apk.yml`) → **Actions** tab → download **`SabarimalaYatraGuide-V2.2-APK`** (`SabarimalaYatraGuide-v2.2.0.apk`).
- **Local / Android Studio (JDK 17 + Gradle 8.7 + Android SDK 34):**
  ```bash
  gradle testDebugUnitTest assembleDebug --stacktrace
  ```
