# Baseline Project Analysis — Sabarimala Yatra Guide V2

## 1. Inspected Source Archive
- **Source File:** `SabarimalaYatraGuide_V2_SourceCode.zip` (48 files, 5.80 MB compressed)
- **Application ID / Namespace:** `com.sabarimala.yatraguide`
- **Baseline Version:** `versionCode = 2`, `versionName = "2.0.0"`

## 2. Build System & SDK Configuration
- **Gradle:** 8.7 (`gradle/wrapper/gradle-wrapper.properties`, `gradlew`, `gradlew.bat`)
- **Android Gradle Plugin:** `8.5.2`
- **Kotlin:** `1.9.24` (JVM target 17)
- **SDK Levels:** `minSdk = 24`, `compileSdk = 34`, `targetSdk = 34`
- **Dependencies:**
  - `androidx.core:core-ktx:1.13.1`
  - `androidx.activity:activity-ktx:1.9.1`
  - `androidx.appcompat:appcompat:1.7.0`
  - `androidx.webkit:webkit:1.11.0`
  - `androidx.media3:media3-exoplayer:1.4.1`, `media3-session:1.4.1`, `media3-common:1.4.1`
  - `com.google.guava:guava:32.1.3-android`
  - Test: `junit:junit:4.13.2`, `org.json:json:20240303`

## 3. Architecture & Package Structure (Pre-Modification)
- **Presentation Layer:** Single-activity hybrid Android app (`MainActivity.kt`) hosting an offline `WebViewAssetLoader` UI (`app/src/main/assets/index.html`) bridged to native Kotlin services via `@JavascriptInterface` (`AndroidBridge`).
- **Audio Layer (`audio/`):** `DevotionalPlaybackService.kt` (Media3 `MediaSessionService` + audio-only `ExoPlayer`, lock-screen/Bluetooth controls, audio focus, noisy-audio pause) and `PlaybackStateMapper.kt`.
- **Data Layer (`data/`):** `YatraPreferencesStore.kt` (SharedPreferences-backed `KeyValueStorage`), `SongLibraryRepository.kt` (6 bundled non-copyrighted `.wav` tracks + `catalog.json` + local audio import), `TrustedUpdatesRepository.kt` (honest offline updates framework).
- **Notifications (`notifications/`):** `YatraNotificationManager.kt` (5 Android channels + Android 13+ `POST_NOTIFICATIONS` permission handling).
- **Models (`model/`):** `SongItem.kt`, `Playlist.kt`, `NotificationCategory.kt`, `UpdateAlertModels.kt`.
- **Existing Tests (`app/src/test/`):** 4 JUnit 4 suites (`YatraPreferencesStoreTest`, `SongLibraryRepositoryTest`, `TrustedUpdatesRepositoryTest`, `PlaybackStateMapperTest`).

## 4. Existing Tamil Calendar / Panchangam Audit
- **Finding:** No Tamil Calendar or Panchangam module existed in the V2.0.0 baseline. The Guide tab contained only static season date highlights (Mandala/Makaravilakku) and daily temple pooja timings.
- **Preservation Strategy:** Keep all existing Media3 audio, song library, playlists, notifications, updates framework, Sabarimala pilgrimage guide, distance/bus calculator, SOS helplines, 4 visual themes, and accessibility settings completely intact, and integrate the Tamil Calendar & Panchangam as a clean, modular `com.sabarimala.yatraguide.panchangam` package + native tab.
