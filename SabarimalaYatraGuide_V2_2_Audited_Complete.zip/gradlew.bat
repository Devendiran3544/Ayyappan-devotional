@rem Gradle startup script for Windows (Sabarimala Yatra Guide V2)
@if "%DEBUG%"=="" @echo off
setlocal
set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%

if not exist "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" (
    where gradle >nul 2>nul
    if %ERRORLEVEL%==0 (
        gradle %*
        exit /b %ERRORLEVEL%
    ) else (
        echo ERROR: gradle\wrapper\gradle-wrapper.jar is missing and system gradle is not in PATH.
        echo Run "gradle wrapper --gradle-version 8.7" or open in Android Studio.
        exit /b 1
    )
)

set JAVA_EXE=java.exe
if defined JAVA_HOME set JAVA_EXE=%JAVA_HOME%\bin\java.exe
"%JAVA_EXE%" -Xmx2048m -Dfile.encoding=UTF-8 -classpath "%APP_HOME%gradle\wrapper\gradle-wrapper.jar" org.gradle.wrapper.GradleWrapperMain %*
endlocal
