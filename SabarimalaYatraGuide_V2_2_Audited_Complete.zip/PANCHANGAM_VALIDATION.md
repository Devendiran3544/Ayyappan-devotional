# Panchangam Accuracy & Cross-Validation Report (Audited V2.2)

## 1. Astronomical Model (V2.2)
- **Solar Longitude:** Jean Meeus Ch. 25 + 5 Newcomb/Meeus `T1900` Venus/Jupiter/Moon perturbation terms + variable aberration (`-20.4898" / R`) + Ch. 22 nutation.
- **Lunar Longitude:** Jean Meeus Ch. 47 (60-term ELP-2000 periodic series + eccentricity & additive terms + nutation).
- **Ayanamsa:** ICRC / Swiss Ephemeris Chitra Paksha Lahiri (`Mean J2000.0 = 23°51'39.46"`, precession `5029.0966"*T + 1.11113"*T²`, plus nutation).
- **Sunrise / Sunset:** NOAA upper-limb apparent sunrise/sunset (`zenith = 90°50'`).
- **Muhurtas & Kalam:** Rahu Kalam, Yamagandam, Gulikai = weekday eighths of local daylight; Abhijit = daylight midpoint ± `daylight/30`; Brahma Muhurta = 14th muhurta of previous night (`Ratrimana / 15`).

## 2. Independent 5-Date Cross-Verification Results
Numerically verified by executing the exact V2.2 formulas against published Drik Panchang and AstroMata (Swiss Ephemeris Lahiri) tables:

| Date & Location | Sunrise / Sunset (Ref → V2.2) | Brahma Muhurta (Ref → V2.2) | Abhijit (Ref → V2.2) | Tithi End (Ref → V2.2) | Nakshatra End (Ref → V2.2) | Yoga End (Ref → V2.2) |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **2026-04-14, New Delhi** (Drik) | 05:57 / 18:46 → **05:57 / 18:46** | 04:27–05:12 → **04:28–05:12** | 11:56–12:47 → **11:56–12:47** | Kr. Dwadashi 12:12 AM (+1d) → **12:13 AM (+1d)** | Shatabhisha 04:06 PM → **04:07 PM** | Shukla 03:40 PM → **03:40 PM** |
| **2026-10-24, Bengaluru** (AstroMata) | 06:11 / 17:56 → **06:11 / 17:56** | 04:33–05:22 → **04:33–05:22** | 11:40–12:27 → **11:40–12:27** | Sh. Trayodashi 01:36 PM → **01:37 PM** | U. Bhadrapada 08:32 PM → **08:33 PM** | Vyaghata 08:01 PM → **08:02 PM** |
| **2026-11-28, New Delhi** (Drik) | 06:54 / 17:24 → **06:54 / 17:24** | 05:06–06:00 → **05:06–06:00** | 11:48–12:30 → **11:48–12:30** | Kr. Panchami 03:56 AM (+1d) → **03:57 AM (+1d)** | Punarvasu 12:50 PM → **12:51 PM** | Shukla 08:18 PM → **08:18 PM** |
| **2026-12-27, New Delhi** (Drik) | 07:12 / 17:32 → **07:12 / 17:32** | 05:23–06:18 → **05:23–06:17** | 12:02–12:43 → **12:01–12:43** | Kr. Chaturthi 05:12 PM → **05:14 PM** | Ashlesha 06:04 PM → **06:05 PM** | Vishkambha 08:53 PM → **08:54 PM** |
| **2027-01-14, New Delhi** (Drik) | 07:15 / 17:45 → **07:15 / 17:45** | 05:27–06:21 → **05:27–06:21** | 12:09–12:51 → **12:09–12:51** | Sh. Shashthi 01:58 PM → **01:59 PM** | U. Bhadrapada 11:18 PM → **11:19 PM** | Parigha 05:22 PM → **05:23 PM** |

### Solar Ingresses & Tamil Calendar Year Continuity
- **Mesha Sankranti (2026-04-14):** Drik `09:39 AM IST` → V2.2 **`09:36 AM IST`** (3 min delta; Tamil Day 1 = Apr 14, Parabhava Year).
- **Makara Sankranti (2027-01-14):** Drik `09:14 PM IST` → V2.2 **`09:14 PM IST`** (**0 min delta**; post-sunset ingress → Thai 1 = Jan 15, 2027).
- **Jan 1–14, 2027 Continuity:** Verified `2027-01-01` = **Parabhava, Margazhi 17** and `2027-01-14` = **Parabhava, Margazhi 30** (fixing V2.1 Bug #1).
