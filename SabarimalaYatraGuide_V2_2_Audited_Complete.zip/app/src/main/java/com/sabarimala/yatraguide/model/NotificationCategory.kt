package com.sabarimala.yatraguide.model

import org.json.JSONObject

enum class NotificationCategory(
    val id: String,
    val channelId: String,
    val titleTa: String,
    val titleEn: String,
    val descriptionTa: String,
    val descriptionEn: String,
    val highPriority: Boolean,
    val defaultEnabled: Boolean
) {
    TEMPLE_UPDATES(
        id = "temple_updates",
        channelId = "sabarimala_temple_updates",
        titleTa = "கோவில் & தரிசன அறிவிப்புகள்",
        titleEn = "Temple Updates",
        descriptionTa = "நடை திறப்பு, அடைப்பு, மண்டல மற்றும் மகரவிளக்கு கால அட்டவணை அறிவிப்புகள்",
        descriptionEn = "Temple opening, closing, Mandala and Makaravilakku schedule updates",
        highPriority = false,
        defaultEnabled = true
    ),
    TRAVEL_UPDATES(
        id = "travel_updates",
        channelId = "sabarimala_travel_updates",
        titleTa = "பயண & பாதை அறிவிப்புகள்",
        titleEn = "Travel Updates",
        descriptionTa = "நிலக்கல் பார்க்கிங், பம்பை KSRTC ஷட்டில் மற்றும் யாத்திரை பாதை தகவல்கள்",
        descriptionEn = "Nilakkal parking, Pamba KSRTC shuttle and pilgrimage route updates",
        highPriority = false,
        defaultEnabled = true
    ),
    WEATHER_ALERTS(
        id = "weather_alerts",
        channelId = "sabarimala_weather_alerts",
        titleTa = "வானிலை எச்சரிக்கைகள்",
        titleEn = "Weather Alerts",
        descriptionTa = "சபரிமலை மற்றும் பத்தனம்திட்டா மலைப்பகுதி மழை / வானிலை எச்சரிக்கைகள்",
        descriptionEn = "Heavy rain, fog and hill weather advisories for Sabarimala region",
        highPriority = true,
        defaultEnabled = true
    ),
    EMERGENCY_NOTIFICATIONS(
        id = "emergency_notifications",
        channelId = "sabarimala_emergency_notifications",
        titleTa = "அவசர பாதுகாப்பு அறிவிப்புகள்",
        titleEn = "Emergency Notifications",
        descriptionTa = "முக்கிய பாதுகாப்பு மற்றும் அவசரகால யாத்திரை எச்சரிக்கைகள்",
        descriptionEn = "Critical safety and emergency pilgrimage notifications",
        highPriority = true,
        defaultEnabled = true
    ),
    IMPORTANT_ANNOUNCEMENTS(
        id = "important_announcements",
        channelId = "sabarimala_important_announcements",
        titleTa = "முக்கிய அறிவிப்புகள்",
        titleEn = "Important Announcements",
        descriptionTa = "Virtual Queue மற்றும் தேவசம் போர்டு முக்கிய அறிவிப்புகள்",
        descriptionEn = "Verified Virtual Queue and Devaswom Board announcements",
        highPriority = false,
        defaultEnabled = true
    );

    fun toJson(enabled: Boolean): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("channelId", channelId)
            put("titleTa", titleTa)
            put("titleEn", titleEn)
            put("descriptionTa", descriptionTa)
            put("descriptionEn", descriptionEn)
            put("highPriority", highPriority)
            put("enabled", enabled)
        }
    }

    companion object {
        fun fromId(id: String?): NotificationCategory? {
            return values().firstOrNull { it.id == id }
        }
    }
}
