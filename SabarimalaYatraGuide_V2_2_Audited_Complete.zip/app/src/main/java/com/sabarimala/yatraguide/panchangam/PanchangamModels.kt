package com.sabarimala.yatraguide.panchangam

import org.json.JSONArray
import org.json.JSONObject

data class PanchangamLocation(
    val id: String,
    val nameTa: String,
    val nameEn: String,
    val latitude: Double,
    val longitude: Double,
    val timeZoneId: String,
    val isDefaultPilgrimageSite: Boolean = false
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("nameTa", nameTa)
        put("nameEn", nameEn)
        put("latitude", latitude)
        put("longitude", longitude)
        put("timeZoneId", timeZoneId)
        put("isDefaultPilgrimageSite", isDefaultPilgrimageSite)
    }

    companion object {
        val SABARIMALA = PanchangamLocation(
            id = "sabarimala",
            nameTa = "சபரிமலை சந்நிதானம் (முதன்மை)",
            nameEn = "Sabarimala Sannidhanam (Default)",
            latitude = 9.4331,
            longitude = 77.0803,
            timeZoneId = "Asia/Kolkata",
            isDefaultPilgrimageSite = true
        )

        val PRESET_LOCATIONS: List<PanchangamLocation> = listOf(
            SABARIMALA,
            PanchangamLocation("pamba", "பம்பை & நிலக்கல்", "Pamba & Nilakkal", 9.4139, 77.0689, "Asia/Kolkata"),
            PanchangamLocation("erumeli", "எருமேலி", "Erumeli", 9.4831, 76.8461, "Asia/Kolkata"),
            PanchangamLocation("chennai", "சென்னை", "Chennai", 13.0827, 80.2707, "Asia/Kolkata"),
            PanchangamLocation("cuddalore", "கடலூர் / திட்டக்குடி", "Cuddalore / Tittagudi", 11.4167, 79.1167, "Asia/Kolkata"),
            PanchangamLocation("madurai", "மதுரை", "Madurai", 9.9252, 78.1198, "Asia/Kolkata"),
            PanchangamLocation("trichy", "திருச்சி", "Tiruchirappalli", 10.7905, 78.7047, "Asia/Kolkata"),
            PanchangamLocation("coimbatore", "கோயம்புத்தூர்", "Coimbatore", 11.0168, 76.9558, "Asia/Kolkata"),
            PanchangamLocation("bengaluru", "பெங்களூரு", "Bengaluru", 12.9716, 77.5946, "Asia/Kolkata"),
            PanchangamLocation("new_delhi", "புதுடெல்லி", "New Delhi", 28.6139, 77.2090, "Asia/Kolkata")
        )

        fun byId(id: String?): PanchangamLocation {
            return PRESET_LOCATIONS.firstOrNull { it.id == id } ?: SABARIMALA
        }
    }
}

data class AngamSpan(
    val index: Int,
    val nameTa: String,
    val nameEn: String,
    val endTimeFormatted: String,
    val endsNextDay: Boolean,
    val nextNameTa: String,
    val nextNameEn: String,
    val extraTa: String = "",
    val extraEn: String = ""
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("index", index)
        put("nameTa", nameTa)
        put("nameEn", nameEn)
        put("endTimeFormatted", endTimeFormatted)
        put("endsNextDay", endsNextDay)
        put("nextNameTa", nextNameTa)
        put("nextNameEn", nextNameEn)
        put("extraTa", extraTa)
        put("extraEn", extraEn)
    }
}

data class TimeWindow(
    val startFormatted: String,
    val endFormatted: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("start", startFormatted)
        put("end", endFormatted)
        put("range", "$startFormatted – $endFormatted")
    }
}

data class TamilDateInfo(
    val tamilYearTa: String,
    val tamilYearEn: String,
    val tamilMonthIndex: Int, // 0..11
    val tamilMonthTa: String,
    val tamilMonthEn: String,
    val tamilDay: Int, // 1..32
    val sankrantiTodayFormatted: String? = null
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("tamilYearTa", tamilYearTa)
        put("tamilYearEn", tamilYearEn)
        put("tamilMonthIndex", tamilMonthIndex)
        put("tamilMonthTa", tamilMonthTa)
        put("tamilMonthEn", tamilMonthEn)
        put("tamilDay", tamilDay)
        put("formattedTa", "$tamilYearTa வருடம், $tamilMonthTa $tamilDay")
        put("formattedEn", "$tamilYearEn Year, $tamilMonthEn $tamilDay")
        put("sankrantiTodayFormatted", sankrantiTodayFormatted ?: JSONObject.NULL)
    }
}

enum class EventCategory {
    SABARIMALA_SEASON,
    MONTHLY_POOJA,
    FASTING_VRATHAM,
    FESTIVAL
}

enum class VerificationStatus {
    VERIFIED_ASTRONOMICAL,
    VERIFIED_PUBLISHED_CALENDAR,
    TENTATIVE_CONFIRM_TDB
}

data class PilgrimDayEvent(
    val id: String,
    val titleTa: String,
    val titleEn: String,
    val detailTa: String,
    val detailEn: String,
    val category: EventCategory,
    val verificationStatus: VerificationStatus,
    val sourceNote: String
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("titleTa", titleTa)
        put("titleEn", titleEn)
        put("detailTa", detailTa)
        put("detailEn", detailEn)
        put("category", category.name)
        put("verificationStatus", verificationStatus.name)
        put("sourceNote", sourceNote)
    }
}

data class DailyPanchangam(
    val gregorianYear: Int,
    val gregorianMonth: Int,
    val gregorianDay: Int,
    val isoDate: String,
    val dayOfWeekIndex: Int, // 0=Sun..6=Sat
    val varaTa: String,
    val varaEn: String,
    val location: PanchangamLocation,
    val timezoneOffsetLabel: String,
    val tamilDate: TamilDateInfo,
    val sunriseFormatted: String,
    val sunsetFormatted: String,
    val tithi: AngamSpan,
    val pakshaTa: String,
    val pakshaEn: String,
    val nakshatra: AngamSpan,
    val yoga: AngamSpan,
    val karana: AngamSpan,
    val rahuKalam: TimeWindow,
    val yamagandam: TimeWindow,
    val gulikai: TimeWindow,
    val brahmaMuhurta: TimeWindow,
    val abhijitMuhurta: TimeWindow,
    val pilgrimGuidanceTa: String,
    val pilgrimGuidanceEn: String,
    val events: List<PilgrimDayEvent>,
    val calculationMethodNoteTa: String,
    val calculationMethodNoteEn: String,
    val isPolarFallback: Boolean = false
) {
    fun toJson(): JSONObject {
        val eventsArr = JSONArray()
        events.forEach { eventsArr.put(it.toJson()) }
        return JSONObject().apply {
            put("ok", true)
            put("year", gregorianYear)
            put("month", gregorianMonth)
            put("day", gregorianDay)
            put("isoDate", isoDate)
            put("dayOfWeekIndex", dayOfWeekIndex)
            put("varaTa", varaTa)
            put("varaEn", varaEn)
            put("location", location.toJson())
            put("timezoneOffsetLabel", timezoneOffsetLabel)
            put("tamilDate", tamilDate.toJson())
            put("sunrise", sunriseFormatted)
            put("sunset", sunsetFormatted)
            put("tithi", tithi.toJson())
            put("pakshaTa", pakshaTa)
            put("pakshaEn", pakshaEn)
            put("nakshatra", nakshatra.toJson())
            put("yoga", yoga.toJson())
            put("karana", karana.toJson())
            put("rahuKalam", rahuKalam.toJson())
            put("yamagandam", yamagandam.toJson())
            put("gulikai", gulikai.toJson())
            put("brahmaMuhurta", brahmaMuhurta.toJson())
            put("abhijitMuhurta", abhijitMuhurta.toJson())
            put("pilgrimGuidanceTa", pilgrimGuidanceTa)
            put("pilgrimGuidanceEn", pilgrimGuidanceEn)
            put("events", eventsArr)
            put("calculationMethodNoteTa", calculationMethodNoteTa)
            put("calculationMethodNoteEn", calculationMethodNoteEn)
            put("isPolarFallback", isPolarFallback)
        }
    }
}

data class CalendarDayCell(
    val year: Int,
    val month: Int,
    val day: Int,
    val isoDate: String,
    val tamilDay: Int,
    val tamilMonthTa: String,
    val tamilMonthEn: String,
    val tithiShortTa: String,
    val tithiShortEn: String,
    val isSabarimalaOpen: Boolean,
    val hasFastingDay: Boolean,
    val hasMajorFestival: Boolean,
    val isPournami: Boolean,
    val isAmavasya: Boolean
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("year", year)
        put("month", month)
        put("day", day)
        put("isoDate", isoDate)
        put("tamilDay", tamilDay)
        put("tamilMonthTa", tamilMonthTa)
        put("tamilMonthEn", tamilMonthEn)
        put("tithiShortTa", tithiShortTa)
        put("tithiShortEn", tithiShortEn)
        put("isSabarimalaOpen", isSabarimalaOpen)
        put("hasFastingDay", hasFastingDay)
        put("hasMajorFestival", hasMajorFestival)
        put("isPournami", isPournami)
        put("isAmavasya", isAmavasya)
    }
}

data class MonthCalendarGrid(
    val year: Int,
    val month: Int,
    val firstDayOfWeek: Int, // 0=Sun..6=Sat
    val daysInMonth: Int,
    val tamilHeaderTa: String,
    val tamilHeaderEn: String,
    val location: PanchangamLocation,
    val days: List<CalendarDayCell>,
    val monthHighlights: List<Pair<String, PilgrimDayEvent>>
) {
    fun toJson(): JSONObject {
        val daysArr = JSONArray()
        days.forEach { daysArr.put(it.toJson()) }
        val hlArr = JSONArray()
        monthHighlights.forEach { (iso, ev) ->
            hlArr.put(ev.toJson().apply { put("isoDate", iso) })
        }
        return JSONObject().apply {
            put("ok", true)
            put("year", year)
            put("month", month)
            put("firstDayOfWeek", firstDayOfWeek)
            put("daysInMonth", daysInMonth)
            put("tamilHeaderTa", tamilHeaderTa)
            put("tamilHeaderEn", tamilHeaderEn)
            put("location", location.toJson())
            put("days", daysArr)
            put("monthHighlights", hlArr)
        }
    }
}
