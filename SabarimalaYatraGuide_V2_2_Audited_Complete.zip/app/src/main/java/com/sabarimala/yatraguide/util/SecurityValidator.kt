package com.sabarimala.yatraguide.util

import java.net.URI
import java.util.Locale

object SecurityValidator {

    private val ALLOWED_MAPS_HOSTS = setOf(
        "www.google.com",
        "google.com",
        "maps.google.com",
        "maps.app.goo.gl"
    )

    private val PHONE_CLEAN_REGEX = Regex("[^0-9+*#-]")

    fun sanitizePhoneNumber(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        val cleaned = raw.replace(PHONE_CLEAN_REGEX, "")
        return if (cleaned.any { it.isDigit() }) cleaned else null
    }

    fun isSafeHttpsUrl(rawUrl: String?): Boolean {
        if (rawUrl.isNullOrBlank()) return false
        return try {
            val uri = URI(rawUrl.trim())
            val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return false
            val host = uri.host?.lowercase(Locale.ROOT) ?: return false
            scheme == "https" && host.isNotBlank()
        } catch (_: Exception) {
            false
        }
    }

    fun isSafeMapsUrl(rawUrl: String?): Boolean {
        if (!isSafeHttpsUrl(rawUrl)) return false
        return try {
            val uri = URI(rawUrl!!.trim())
            val host = uri.host?.lowercase(Locale.ROOT) ?: return false
            ALLOWED_MAPS_HOSTS.contains(host)
        } catch (_: Exception) {
            false
        }
    }

    fun isAllowedWebViewExternalScheme(scheme: String?): Boolean {
        val s = scheme?.lowercase(Locale.ROOT) ?: return false
        return s == "https" || s == "http" || s == "tel"
    }
}
