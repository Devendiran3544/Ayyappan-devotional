package com.sabarimala.yatraguide.audio

object PlaybackStateMapper {
    const val REPEAT_OFF = 0
    const val REPEAT_ONE = 1
    const val REPEAT_ALL = 2

    fun nextRepeatMode(currentMode: Int): Int {
        return when (currentMode) {
            REPEAT_OFF -> REPEAT_ALL
            REPEAT_ALL -> REPEAT_ONE
            else -> REPEAT_OFF
        }
    }

    fun repeatModeLabel(mode: Int): String {
        return when (mode) {
            REPEAT_ONE -> "ONE"
            REPEAT_ALL -> "ALL"
            else -> "OFF"
        }
    }

    fun clampResumePosition(savedPositionMs: Long, durationMs: Long): Long {
        if (savedPositionMs <= 0L) return 0L
        if (durationMs <= 0L) return savedPositionMs
        // If user was within last 2 seconds of track end, restart cleanly from 0
        return if (savedPositionMs >= (durationMs - 2000L).coerceAtLeast(0L)) {
            0L
        } else {
            savedPositionMs
        }
    }

    fun formatDurationMs(durationMs: Long): String {
        val totalSec = (durationMs.coerceAtLeast(0L)) / 1000L
        val mins = totalSec / 60L
        val secs = totalSec % 60L
        return if (secs < 10L) "$mins:0$secs" else "$mins:$secs"
    }
}
