package com.sabarimala.yatraguide.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.sabarimala.yatraguide.MainActivity
import com.sabarimala.yatraguide.R
import com.sabarimala.yatraguide.data.YatraPreferencesStore
import com.sabarimala.yatraguide.model.NotificationCategory
import com.sabarimala.yatraguide.model.YatraAlert
import org.json.JSONArray
import org.json.JSONObject

class YatraNotificationManager(
    private val context: Context,
    private val store: YatraPreferencesStore
) {
    private val systemManager: NotificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    fun ensureChannelsCreated() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channels = listOf(
            NotificationChannel(
                NotificationCategory.TEMPLE_UPDATES.channelId,
                context.getString(R.string.channel_temple_updates_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.channel_temple_updates_desc)
            },
            NotificationChannel(
                NotificationCategory.TRAVEL_UPDATES.channelId,
                context.getString(R.string.channel_travel_updates_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.channel_travel_updates_desc)
            },
            NotificationChannel(
                NotificationCategory.WEATHER_ALERTS.channelId,
                context.getString(R.string.channel_weather_alerts_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_weather_alerts_desc)
            },
            NotificationChannel(
                NotificationCategory.EMERGENCY_NOTIFICATIONS.channelId,
                context.getString(R.string.channel_emergency_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_emergency_desc)
            },
            NotificationChannel(
                NotificationCategory.IMPORTANT_ANNOUNCEMENTS.channelId,
                context.getString(R.string.channel_announcements_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = context.getString(R.string.channel_announcements_desc)
            }
        )
        systemManager.createNotificationChannels(channels)
    }

    fun hasNotificationPermission(): Boolean {
        val runtimeGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
        return runtimeGranted && NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    fun postVerifiedAlert(alert: YatraAlert, language: String = "ta"): Boolean {
        val category = alert.category.notificationCategory
        if (!hasNotificationPermission()) return false
        if (!store.isNotificationCategoryEnabled(category)) return false

        ensureChannelsCreated()
        val title = if (language == "ta") alert.titleTa else alert.titleEn
        val body = if (language == "ta") alert.messageTa else alert.messageEn
        return dispatchNotification(
            category = category,
            notificationId = alert.id.hashCode(),
            title = title,
            body = body
        )
    }

    fun sendUserRequestedTestNotification(category: NotificationCategory, language: String = "ta"): Boolean {
        if (!hasNotificationPermission()) return false
        if (!store.isNotificationCategoryEnabled(category)) return false

        ensureChannelsCreated()
        val title = if (language == "ta") {
            "சோதனை அறிவிப்பு • ${category.titleTa}"
        } else {
            "Test Notification • ${category.titleEn}"
        }
        val body = if (language == "ta") {
            "இந்த அறிவிப்புப் பிரிவு சரியாக இயங்குகிறது. நம்பகமான நேரடி தகவல்கள் இணைக்கப்படும்போது இங்கு அறிவிப்புகள் வரும்."
        } else {
            "This notification channel is configured properly. Verified alerts for this category will appear here once a trusted live source is connected."
        }
        return dispatchNotification(
            category = category,
            notificationId = 5000 + category.ordinal,
            title = title,
            body = body
        )
    }

    private fun dispatchNotification(
        category: NotificationCategory,
        notificationId: Int,
        title: String,
        body: String
    ): Boolean {
        val openIntent = PendingIntent.getActivity(
            context,
            notificationId,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val priority = if (category.highPriority) {
            NotificationCompat.PRIORITY_HIGH
        } else {
            NotificationCompat.PRIORITY_DEFAULT
        }
        val notification = NotificationCompat.Builder(context, category.channelId)
            .setSmallIcon(R.drawable.ic_notification_lamp)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(priority)
            .setAutoCancel(true)
            .setContentIntent(openIntent)
            .build()

        return try {
            systemManager.notify(notificationId, notification)
            true
        } catch (_: SecurityException) {
            false
        }
    }

    fun getStatusJson(): JSONObject {
        val cats = JSONArray()
        NotificationCategory.values().forEach { cat ->
            cats.put(cat.toJson(enabled = store.isNotificationCategoryEnabled(cat)))
        }
        return JSONObject().apply {
            put("permissionGranted", hasNotificationPermission())
            put("requiresRuntimePermission", Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
            put("categories", cats)
        }
    }
}
