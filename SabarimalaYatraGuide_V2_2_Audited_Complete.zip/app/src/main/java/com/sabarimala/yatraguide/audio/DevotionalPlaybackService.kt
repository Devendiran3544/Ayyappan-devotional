package com.sabarimala.yatraguide.audio

import android.app.PendingIntent
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.net.Uri
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import com.sabarimala.yatraguide.MainActivity
import com.sabarimala.yatraguide.R
import com.sabarimala.yatraguide.data.SongLibraryRepository
import com.sabarimala.yatraguide.data.YatraPreferencesStore
import com.sabarimala.yatraguide.model.SongItem
import java.io.ByteArrayOutputStream

@OptIn(UnstableApi::class)
class DevotionalPlaybackService : MediaSessionService() {

    private var mediaSession: MediaSession? = null
    private lateinit var store: YatraPreferencesStore
    private lateinit var repository: SongLibraryRepository
    private var defaultArtworkBytes: ByteArray? = null

    override fun onCreate() {
        super.onCreate()
        store = YatraPreferencesStore(this)
        repository = SongLibraryRepository(this, store)
        defaultArtworkBytes = loadLauncherArtworkBytes()

        // Strictly audio-only: explicitly disable video tracks
        val trackSelector = DefaultTrackSelector(this).apply {
            parameters = buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                .build()
        }

        val audioAttributes = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
            .build()

        val exoPlayer = ExoPlayer.Builder(this)
            .setTrackSelector(trackSelector)
            .setAudioAttributes(audioAttributes, /* handleAudioFocus = */ true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()

        // Restore persisted shuffle and repeat preferences
        val savedState = store.getPlaybackState()
        exoPlayer.shuffleModeEnabled = savedState.shuffleEnabled
        exoPlayer.repeatMode = when (savedState.repeatMode) {
            Player.REPEAT_MODE_OFF,
            Player.REPEAT_MODE_ONE,
            Player.REPEAT_MODE_ALL -> savedState.repeatMode
            else -> Player.REPEAT_MODE_ALL
        }

        exoPlayer.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                val songId = mediaItem?.mediaId
                if (!songId.isNullOrBlank()) {
                    store.addRecentlyPlayed(songId)
                    persistCurrentState(exoPlayer)
                }
            }

            override fun onIsPlayingChanged(isPlaying: Boolean) {
                if (isPlaying) {
                    val songId = exoPlayer.currentMediaItem?.mediaId
                    if (!songId.isNullOrBlank()) {
                        store.addRecentlyPlayed(songId)
                    }
                }
                persistCurrentState(exoPlayer)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                persistCurrentState(exoPlayer)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                persistCurrentState(exoPlayer)
            }
        })

        val sessionActivityIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val callback = object : MediaSession.Callback {
            override fun onPlaybackResumption(
                mediaSession: MediaSession,
                controller: MediaSession.ControllerInfo
            ): ListenableFuture<MediaSession.MediaItemsWithStartPosition> {
                val songs = repository.getAllSongs()
                val mediaItems = songs.map { toMediaItem(it, defaultArtworkBytes) }
                val saved = store.getPlaybackState()
                val startIndex = if (!saved.lastSongId.isNullOrBlank()) {
                    songs.indexOfFirst { it.id == saved.lastSongId }.coerceAtLeast(0)
                } else {
                    0
                }
                val expectedDuration = songs.getOrNull(startIndex)?.durationMs ?: 0L
                val safePos = PlaybackStateMapper.clampResumePosition(saved.lastPositionMs, expectedDuration)
                return Futures.immediateFuture(
                    MediaSession.MediaItemsWithStartPosition(mediaItems, startIndex, safePos)
                )
            }
        }

        mediaSession = MediaSession.Builder(this, exoPlayer)
            .setSessionActivity(sessionActivityIntent)
            .setCallback(callback)
            .build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? {
        return mediaSession
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        val player = mediaSession?.player
        if (player == null || !player.playWhenReady || player.mediaItemCount == 0 ||
            player.playbackState == Player.STATE_ENDED
        ) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        mediaSession?.run {
            persistCurrentState(player)
            player.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    private fun persistCurrentState(player: Player) {
        val songId = player.currentMediaItem?.mediaId
        val pos = player.currentPosition.coerceAtLeast(0L)
        store.savePlaybackState(
            songId = songId,
            positionMs = pos,
            shuffleEnabled = player.shuffleModeEnabled,
            repeatMode = player.repeatMode
        )
    }

    private fun loadLauncherArtworkBytes(): ByteArray? {
        return try {
            val drawable = ContextCompat.getDrawable(this, R.mipmap.ic_launcher) ?: return null
            val width = drawable.intrinsicWidth.coerceAtLeast(192)
            val height = drawable.intrinsicHeight.coerceAtLeast(192)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            drawable.setBounds(0, 0, canvas.width, canvas.height)
            drawable.draw(canvas)
            val baos = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, baos)
            bitmap.recycle()
            baos.toByteArray()
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        fun toMediaItem(song: SongItem, artworkBytes: ByteArray? = null): MediaItem {
            val metaBuilder = MediaMetadata.Builder()
                .setTitle(song.titleTa)
                .setDisplayTitle(song.titleTa)
                .setSubtitle(song.subtitleTa.ifBlank { song.artist })
                .setArtist(song.artist.ifBlank { "Sabarimala Devotional" })
                .setAlbumTitle("Sabarimala Yatra Guide")
                .setMediaType(MediaMetadata.MEDIA_TYPE_MUSIC)
            if (artworkBytes != null && artworkBytes.isNotEmpty()) {
                metaBuilder.setArtworkData(artworkBytes, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
            }
            return MediaItem.Builder()
                .setMediaId(song.id)
                .setUri(Uri.parse(song.uriString))
                .setMediaMetadata(metaBuilder.build())
                .build()
        }
    }
}
