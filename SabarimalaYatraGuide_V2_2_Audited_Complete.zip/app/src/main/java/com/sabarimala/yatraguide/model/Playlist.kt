package com.sabarimala.yatraguide.model

import org.json.JSONArray
import org.json.JSONObject

data class Playlist(
    val id: String,
    val name: String,
    val songIds: List<String>,
    val createdAt: Long
) {
    fun toJson(): JSONObject {
        val idsArray = JSONArray()
        songIds.forEach { idsArray.put(it) }
        return JSONObject().apply {
            put("id", id)
            put("name", name)
            put("songIds", idsArray)
            put("createdAt", createdAt)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): Playlist? {
            val id = obj.optString("id", "").trim()
            val name = obj.optString("name", "").trim()
            if (id.isEmpty() || name.isEmpty()) return null
            val ids = mutableListOf<String>()
            val arr = obj.optJSONArray("songIds")
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val sid = arr.optString(i, "").trim()
                    if (sid.isNotEmpty() && !ids.contains(sid)) {
                        ids.add(sid)
                    }
                }
            }
            return Playlist(
                id = id,
                name = name,
                songIds = ids,
                createdAt = obj.optLong("createdAt", 0L)
            )
        }
    }
}
