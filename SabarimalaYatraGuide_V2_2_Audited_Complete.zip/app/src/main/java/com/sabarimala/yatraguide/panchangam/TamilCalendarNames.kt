package com.sabarimala.yatraguide.panchangam

data class BilingualName(val ta: String, val en: String)

object TamilCalendarNames {

    // 60-Year Tamil / Jovian Cycle anchored to Prabhava = Chithirai 1987 (index 0)
    // Index 39 = 2026-2027 = பராபவ (Parabhava), Index 40 = 2027-2028 = பிலவங்க (Pilavanga)
    val TAMIL_YEARS_60: List<BilingualName> = listOf(
        BilingualName("பிரபவ", "Prabhava"),
        BilingualName("விபவ", "Vibhava"),
        BilingualName("சுக்ல", "Shukla"),
        BilingualName("பிரமோதூத", "Pramodoota"),
        BilingualName("பிரஜோற்பத்தி", "Prajothpatti"),
        BilingualName("ஆங்கீரச", "Angirasa"),
        BilingualName("ஸ்ரீமுக", "Srimukha"),
        BilingualName("பவ", "Bhava"),
        BilingualName("யுவ", "Yuva"),
        BilingualName("தாது", "Dhatu"),
        BilingualName("ஈஸ்வர", "Eeshwara"),
        BilingualName("வெகுதானிய", "Bahudhanya"),
        BilingualName("பிரமாதி", "Pramathi"),
        BilingualName("விக்ரம", "Vikrama"),
        BilingualName("விஷு", "Vishu"),
        BilingualName("சித்திரபானு", "Chitrabhanu"),
        BilingualName("சுபானு", "Subhanu"),
        BilingualName("தாரண", "Tharana"),
        BilingualName("பார்த்திப", "Parthiba"),
        BilingualName("விய", "Viya"),
        BilingualName("சர்வஜித்", "Sarvajith"),
        BilingualName("சர்வதாரி", "Sarvadhari"),
        BilingualName("விரோதி", "Virodhi"),
        BilingualName("விக்ருதி", "Vikruthi"),
        BilingualName("கர", "Kara"),
        BilingualName("நந்தன", "Nandana"),
        BilingualName("விஜய", "Vijaya"),
        BilingualName("ஜய", "Jaya"),
        BilingualName("மன்மத", "Manmatha"),
        BilingualName("துர்முகி", "Durmukhi"),
        BilingualName("ஹேவிளம்பி", "Hevilambi"),
        BilingualName("விளம்பி", "Vilambi"),
        BilingualName("விகாரி", "Vikari"),
        BilingualName("சார்வரி", "Sharvari"),
        BilingualName("பிலவ", "Plava"),
        BilingualName("சுபகிருது", "Subhakrith"),
        BilingualName("சோபகிருது", "Sobhakrith"),
        BilingualName("குரோதி", "Krodhi"),
        BilingualName("விசுவாவசு", "Viswavasu"),
        BilingualName("பராபவ", "Parabhava"),
        BilingualName("பிலவங்க", "Pilavanga"),
        BilingualName("கீலக", "Keelaka"),
        BilingualName("சௌமிய", "Saumya"),
        BilingualName("சாதாரண", "Sadharana"),
        BilingualName("விரோதிகிருது", "Virodhikrith"),
        BilingualName("பரிதாபி", "Paridhabi"),
        BilingualName("பிரமாதீச", "Pramadheesa"),
        BilingualName("ஆனந்த", "Ananda"),
        BilingualName("ராட்சச", "Rakshasa"),
        BilingualName("நள", "Nala"),
        BilingualName("பிங்கள", "Pingala"),
        BilingualName("காளயுக்தி", "Kalayukthi"),
        BilingualName("சித்தார்த்தி", "Siddharthi"),
        BilingualName("ரௌத்திரி", "Raudri"),
        BilingualName("துன்மதி", "Durmathi"),
        BilingualName("துந்துபி", "Dundubhi"),
        BilingualName("ருத்ரோத்காரி", "Rudhrodhgari"),
        BilingualName("ரக்தாட்சி", "Raktakshi"),
        BilingualName("குரோதன", "Krodhana"),
        BilingualName("அட்சய", "Akshaya")
    )

    // 12 Tamil Solar Months (index 0 = Mesha / Chithirai ... index 11 = Meena / Panguni)
    val TAMIL_MONTHS: List<BilingualName> = listOf(
        BilingualName("சித்திரை", "Chithirai"),
        BilingualName("வைகாசி", "Vaikasi"),
        BilingualName("ஆனி", "Aani"),
        BilingualName("ஆடி", "Aadi"),
        BilingualName("ஆவணி", "Aavani"),
        BilingualName("புரட்டாசி", "Purattasi"),
        BilingualName("ஐப்பசி", "Aippasi"),
        BilingualName("கார்த்திகை", "Karthigai"),
        BilingualName("மார்கழி", "Margazhi"),
        BilingualName("தை", "Thai"),
        BilingualName("மாசி", "Maasi"),
        BilingualName("பங்குனி", "Panguni")
    )

    // Sunday = 0 .. Saturday = 6
    val WEEKDAYS: List<BilingualName> = listOf(
        BilingualName("ஞாயிற்றுக்கிழமை", "Sunday"),
        BilingualName("திங்கட்கிழமை", "Monday"),
        BilingualName("செவ்வாய்க்கிழமை", "Tuesday"),
        BilingualName("புதன்கிழமை", "Wednesday"),
        BilingualName("வியாழக்கிழமை", "Thursday"),
        BilingualName("வெள்ளிக்கிழமை", "Friday"),
        BilingualName("சனிக்கிழமை", "Saturday")
    )

    val PAKSHA_SHUKLA = BilingualName("வளர்பிறை (சுக்ல பக்ஷம்)", "Shukla Paksha (Waxing)")
    val PAKSHA_KRISHNA = BilingualName("தேய்பிறை (கிருஷ்ண பக்ஷம்)", "Krishna Paksha (Waning)")

    // 30 Tithis (0..14 Shukla, 15..29 Krishna)
    val TITHIS: List<BilingualName> = listOf(
        BilingualName("பிரதமை", "Prathama"),
        BilingualName("துவிதியை", "Dwitiya"),
        BilingualName("திருதியை", "Tritiya"),
        BilingualName("சதுர்த்தி", "Chaturthi"),
        BilingualName("பஞ்சமி", "Panchami"),
        BilingualName("சஷ்டி", "Shashthi"),
        BilingualName("சப்தமி", "Saptami"),
        BilingualName("அஷ்டமி", "Ashtami"),
        BilingualName("நவமி", "Navami"),
        BilingualName("தசமி", "Dashami"),
        BilingualName("ஏகாதசி", "Ekadashi"),
        BilingualName("துவாதசி", "Dwadashi"),
        BilingualName("திரயோதசி", "Trayodashi"),
        BilingualName("சதுர்த்தசி", "Chaturdashi"),
        BilingualName("பௌர்ணமி", "Pournami"),
        BilingualName("பிரதமை", "Prathama"),
        BilingualName("துவிதியை", "Dwitiya"),
        BilingualName("திருதியை", "Tritiya"),
        BilingualName("சதுர்த்தி", "Chaturthi"),
        BilingualName("பஞ்சமி", "Panchami"),
        BilingualName("சஷ்டி", "Shashthi"),
        BilingualName("சப்தமி", "Saptami"),
        BilingualName("அஷ்டமி", "Ashtami"),
        BilingualName("நவமி", "Navami"),
        BilingualName("தசமி", "Dashami"),
        BilingualName("ஏகாதசி", "Ekadashi"),
        BilingualName("துவாதசி", "Dwadashi"),
        BilingualName("திரயோதசி", "Trayodashi"),
        BilingualName("சதுர்த்தசி", "Chaturdashi"),
        BilingualName("அமாவாசை", "Amavasya")
    )

    val NAKSHATRAS: List<BilingualName> = listOf(
        BilingualName("அஸ்வினி", "Ashwini"),
        BilingualName("பரணி", "Bharani"),
        BilingualName("கார்த்திகை", "Krittika"),
        BilingualName("ரோகிணி", "Rohini"),
        BilingualName("மிருகசீரிஷம்", "Mrigashira"),
        BilingualName("திருவாதிரை", "Ardra"),
        BilingualName("புனர்பூசம்", "Punarvasu"),
        BilingualName("பூசம்", "Pushya"),
        BilingualName("ஆயில்யம்", "Ashlesha"),
        BilingualName("மகம்", "Magha"),
        BilingualName("பூரம்", "Purva Phalguni"),
        BilingualName("உத்திரம்", "Uttara Phalguni"),
        BilingualName("அஸ்தம்", "Hasta"),
        BilingualName("சித்திரை", "Chitra"),
        BilingualName("சுவாதி", "Swati"),
        BilingualName("விசாகம்", "Vishakha"),
        BilingualName("அனுஷம்", "Anuradha"),
        BilingualName("கேட்டை", "Jyeshtha"),
        BilingualName("மூலம்", "Mula"),
        BilingualName("பூராடம்", "Purva Ashadha"),
        BilingualName("உத்திராடம்", "Uttara Ashadha"),
        BilingualName("திருவோணம்", "Shravana"),
        BilingualName("அவிட்டம்", "Dhanishtha"),
        BilingualName("சதயம்", "Shatabhisha"),
        BilingualName("பூரட்டாதி", "Purva Bhadrapada"),
        BilingualName("உத்திரட்டாதி", "Uttara Bhadrapada"),
        BilingualName("ரேவதி", "Revati")
    )

    val YOGAS: List<BilingualName> = listOf(
        BilingualName("விஷ்கம்பம்", "Vishkambha"),
        BilingualName("ப்ரீதி", "Priti"),
        BilingualName("ஆயுஷ்மான்", "Ayushman"),
        BilingualName("சௌபாக்கியம்", "Saubhagya"),
        BilingualName("சோபனம்", "Shobhana"),
        BilingualName("அதிகண்டம்", "Atiganda"),
        BilingualName("சுகர்மம்", "Sukarma"),
        BilingualName("திருதி", "Dhriti"),
        BilingualName("சூலம்", "Shula"),
        BilingualName("கண்டம்", "Ganda"),
        BilingualName("விருத்தி", "Vriddhi"),
        BilingualName("துருவம்", "Dhruva"),
        BilingualName("வியாகாதம்", "Vyaghata"),
        BilingualName("ஹர்ஷணம்", "Harshana"),
        BilingualName("வஜ்ரம்", "Vajra"),
        BilingualName("சித்தி", "Siddhi"),
        BilingualName("வியதீபாதம்", "Vyatipata"),
        BilingualName("வரியான்", "Variyan"),
        BilingualName("பரிகம்", "Parigha"),
        BilingualName("சிவம்", "Shiva"),
        BilingualName("சித்தம்", "Siddha"),
        BilingualName("சாத்தியம்", "Sadhya"),
        BilingualName("சுபம்", "Shubha"),
        BilingualName("சுக்லம்", "Shukla"),
        BilingualName("பிரம்மம்", "Brahma"),
        BilingualName("இந்திரம்", "Indra"),
        BilingualName("வைதிருதி", "Vaidhriti")
    )

    val MOVABLE_KARANAS: List<BilingualName> = listOf(
        BilingualName("பவம்", "Bava"),
        BilingualName("பாலவம்", "Balava"),
        BilingualName("கௌலவம்", "Kaulava"),
        BilingualName("தைதுலம்", "Taitila"),
        BilingualName("கரசை", "Gara"),
        BilingualName("வணிசை", "Vanija"),
        BilingualName("பத்திரை (விஷ்டி)", "Vishti (Bhadra)")
    )

    val KARANA_KIMSTUGHNA = BilingualName("கிம்ஸ்துக்னம்", "Kimstughna")
    val KARANA_SHAKUNI = BilingualName("சகுனி", "Shakuni")
    val KARANA_CHATUSHPADA = BilingualName("சதுஷ்பாதம்", "Chatushpada")
    val KARANA_NAGA = BilingualName("நாகவம்", "Naga")

    fun karanaForHalfTithi(halfTithiIndex: Int): BilingualName {
        val idx = ((halfTithiIndex % 60) + 60) % 60
        return when (idx) {
            0 -> KARANA_KIMSTUGHNA
            57 -> KARANA_SHAKUNI
            58 -> KARANA_CHATUSHPADA
            59 -> KARANA_NAGA
            else -> MOVABLE_KARANAS[(idx - 1) % 7]
        }
    }

    fun tamilYearForSolarYear(solarCycleYear: Int): BilingualName {
        // Prabhava = 1987 (index 0)
        val idx = ((solarCycleYear - 1987) % 60 + 60) % 60
        return TAMIL_YEARS_60[idx]
    }
}
