package com.sabarimala.yatraguide.panchangam

import java.util.Calendar
import java.util.GregorianCalendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.roundToInt
import kotlin.math.roundToLong
import kotlin.math.sin
import kotlin.math.tan

/**
 * Pure-Kotlin offline astronomical Panchangam engine (Audited V2.2):
 * - Jean Meeus "Astronomical Algorithms" (Ch. 22 Nutation, Ch. 25 Solar + T1900 planetary/lunar
 *   perturbations + variable aberration -20.4898"/R, Ch. 47 Lunar ELP-2000 60-term series)
 * - ICRC / Swiss Ephemeris Lahiri Ayanamsa (mean J2000.0 = 23°51'39.46" + precession + nutation)
 * - NOAA upper-limb apparent Sunrise/Sunset (zenith = 90°50')
 * - Local-sunrise-anchored Panchangam evaluation with DST-safe local day boundaries
 * - Vedic night-length (Ratrimana / 15) Brahma Muhurta and daylight-eighth Rahu/Yama/Gulikai
 * - Traditional Tamil solar ingress rule with corrected Jan 1–14 Margazhi Tamil year mapping
 */
object AstronomicalCalculator {

    private const val DEG2RAD = Math.PI / 180.0
    private const val RAD2DEG = 180.0 / Math.PI
    private const val OFFICIAL_SUNRISE_ZENITH = 90.833333
    private val UTC_TZ: TimeZone = TimeZone.getTimeZone("UTC")

    // Weekday-specific eighths of daylight (index 0 = Sunday .. 6 = Saturday), 1-based slot numbers
    private val RAHU_SLOTS = intArrayOf(8, 2, 7, 5, 6, 4, 3)
    private val YAMA_SLOTS = intArrayOf(5, 4, 3, 2, 1, 7, 6)
    private val GULI_SLOTS = intArrayOf(7, 6, 5, 4, 3, 2, 1)

    // Meeus Table 47.A principal periodic longitude terms for the Moon (D, M, M', F, coeff in 1e-6 deg)
    private val MOON_L_TERMS: Array<IntArray> = arrayOf(
        intArrayOf(0, 0, 1, 0, 6288774), intArrayOf(2, 0, -1, 0, 1274027), intArrayOf(2, 0, 0, 0, 658314),
        intArrayOf(0, 0, 2, 0, 213618), intArrayOf(0, 1, 0, 0, -185116), intArrayOf(0, 0, 0, 2, -114332),
        intArrayOf(2, 0, -2, 0, 58793), intArrayOf(2, -1, -1, 0, 57066), intArrayOf(2, 0, 1, 0, 53322),
        intArrayOf(2, -1, 0, 0, 45758), intArrayOf(0, 1, -1, 0, -40923), intArrayOf(1, 0, 0, 0, -34720),
        intArrayOf(0, 1, 1, 0, -30383), intArrayOf(2, 0, 0, -2, 15327), intArrayOf(0, 0, 1, 2, -12528),
        intArrayOf(0, 0, 1, -2, 10980), intArrayOf(4, 0, -1, 0, 10675), intArrayOf(0, 0, 3, 0, 10034),
        intArrayOf(4, 0, -2, 0, 8548), intArrayOf(2, 1, -1, 0, -7888), intArrayOf(2, 1, 0, 0, -6766),
        intArrayOf(1, 0, -1, 0, -5163), intArrayOf(1, 1, 0, 0, 4987), intArrayOf(2, -1, 1, 0, 4036),
        intArrayOf(2, 0, 2, 0, 3994), intArrayOf(4, 0, 0, 0, 3861), intArrayOf(2, 0, -3, 0, 3665),
        intArrayOf(0, 1, -2, 0, -2689), intArrayOf(2, 0, -1, 2, -2602), intArrayOf(2, -1, -2, 0, 2390),
        intArrayOf(1, 0, 1, 0, -2348), intArrayOf(2, -2, 0, 0, 2236), intArrayOf(0, 1, 2, 0, -2120),
        intArrayOf(0, 2, 0, 0, -2069), intArrayOf(2, -2, -1, 0, 2048), intArrayOf(2, 0, 1, -2, -1773),
        intArrayOf(2, 0, 0, 2, -1595), intArrayOf(4, -1, -1, 0, 1215), intArrayOf(0, 0, 2, 2, -1110),
        intArrayOf(3, 0, -1, 0, -892), intArrayOf(2, 1, 1, 0, -810), intArrayOf(4, -1, -2, 0, 759),
        intArrayOf(0, 2, -1, 0, -713), intArrayOf(2, 2, -1, 0, -700), intArrayOf(2, 1, -2, 0, 691),
        intArrayOf(2, -1, 0, -2, 596), intArrayOf(4, 0, 1, 0, 549), intArrayOf(0, 0, 4, 0, 537),
        intArrayOf(4, -1, 0, 0, 520), intArrayOf(1, 0, -2, 0, -487), intArrayOf(2, 1, 0, -2, -399),
        intArrayOf(0, 0, 2, -2, -381), intArrayOf(1, 1, 1, 0, 351), intArrayOf(3, 0, -2, 0, -340),
        intArrayOf(4, 0, -3, 0, 330), intArrayOf(2, -1, 2, 0, 327), intArrayOf(0, 2, 1, 0, -323),
        intArrayOf(1, 1, -1, 0, 299), intArrayOf(2, 0, 3, 0, 294)
    )

    fun norm360(deg: Double): Double {
        var x = deg % 360.0
        if (x < 0.0) x += 360.0
        return x
    }

    fun julianDayUtc(year: Int, month: Int, day: Int, hourUtc: Double = 0.0): Double {
        var y = year
        var m = month
        if (m <= 2) {
            y -= 1
            m += 12
        }
        val a = y / 100
        val b = 2 - a + a / 4
        return floor(365.25 * (y + 4716)) +
            floor(30.6001 * (m + 1)) +
            day +
            (hourUtc / 24.0) +
            b - 1524.5
    }

    private fun jdFromEpochMs(epochMs: Long): Double = (epochMs / 86400000.0) + 2440587.5

    private fun epochMsFromJd(jdUtc: Double): Long = ((jdUtc - 2440587.5) * 86400000.0).roundToLong()

    private fun deltaTSeconds(yearDecimal: Double): Double {
        val t = yearDecimal - 2000.0
        return 62.92 + 0.32217 * t + 0.005589 * t * t
    }

    private fun jdTtFromJdUtc(jdUtc: Double): Double {
        val yearApprox = 2000.0 + (jdUtc - 2451545.0) / 365.25
        return jdUtc + deltaTSeconds(yearApprox) / 86400.0
    }

    private fun nutationLongitudeDeg(tCentury: Double): Double {
        val omega = norm360(125.04452 - 1934.136261 * tCentury + 0.0020708 * tCentury * tCentury)
        val l = norm360(280.4665 + 36000.7698 * tCentury)
        val lp = norm360(218.3165 + 481267.8813 * tCentury)
        val dpsiArcsec = (
            -17.20 * sin(omega * DEG2RAD)
                - 1.32 * sin(2.0 * l * DEG2RAD)
                - 0.23 * sin(2.0 * lp * DEG2RAD)
                + 0.21 * sin(2.0 * omega * DEG2RAD)
            )
        return dpsiArcsec / 3600.0
    }

    fun sunApparentLongitude(jdUtc: Double): Double {
        val jdTt = jdTtFromJdUtc(jdUtc)
        val t = (jdTt - 2451545.0) / 36525.0
        val t1900 = (jdTt - 2415020.0) / 36525.0

        val l0 = norm360(280.4664567 + 36000.76982779 * t + 0.0003032028 * t * t)
        val m = norm360(357.5291092 + 35999.0502909 * t - 0.0001536 * t * t)
        val mRad = m * DEG2RAD
        val c = (1.914602 - 0.004817 * t - 0.000014 * t * t) * sin(mRad) +
            (0.019993 - 0.000101 * t) * sin(2.0 * mRad) +
            0.000289 * sin(3.0 * mRad)

        // Principal Venus, Jupiter, and lunar perturbations (Meeus / Newcomb, T from B1900.0)
        val aVenus = (153.23 + 22518.7541 * t1900) * DEG2RAD
        val bVenus = (216.57 + 45037.5082 * t1900) * DEG2RAD
        val cJup = (312.69 + 32964.3577 * t1900) * DEG2RAD
        val dMoon = (350.74 + 445267.1142 * t1900 - 0.00144 * t1900 * t1900) * DEG2RAD
        val eLong = (231.19 + 20.20 * t1900) * DEG2RAD
        val pert = 0.00134 * cos(aVenus) +
            0.00154 * cos(bVenus) +
            0.00200 * cos(cJup) +
            0.00179 * sin(dMoon) +
            0.00178 * sin(eLong)

        val trueLon = l0 + c + pert
        val e = 0.016708634 - 0.000042037 * t
        val trueAnomaly = m + c
        val radiusAu = (1.000001018 * (1.0 - e * e)) / (1.0 + e * cos(trueAnomaly * DEG2RAD))
        val aberrationDeg = -20.4898 / (3600.0 * radiusAu)

        return norm360(trueLon + aberrationDeg + nutationLongitudeDeg(t))
    }

    fun moonApparentLongitude(jdUtc: Double): Double {
        val jdTt = jdTtFromJdUtc(jdUtc)
        val t = (jdTt - 2451545.0) / 36525.0
        val t2 = t * t
        val t3 = t2 * t
        val t4 = t3 * t

        val lp = norm360(218.3164477 + 481267.88123421 * t - 0.0015786 * t2 + t3 / 538841.0 - t4 / 65194000.0)
        val d = norm360(297.8501921 + 445267.1114034 * t - 0.0018819 * t2 + t3 / 545868.0 - t4 / 113065000.0)
        val m = norm360(357.5291092 + 35999.0502909 * t - 0.0001536 * t2 + t3 / 24490000.0)
        val mp = norm360(134.9633964 + 477198.8675055 * t + 0.0087414 * t2 + t3 / 69699.0 - t4 / 14712000.0)
        val f = norm360(93.2720950 + 483202.0175233 * t - 0.0036539 * t2 - t3 / 3526000.0 + t4 / 863310000.0)

        val a1 = norm360(119.75 + 131.849 * t)
        val a2 = norm360(53.09 + 479264.290 * t)
        val e = 1.0 - 0.002516 * t - 0.0000074 * t2
        val e2 = e * e

        var sumL = 0.0
        for (term in MOON_L_TERMS) {
            val dC = term[0]
            val mC = term[1]
            val mpC = term[2]
            val fC = term[3]
            val coeff = term[4].toDouble()
            val arg = (dC * d + mC * m + mpC * mp + fC * f) * DEG2RAD
            var valTerm = coeff * sin(arg)
            val absM = abs(mC)
            if (absM == 1) valTerm *= e
            else if (absM == 2) valTerm *= e2
            sumL += valTerm
        }

        sumL += 3958.0 * sin(a1 * DEG2RAD)
        sumL += 1962.0 * sin((lp - f) * DEG2RAD)
        sumL += 318.0 * sin(a2 * DEG2RAD)

        val lon = lp + sumL / 1000000.0 + nutationLongitudeDeg(t)
        return norm360(lon)
    }

    /**
     * ICRC / Swiss Ephemeris Chitra Paksha Lahiri Ayanamsa.
     * Mean Lahiri at J2000.0 = 23°51'39.46" (23.8609611°), so True Lahiri at J2000.0
     * with -13.93" nutation equals 23°51'25.53".
     */
    fun lahiriAyanamsaDeg(jdUtc: Double): Double {
        val jdTt = jdTtFromJdUtc(jdUtc)
        val t = (jdTt - 2451545.0) / 36525.0
        val meanAyan = 23.8609611 + (5029.0966 * t + 1.11113 * t * t) / 3600.0
        return meanAyan + nutationLongitudeDeg(t)
    }

    fun siderealSunLongitude(jdUtc: Double): Double =
        norm360(sunApparentLongitude(jdUtc) - lahiriAyanamsaDeg(jdUtc))

    fun siderealMoonLongitude(jdUtc: Double): Double =
        norm360(moonApparentLongitude(jdUtc) - lahiriAyanamsaDeg(jdUtc))

    /**
     * Computes apparent upper-limb sunrise and sunset in UTC hours for a civil Gregorian date.
     * Returns null pair component at extreme polar latitudes where Sun does not rise/set.
     */
    fun computeSunriseSunsetUtcHours(
        year: Int,
        month: Int,
        day: Int,
        latitude: Double,
        longitude: Double
    ): Pair<Double?, Double?> {
        return Pair(
            computeSolarEventUtcHours(year, month, day, latitude, longitude, isSunrise = true),
            computeSolarEventUtcHours(year, month, day, latitude, longitude, isSunrise = false)
        )
    }

    private fun computeSolarEventUtcHours(
        year: Int,
        month: Int,
        day: Int,
        latitude: Double,
        longitude: Double,
        isSunrise: Boolean
    ): Double? {
        var utHours = (if (isSunrise) 6.0 else 18.0) - (longitude / 15.0)
        for (iter in 0 until 3) {
            val jd = julianDayUtc(year, month, day, utHours)
            val t = (jd - 2451545.0) / 36525.0
            val l0 = norm360(280.46646 + t * (36000.76983 + t * 0.0003032))
            val m = norm360(357.52911 + t * (35999.05029 - 0.0001537 * t))
            val e = 0.016708634 - t * (0.000042037 + 0.0000001267 * t)
            val c = sin(m * DEG2RAD) * (1.914602 - t * (0.004817 + 0.000014 * t)) +
                sin(2.0 * m * DEG2RAD) * (0.019993 - 0.000101 * t) +
                sin(3.0 * m * DEG2RAD) * 0.000289
            val sunTrueLon = l0 + c
            val omega = 125.04 - 1934.136 * t
            val lam = sunTrueLon - 0.00569 - 0.00478 * sin(omega * DEG2RAD)
            val obliq0 = 23.0 + (26.0 + (21.448 - t * (46.815 + t * (0.00059 - t * 0.001813))) / 60.0) / 60.0
            val obliq = obliq0 + 0.00256 * cos(omega * DEG2RAD)
            val decl = asin(sin(obliq * DEG2RAD) * sin(lam * DEG2RAD))
            val tanHalfObliq = tan((obliq / 2.0) * DEG2RAD)
            val yVar = tanHalfObliq * tanHalfObliq
            val eqTimeMin = 4.0 * RAD2DEG * (
                yVar * sin(2.0 * l0 * DEG2RAD) -
                    2.0 * e * sin(m * DEG2RAD) +
                    4.0 * e * yVar * sin(m * DEG2RAD) * cos(2.0 * l0 * DEG2RAD) -
                    0.5 * yVar * yVar * sin(4.0 * l0 * DEG2RAD) -
                    1.25 * e * e * sin(2.0 * m * DEG2RAD)
                )
            val cosHa = (cos(OFFICIAL_SUNRISE_ZENITH * DEG2RAD) / (cos(latitude * DEG2RAD) * cos(decl))) -
                tan(latitude * DEG2RAD) * tan(decl)
            if (cosHa > 1.0 || cosHa < -1.0) return null
            val haDeg = acos(cosHa) * RAD2DEG
            val solarNoonMin = 720.0 - 4.0 * longitude - eqTimeMin
            val eventMin = if (isSunrise) solarNoonMin - 4.0 * haDeg else solarNoonMin + 4.0 * haDeg
            utHours = eventMin / 60.0
        }
        return utHours
    }

    fun findTransitionJd(
        jdStart: Double,
        angleFn: (Double) -> Double,
        targetDeg: Double,
        maxDays: Double = 2.2
    ): Double? {
        fun signedDiff(jd: Double): Double {
            var d = norm360(angleFn(jd) - targetDeg)
            if (d > 180.0) d -= 360.0
            return d
        }

        val step = 0.05
        var t0 = jdStart
        var d0 = signedDiff(t0)
        while (t0 - jdStart < maxDays) {
            val t1 = t0 + step
            val d1 = signedDiff(t1)
            if (d0 <= 0.0 && d1 >= 0.0) {
                var lo = t0
                var hi = t1
                for (i in 0 until 30) {
                    val mid = 0.5 * (lo + hi)
                    if (signedDiff(mid) < 0.0) lo = mid else hi = mid
                }
                return 0.5 * (lo + hi)
            }
            t0 = t1
            d0 = d1
        }
        return null
    }

    fun getTimezoneOffsetHours(year: Int, month: Int, day: Int, timeZoneId: String): Double {
        val tz = TimeZone.getTimeZone(timeZoneId)
        val cal = GregorianCalendar(tz).apply {
            set(year, month - 1, day, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return tz.getOffset(cal.timeInMillis) / 3600000.0
    }

    private fun localDayBoundsJdUtc(year: Int, month: Int, day: Int, timeZoneId: String): Pair<Double, Double> {
        val tz = TimeZone.getTimeZone(timeZoneId)
        val startCal = GregorianCalendar(tz).apply {
            set(year, month - 1, day, 0, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val endCal = (startCal.clone() as GregorianCalendar).apply {
            add(Calendar.DAY_OF_MONTH, 1)
        }
        return Pair(jdFromEpochMs(startCal.timeInMillis), jdFromEpochMs(endCal.timeInMillis))
    }

    /**
     * Formats an instant (JD UTC) in the target timezone rounded to the nearest minute,
     * returning Pair(formatted12HourTime, isOnOrAfterNextCivilDay) consistently even at 23:59:45.
     */
    fun formatEventTimeWithRollover(
        eventJdUtc: Double,
        baseYear: Int,
        baseMonth: Int,
        baseDay: Int,
        timeZoneId: String
    ): Pair<String, Boolean> {
        val tz = TimeZone.getTimeZone(timeZoneId)
        // Round to nearest minute in epoch milliseconds before extracting civil date/time fields
        val roundedMinMs = ((epochMsFromJd(eventJdUtc) + 30_000L) / 60_000L) * 60_000L
        val evCal = GregorianCalendar(tz).apply { timeInMillis = roundedMinMs }
        val h24 = evCal.get(Calendar.HOUR_OF_DAY)
        val m = evCal.get(Calendar.MINUTE)
        val ampm = if (h24 < 12) "AM" else "PM"
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        val formatted = String.format(Locale.US, "%02d:%02d %s", h12, m, ampm)

        val evY = evCal.get(Calendar.YEAR)
        val evM = evCal.get(Calendar.MONTH) + 1
        val evD = evCal.get(Calendar.DAY_OF_MONTH)
        val isNextDay = (evY > baseYear) ||
            (evY == baseYear && evM > baseMonth) ||
            (evY == baseYear && evM == baseMonth && evD > baseDay)

        return Pair(formatted, isNextDay)
    }

    fun formatTimezoneOffsetLabel(offsetHours: Double, timeZoneId: String): String {
        if (timeZoneId == "Asia/Kolkata") return "IST (UTC+05:30)"
        val sign = if (offsetHours >= 0.0) "+" else "-"
        val absMin = (abs(offsetHours) * 60.0).roundToInt()
        val h = absMin / 60
        val m = absMin % 60
        return String.format(Locale.US, "UTC%s%02d:%02d", sign, h, m)
    }

    fun formatLocalHours12(localHours: Double): String {
        val totalMin = ((localHours * 60.0).roundToInt() % 1440 + 1440) % 1440
        val h24 = totalMin / 60
        val m = totalMin % 60
        val ampm = if (h24 < 12) "AM" else "PM"
        val h12 = when {
            h24 == 0 -> 12
            h24 > 12 -> h24 - 12
            else -> h24
        }
        return String.format(Locale.US, "%02d:%02d %s", h12, m, ampm)
    }

    fun formatLocalHours24(localHours: Double): String {
        val totalMin = ((localHours * 60.0).roundToInt() % 1440 + 1440) % 1440
        return String.format(Locale.US, "%02d:%02d", totalMin / 60, totalMin % 60)
    }

    fun dayOfWeekSundayZero(year: Int, month: Int, day: Int): Int {
        val cal = GregorianCalendar(UTC_TZ).apply {
            set(year, month - 1, day, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.get(Calendar.DAY_OF_WEEK) - 1
    }

    fun daysInGregorianMonth(year: Int, month: Int): Int {
        val cal = GregorianCalendar(UTC_TZ).apply {
            set(year, month - 1, 1, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    }

    private fun previousCivilDate(year: Int, month: Int, day: Int): Triple<Int, Int, Int> {
        val cal = GregorianCalendar(UTC_TZ).apply {
            set(year, month - 1, day, 12, 0, 0)
            set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_MONTH, -1)
        }
        return Triple(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
    }

    private fun computeTamilSolarMonthStartDay(
        rasiIndex: Int,
        approxYear: Int,
        approxMonth: Int,
        location: PanchangamLocation
    ): Triple<Int, Int, Int> {
        val targetDeg = rasiIndex * 30.0
        val jdProbe = julianDayUtc(approxYear, approxMonth, 8, 0.0)
        val jdIngress = findTransitionJd(jdProbe, ::siderealSunLongitude, targetDeg, maxDays = 14.0)
            ?: return Triple(approxYear, approxMonth, 14)

        val tz = TimeZone.getTimeZone(location.timeZoneId)
        val cal = GregorianCalendar(tz).apply { timeInMillis = epochMsFromJd(jdIngress) }
        val iy = cal.get(Calendar.YEAR)
        val im = cal.get(Calendar.MONTH) + 1
        val id = cal.get(Calendar.DAY_OF_MONTH)
        val tzOff = getTimezoneOffsetHours(iy, im, id, location.timeZoneId)

        val ingLocalHr = cal.get(Calendar.HOUR_OF_DAY) +
            cal.get(Calendar.MINUTE) / 60.0 +
            cal.get(Calendar.SECOND) / 3600.0

        val (_, ssUt) = computeSunriseSunsetUtcHours(iy, im, id, location.latitude, location.longitude)
        val sunsetLocalHr = (ssUt ?: (18.0 - tzOff)) + tzOff

        // Traditional Tamil rule (Drik / Thirukanitha): ingress before local sunset -> that civil date is Day 1
        return if (ingLocalHr < sunsetLocalHr) {
            Triple(iy, im, id)
        } else {
            cal.add(Calendar.DAY_OF_MONTH, 1)
            Triple(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        }
    }

    fun computeTamilDate(
        year: Int,
        month: Int,
        day: Int,
        location: PanchangamLocation
    ): TamilDateInfo {
        val tzOff = getTimezoneOffsetHours(year, month, day, location.timeZoneId)
        val (_, ssUt) = computeSunriseSunsetUtcHours(year, month, day, location.latitude, location.longitude)
        val sunsetUt = ssUt ?: (18.0 - tzOff)
        val jdSunset = julianDayUtc(year, month, day, sunsetUt)

        // Sidereal solar rasi at local sunset determines the Tamil month for this civil date
        val sunAtSunset = siderealSunLongitude(jdSunset)
        val rasiIndex = (floor(sunAtSunset / 30.0).toInt()) % 12

        // DST-safe check for solar ingress occurring during this local civil day
        val (jdStartOfDayUtc, jdEndOfDayUtc) = localDayBoundsJdUtc(year, month, day, location.timeZoneId)
        val sunStart = siderealSunLongitude(jdStartOfDayUtc)
        val sunEnd = siderealSunLongitude(jdEndOfDayUtc)
        val rasiStart = floor(sunStart / 30.0).toInt() % 12
        val rasiEnd = floor(sunEnd / 30.0).toInt() % 12
        var sankrantiLabel: String? = null
        if (rasiStart != rasiEnd) {
            val daySpan = (jdEndOfDayUtc - jdStartOfDayUtc) + 0.05
            val jdIng = findTransitionJd(jdStartOfDayUtc, ::siderealSunLongitude, rasiEnd * 30.0, maxDays = daySpan)
            if (jdIng != null && jdIng >= jdStartOfDayUtc && jdIng < jdEndOfDayUtc) {
                val (fmt, _) = formatEventTimeWithRollover(jdIng, year, month, day, location.timeZoneId)
                val mName = TamilCalendarNames.TAMIL_MONTHS[rasiEnd]
                sankrantiLabel = "${mName.ta} / ${mName.en} Sankranti at $fmt"
            }
        }

        // Determine Gregorian year/month where this rasi ingress approximately happens
        val approxMonth = ((rasiIndex + 3) % 12) + 1 // Chithirai=4 .. Margazhi=12, Thai=1, Maasi=2, Panguni=3
        val approxYear = when {
            approxMonth == 12 && month == 1 -> year - 1
            approxMonth == 1 && month == 12 -> year + 1
            else -> year
        }

        val (sy, sm, sd) = computeTamilSolarMonthStartDay(rasiIndex, approxYear, approxMonth, location)
        val jdThis = julianDayUtc(year, month, day, 12.0)
        val jdMonthStart = julianDayUtc(sy, sm, sd, 12.0)
        val tamilDay = (jdThis - jdMonthStart).roundToInt() + 1

        // Tamil year increments on Chithirai 1 (rasiIndex == 0 in April).
        // Months Margazhi (8, during Jan 1-14), Thai (9), Maasi (10), Panguni (11)
        // in Gregorian Jan–Apr all belong to the Tamil year that began the previous April.
        val tamilCycleYear = if (month <= 4 && rasiIndex >= 8) year - 1 else year
        val tamilYearName = TamilCalendarNames.tamilYearForSolarYear(tamilCycleYear)
        val tamilMonthName = TamilCalendarNames.TAMIL_MONTHS[rasiIndex]

        return TamilDateInfo(
            tamilYearTa = tamilYearName.ta,
            tamilYearEn = tamilYearName.en,
            tamilMonthIndex = rasiIndex,
            tamilMonthTa = tamilMonthName.ta,
            tamilMonthEn = tamilMonthName.en,
            tamilDay = tamilDay.coerceIn(1, 32),
            sankrantiTodayFormatted = sankrantiLabel
        )
    }

    fun calculateDailyPanchangam(
        year: Int,
        month: Int,
        day: Int,
        location: PanchangamLocation
    ): DailyPanchangam {
        require(year in 1901..2099) { "Supported year range is 1901..2099" }
        require(month in 1..12) { "Invalid month: $month" }
        val maxDay = daysInGregorianMonth(year, month)
        require(day in 1..maxDay) { "Invalid day $day for $year-$month" }

        val tzOff = getTimezoneOffsetHours(year, month, day, location.timeZoneId)
        val tzLabel = formatTimezoneOffsetLabel(tzOff, location.timeZoneId)
        val (srUtOpt, ssUtOpt) = computeSunriseSunsetUtcHours(year, month, day, location.latitude, location.longitude)
        val isPolarFallback = (srUtOpt == null || ssUtOpt == null)
        val srUt = srUtOpt ?: (6.0 - tzOff)
        val ssUt = ssUtOpt ?: (18.0 - tzOff)

        val srLocal = srUt + tzOff
        val ssLocal = ssUt + tzOff

        // Evaluate all 5 Angams at local SUNRISE (Hindu Panchangam day convention)
        val jdSunrise = julianDayUtc(year, month, day, srUt)
        val sunSid = siderealSunLongitude(jdSunrise)
        val moonSid = siderealMoonLongitude(jdSunrise)
        val elong = norm360(moonSid - sunSid)

        val tithiIdx = floor(elong / 12.0).toInt() % 30
        val nextTithiIdx = (tithiIdx + 1) % 30
        val tithiEndJd = findTransitionJd(
            jdSunrise,
            { j -> norm360(siderealMoonLongitude(j) - siderealSunLongitude(j)) },
            norm360((tithiIdx + 1) * 12.0)
        )

        val nakSpanDeg = 360.0 / 27.0
        val nakIdx = floor(moonSid / nakSpanDeg).toInt() % 27
        val nextNakIdx = (nakIdx + 1) % 27
        val nakEndJd = findTransitionJd(
            jdSunrise,
            ::siderealMoonLongitude,
            norm360((nakIdx + 1) * nakSpanDeg)
        )

        val yogaIdx = floor(norm360(sunSid + moonSid) / nakSpanDeg).toInt() % 27
        val nextYogaIdx = (yogaIdx + 1) % 27
        val yogaEndJd = findTransitionJd(
            jdSunrise,
            { j -> norm360(siderealSunLongitude(j) + siderealMoonLongitude(j)) },
            norm360((yogaIdx + 1) * nakSpanDeg)
        )

        val karanaIdx = floor(elong / 6.0).toInt() % 60
        val nextKaranaIdx = (karanaIdx + 1) % 60
        val karanaEndJd = findTransitionJd(
            jdSunrise,
            { j -> norm360(siderealMoonLongitude(j) - siderealSunLongitude(j)) },
            norm360((karanaIdx + 1) * 6.0),
            maxDays = 1.2
        )

        fun buildSpan(
            idx: Int,
            cur: BilingualName,
            nxt: BilingualName,
            endJd: Double?,
            extraTa: String = "",
            extraEn: String = ""
        ): AngamSpan {
            if (endJd == null) {
                return AngamSpan(idx, cur.ta, cur.en, "—", false, nxt.ta, nxt.en, extraTa, extraEn)
            }
            val (timeStr, nextDay) = formatEventTimeWithRollover(endJd, year, month, day, location.timeZoneId)
            return AngamSpan(idx, cur.ta, cur.en, timeStr, nextDay, nxt.ta, nxt.en, extraTa, extraEn)
        }

        val isShukla = tithiIdx < 15
        val paksha = if (isShukla) TamilCalendarNames.PAKSHA_SHUKLA else TamilCalendarNames.PAKSHA_KRISHNA

        val tithiSpan = buildSpan(
            tithiIdx,
            TamilCalendarNames.TITHIS[tithiIdx],
            TamilCalendarNames.TITHIS[nextTithiIdx],
            tithiEndJd,
            extraTa = paksha.ta,
            extraEn = paksha.en
        )
        val nakSpan = buildSpan(
            nakIdx,
            TamilCalendarNames.NAKSHATRAS[nakIdx],
            TamilCalendarNames.NAKSHATRAS[nextNakIdx],
            nakEndJd
        )
        val yogaSpan = buildSpan(
            yogaIdx,
            TamilCalendarNames.YOGAS[yogaIdx],
            TamilCalendarNames.YOGAS[nextYogaIdx],
            yogaEndJd
        )
        val karanaSpan = buildSpan(
            karanaIdx,
            TamilCalendarNames.karanaForHalfTithi(karanaIdx),
            TamilCalendarNames.karanaForHalfTithi(nextKaranaIdx),
            karanaEndJd
        )

        // Rahu Kalam, Yamagandam, Gulikai (8 equal divisions of local daylight)
        val dow = dayOfWeekSundayZero(year, month, day)
        val daylight = (ssLocal - srLocal).coerceAtLeast(1.0)
        val eighth = daylight / 8.0

        fun daylightSlot(slot1Based: Int): TimeWindow {
            val s = srLocal + (slot1Based - 1) * eighth
            val e = srLocal + slot1Based * eighth
            return TimeWindow(formatLocalHours12(s), formatLocalHours12(e))
        }

        val rahu = daylightSlot(RAHU_SLOTS[dow])
        val yama = daylightSlot(YAMA_SLOTS[dow])
        val guli = daylightSlot(GULI_SLOTS[dow])

        // Vedic Brahma Muhurta: 14th muhurta of previous night (Ratrimana / 15)
        val (py, pm, pd) = previousCivilDate(year, month, day)
        val (_, prevSsUtOpt) = computeSunriseSunsetUtcHours(py, pm, pd, location.latitude, location.longitude)
        val prevSsUt = prevSsUtOpt ?: (18.0 - tzOff)
        val ratrimana = ((srUt + 24.0) - prevSsUt).coerceIn(4.0, 20.0)
        val nightMuhurta = ratrimana / 15.0
        val brahma = TimeWindow(
            formatLocalHours12(srLocal - 2.0 * nightMuhurta),
            formatLocalHours12(srLocal - 1.0 * nightMuhurta)
        )

        // Abhijit Muhurta: 8th muhurta of daylight (midpoint ± 1/30 of daylight)
        val midDay = (srLocal + ssLocal) / 2.0
        val abhijitHalf = daylight / 30.0
        val abhijit = TimeWindow(
            formatLocalHours12(midDay - abhijitHalf),
            formatLocalHours12(midDay + abhijitHalf)
        )

        val tamilDate = computeTamilDate(year, month, day, location)
        val isoDate = String.format(Locale.US, "%04d-%02d-%02d", year, month, day)
        val vara = TamilCalendarNames.WEEKDAYS[dow]

        val events = SabarimalaEventsCatalog.getEventsForDate(
            year = year,
            month = month,
            day = day,
            isoDate = isoDate,
            tamilDate = tamilDate,
            tithiIndex = tithiIdx,
            nakshatraIndex = nakIdx
        )

        val (guideTa, guideEn) = SabarimalaEventsCatalog.buildPilgrimGuidance(
            dow = dow,
            tithiIndex = tithiIdx,
            nakshatraIndex = nakIdx,
            events = events,
            rahu = rahu
        )

        val methodNoteTa = if (isPolarFallback) {
            "துருவப் பகுதி (Polar latitude): இந்தத் தேதியில் வழக்கமான சூரிய உதயம்/அஸ்தமனம் இல்லை; 06:00/18:00 குறிப்பு நேரம் பயன்படுத்தப்பட்டது."
        } else {
            "திருக்கணித (ICRC Lahiri Ayanamsa) உள்ளூர் சூரிய உதய அடிப்படைக் கணக்கீடு. வாக்கிய பஞ்சாங்கத்துடன் நிமிட வேறுபாடு இருக்கலாம்."
        }
        val methodNoteEn = if (isPolarFallback) {
            "Polar latitude notice: no standard sunrise/sunset occurs on this date; 06:00/18:00 reference fallback was used."
        } else {
            "Computed offline via Thirukanitha (ICRC Lahiri Ayanamsa) at local sunrise. Vakya almanacs may vary by a few minutes."
        }

        return DailyPanchangam(
            gregorianYear = year,
            gregorianMonth = month,
            gregorianDay = day,
            isoDate = isoDate,
            dayOfWeekIndex = dow,
            varaTa = vara.ta,
            varaEn = vara.en,
            location = location,
            timezoneOffsetLabel = tzLabel,
            tamilDate = tamilDate,
            sunriseFormatted = if (isPolarFallback) "06:00 AM*" else formatLocalHours12(srLocal),
            sunsetFormatted = if (isPolarFallback) "06:00 PM*" else formatLocalHours12(ssLocal),
            tithi = tithiSpan,
            pakshaTa = paksha.ta,
            pakshaEn = paksha.en,
            nakshatra = nakSpan,
            yoga = yogaSpan,
            karana = karanaSpan,
            rahuKalam = rahu,
            yamagandam = yama,
            gulikai = guli,
            brahmaMuhurta = brahma,
            abhijitMuhurta = abhijit,
            pilgrimGuidanceTa = guideTa,
            pilgrimGuidanceEn = guideEn,
            events = events,
            calculationMethodNoteTa = methodNoteTa,
            calculationMethodNoteEn = methodNoteEn,
            isPolarFallback = isPolarFallback
        )
    }
}
