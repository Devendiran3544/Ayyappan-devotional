package com.sabarimala.yatraguide.model

import org.json.JSONObject

enum class SongSourceType {
    ASSET,
    LOCAL_URI
}

data class SongItem(
    val id: String,
    val titleTa: String,
    val titleEn: String,
    val subtitleTa: String,
    val subtitleEn: String,
    val artist: String,
    val raga: String,
    val lyricsTa: String,
    val sourceType: SongSourceType,
    val uriString: String,
    val durationMs: Long = 0L,
    val isBundled: Boolean = true,
    val addedAt: Long = 0L
) {
    fun toJson(isFavorite: Boolean = false): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("titleTa", titleTa)
            put("titleEn", titleEn)
            put("subtitleTa", subtitleTa)
            put("subtitleEn", subtitleEn)
            put("artist", artist)
            put("raga", raga)
            put("lyricsTa", lyricsTa)
            put("sourceType", sourceType.name)
            put("uriString", uriString)
            put("durationMs", durationMs)
            put("isBundled", isBundled)
            put("addedAt", addedAt)
            put("isFavorite", isFavorite)
        }
    }

    companion object {
        fun fromJson(obj: JSONObject): SongItem? {
            val id = obj.optString("id", "").trim()
            val uri = obj.optString("uriString", "").trim()
            if (id.isEmpty() || uri.isEmpty()) return null
            val sourceName = obj.optString("sourceType", SongSourceType.LOCAL_URI.name)
            val source = try {
                SongSourceType.valueOf(sourceName)
            } catch (_: Exception) {
                SongSourceType.LOCAL_URI
            }
            return SongItem(
                id = id,
                titleTa = obj.optString("titleTa", id),
                titleEn = obj.optString("titleEn", id),
                subtitleTa = obj.optString("subtitleTa", ""),
                subtitleEn = obj.optString("subtitleEn", ""),
                artist = obj.optString("artist", "Sabarimala Devotional"),
                raga = obj.optString("raga", ""),
                lyricsTa = obj.optString("lyricsTa", ""),
                sourceType = source,
                uriString = uri,
                durationMs = obj.optLong("durationMs", 0L),
                isBundled = obj.optBoolean("isBundled", false),
                addedAt = obj.optLong("addedAt", 0L)
            )
        }
    }
}
