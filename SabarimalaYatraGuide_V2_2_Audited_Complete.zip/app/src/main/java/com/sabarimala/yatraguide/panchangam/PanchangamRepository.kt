package com.sabarimala.yatraguide.panchangam

import com.sabarimala.yatraguide.data.YatraPreferencesStore
import org.json.JSONArray
import org.json.JSONObject

class PanchangamRepository(
    private val store: YatraPreferencesStore
) {
    private val dayCache = object : LinkedHashMap<String, DailyPanchangam>(96, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, DailyPanchangam>?): Boolean {
            return size > MAX_DAY_CACHE
        }
    }

    private val monthCache = object : LinkedHashMap<String, MonthCalendarGrid>(12, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, MonthCalendarGrid>?): Boolean {
            return size > MAX_MONTH_CACHE
        }
    }

    fun getSelectedLocation(): PanchangamLocation {
        return PanchangamLocation.byId(store.getPanchangamLocationId())
    }

    fun setSelectedLocation(locationId: String): PanchangamLocation {
        val loc = PanchangamLocation.byId(locationId)
        store.setPanchangamLocationId(loc.id)
        return loc
    }

    fun getLocationsJson(): JSONObject {
        val selected = getSelectedLocation()
        val arr = JSONArray()
        PanchangamLocation.PRESET_LOCATIONS.forEach { arr.put(it.toJson()) }
        return JSONObject().apply {
            put("selectedLocationId", selected.id)
            put("locations", arr)
        }
    }

    @Synchronized
    fun getDailyPanchangam(
        year: Int,
        month: Int,
        day: Int,
        location: PanchangamLocation = getSelectedLocation()
    ): DailyPanchangam {
        val key = "$year-$month-$day-${location.id}-${location.timeZoneId}"
        dayCache[key]?.let { return it }
        val computed = AstronomicalCalculator.calculateDailyPanchangam(year, month, day, location)
        dayCache[key] = computed
        return computed
    }

    @Synchronized
    fun getCalendarMonth(
        year: Int,
        month: Int,
        location: PanchangamLocation = getSelectedLocation()
    ): MonthCalendarGrid {
        require(year in 1901..2099) { "Supported year range is 1901..2099" }
        require(month in 1..12) { "Invalid month: $month" }

        val key = "$year-$month-${location.id}-${location.timeZoneId}"
        monthCache[key]?.let { return it }

        val daysCount = AstronomicalCalculator.daysInGregorianMonth(year, month)
        val firstDow = AstronomicalCalculator.dayOfWeekSundayZero(year, month, 1)
        val cells = mutableListOf<CalendarDayCell>()
        val highlights = mutableListOf<Pair<String, PilgrimDayEvent>>()
        val seenHighlightIds = mutableSetOf<String>()
        val tamilMonthsTa = LinkedHashSet<String>()
        val tamilMonthsEn = LinkedHashSet<String>()
        val tamilYearsTa = LinkedHashSet<String>()
        val tamilYearsEn = LinkedHashSet<String>()

        for (d in 1..daysCount) {
            val p = getDailyPanchangam(year, month, d, location)
            tamilMonthsTa.add(p.tamilDate.tamilMonthTa)
            tamilMonthsEn.add(p.tamilDate.tamilMonthEn)
            tamilYearsTa.add(p.tamilDate.tamilYearTa)
            tamilYearsEn.add(p.tamilDate.tamilYearEn)

            val isOpen = SabarimalaEventsCatalog.isSabarimalaSeasonOpen(p.isoDate)
            val hasFasting = p.events.any { it.category == EventCategory.FASTING_VRATHAM }
            val hasFestival = p.events.any { it.category == EventCategory.FESTIVAL }

            cells.add(
                CalendarDayCell(
                    year = year,
                    month = month,
                    day = d,
                    isoDate = p.isoDate,
                    tamilDay = p.tamilDate.tamilDay,
                    tamilMonthTa = p.tamilDate.tamilMonthTa,
                    tamilMonthEn = p.tamilDate.tamilMonthEn,
                    tithiShortTa = p.tithi.nameTa,
                    tithiShortEn = p.tithi.nameEn,
                    isSabarimalaOpen = isOpen,
                    hasFastingDay = hasFasting,
                    hasMajorFestival = hasFestival,
                    isPournami = p.tithi.index == 14,
                    isAmavasya = p.tithi.index == 29
                )
            )

            for (ev in p.events) {
                if (ev.category == EventCategory.FESTIVAL || ev.category == EventCategory.FASTING_VRATHAM) {
                    val dedupeKey = "${p.isoDate}_${ev.id}"
                    if (seenHighlightIds.add(dedupeKey)) {
                        highlights.add(Pair(p.isoDate, ev))
                    }
                }
            }
        }

        val headerTa = "${tamilYearsTa.joinToString(" / ")} வருடம் • ${tamilMonthsTa.joinToString(" – ")}"
        val headerEn = "${tamilYearsEn.joinToString(" / ")} • ${tamilMonthsEn.joinToString(" – ")}"

        val grid = MonthCalendarGrid(
            year = year,
            month = month,
            firstDayOfWeek = firstDow,
            daysInMonth = daysCount,
            tamilHeaderTa = headerTa,
            tamilHeaderEn = headerEn,
            location = location,
            days = cells,
            monthHighlights = highlights
        )
        monthCache[key] = grid
        return grid
    }

    fun getDailyPanchangamJsonSafe(year: Int, month: Int, day: Int): String {
        return try {
            getDailyPanchangam(year, month, day).toJson().toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("ok", false)
                put("error", e.message ?: "Unable to calculate Panchangam for requested date")
            }.toString()
        }
    }

    fun getCalendarMonthJsonSafe(year: Int, month: Int): String {
        return try {
            getCalendarMonth(year, month).toJson().toString()
        } catch (e: Exception) {
            JSONObject().apply {
                put("ok", false)
                put("error", e.message ?: "Unable to calculate Tamil Calendar for requested month")
            }.toString()
        }
    }

    fun clearCache() {
        dayCache.clear()
        monthCache.clear()
    }

    companion object {
        private const val MAX_DAY_CACHE = 180
        private const val MAX_MONTH_CACHE = 18
    }
}
