package com.sabarimala.yatraguide.model

import org.json.JSONArray
import org.json.JSONObject

enum class AlertCategory(
    val id: String,
    val titleTa: String,
    val titleEn: String,
    val notificationCategory: NotificationCategory
) {
    TEMPLE_ANNOUNCEMENT(
        "temple_announcement",
        "கோவில் அறிவிப்புகள்",
        "Temple Announcements",
        NotificationCategory.IMPORTANT_ANNOUNCEMENTS
    ),
    TEMPLE_TIMING(
        "temple_timing",
        "நடை திறப்பு / அடைப்பு",
        "Opening & Closing",
        NotificationCategory.TEMPLE_UPDATES
    ),
    MANDALA_MAKARAVILAKKU(
        "mandala_makaravilakku",
        "மண்டல / மகரவிளக்கு",
        "Mandala & Makaravilakku",
        NotificationCategory.TEMPLE_UPDATES
    ),
    TRAVEL(
        "travel",
        "பயண எச்சரிக்கை",
        "Travel Alerts",
        NotificationCategory.TRAVEL_UPDATES
    ),
    ROUTE(
        "route",
        "பாதை நிலை",
        "Route Alerts",
        NotificationCategory.TRAVEL_UPDATES
    ),
    WEATHER(
        "weather",
        "வானிலை எச்சரிக்கை",
        "Weather Alerts",
        NotificationCategory.WEATHER_ALERTS
    ),
    CROWD(
        "crowd",
        "கூட்ட நிலை",
        "Crowd Alerts",
        NotificationCategory.TEMPLE_UPDATES
    ),
    EMERGENCY(
        "emergency",
        "அவசர எச்சரிக்கை",
        "Emergency Alerts",
        NotificationCategory.EMERGENCY_NOTIFICATIONS
    );

    companion object {
        fun fromId(id: String?): AlertCategory? = values().firstOrNull { it.id == id }
    }
}

enum class AlertSeverity {
    INFO,
    ADVISORY,
    WARNING,
    CRITICAL
}

enum class FeedAvailability {
    UNAVAILABLE_NO_TRUSTED_SOURCE,
    OFFLINE,
    LIVE_VERIFIED
}

data class YatraAlert(
    val id: String,
    val category: AlertCategory,
    val severity: AlertSeverity,
    val titleTa: String,
    val titleEn: String,
    val messageTa: String,
    val messageEn: String,
    val sourceName: String,
    val sourceUrl: String?,
    val publishedEpochMs: Long
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("id", id)
            put("category", category.id)
            put("categoryTitleTa", category.titleTa)
            put("categoryTitleEn", category.titleEn)
            put("severity", severity.name)
            put("titleTa", titleTa)
            put("titleEn", titleEn)
            put("messageTa", messageTa)
            put("messageEn", messageEn)
            put("sourceName", sourceName)
            put("sourceUrl", sourceUrl ?: JSONObject.NULL)
            put("publishedEpochMs", publishedEpochMs)
        }
    }
}

data class TrustedSourceReference(
    val nameTa: String,
    val nameEn: String,
    val roleTa: String,
    val roleEn: String,
    val url: String
) {
    fun toJson(): JSONObject {
        return JSONObject().apply {
            put("nameTa", nameTa)
            put("nameEn", nameEn)
            put("roleTa", roleTa)
            put("roleEn", roleEn)
            put("url", url)
        }
    }
}

data class UpdatesFeedStatus(
    val availability: FeedAvailability,
    val lastCheckedEpochMs: Long,
    val sourceName: String?,
    val statusMessageTa: String,
    val statusMessageEn: String,
    val alerts: List<YatraAlert>,
    val officialReferences: List<TrustedSourceReference>
) {
    fun toJson(): JSONObject {
        val alertsArr = JSONArray()
        alerts.forEach { alertsArr.put(it.toJson()) }
        val refsArr = JSONArray()
        officialReferences.forEach { refsArr.put(it.toJson()) }
        val categoriesArr = JSONArray()
        AlertCategory.values().forEach { cat ->
            categoriesArr.put(JSONObject().apply {
                put("id", cat.id)
                put("titleTa", cat.titleTa)
                put("titleEn", cat.titleEn)
            })
        }
        return JSONObject().apply {
            put("availability", availability.name)
            put("isLiveDataAvailable", availability == FeedAvailability.LIVE_VERIFIED)
            put("lastCheckedEpochMs", lastCheckedEpochMs)
            put("sourceName", sourceName ?: JSONObject.NULL)
            put("statusMessageTa", statusMessageTa)
            put("statusMessageEn", statusMessageEn)
            put("alerts", alertsArr)
            put("officialReferences", refsArr)
            put("categories", categoriesArr)
        }
    }
}
