package com.sabarimala.yatraguide.panchangam

/**
 * Audited Sabarimala & Ayyappan Devotional Events Catalog (V2.2):
 * 1) Astronomically derived fasting & devotional days for ANY year (Ekadashi, Pradosham,
 *    Shukla Sashti, Sankatahara Chaturthi, Pournami, Amavasya, Masik Karthigai,
 *    Ayyappan Uthram Star Day, Tamil Month Day 1).
 * 2) Published 2026 – Jan 2027 Sabarimala temple calendar schedules cross-checked across
 *    published TDB / Sabarimala pilgrim calendars.
 * Unconfirmed post-Jan-2027 TDB schedules are intentionally omitted rather than fabricated.
 */
object SabarimalaEventsCatalog {

    private data class DateRangeEvent(
        val startIso: String,
        val endIso: String,
        val event: PilgrimDayEvent
    )

    private fun monthlyPoojaRange(
        id: String,
        startIso: String,
        endIso: String,
        titleTa: String,
        titleEn: String,
        detailTa: String,
        detailEn: String
    ): DateRangeEvent = DateRangeEvent(
        startIso,
        endIso,
        PilgrimDayEvent(
            id = id,
            titleTa = titleTa,
            titleEn = titleEn,
            detailTa = detailTa,
            detailEn = detailEn,
            category = EventCategory.MONTHLY_POOJA,
            verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
            sourceNote = "Published 2026 Sabarimala Calendar (Confirm exact hours with TDB)"
        )
    )

    private val SABARIMALA_PUBLISHED_RANGES: List<DateRangeEvent> = listOf(
        monthlyPoojaRange("kumbham_2026", "2026-02-12", "2026-02-17", "மாசி / கும்பம் மாத பூஜை (சபரிமலை)", "Kumbham / Maasi Monthly Pooja", "பிப்ரவரி 12 மாலை 5 மணி முதல் பிப்ரவரி 17 இரவு வரை மாதாந்திர பூஜை.", "Monthly temple opening Feb 12 (5 PM) – Feb 17, 2026."),
        monthlyPoojaRange("meenam_2026", "2026-03-14", "2026-03-19", "பங்குனி / மீனம் மாத பூஜை (சபரிமலை)", "Meenam / Panguni Monthly Pooja", "மார்ச் 14 மாலை 5 மணி முதல் மார்ச் 19 வரை மாதாந்திர பூஜை.", "Monthly temple opening Mar 14 (5 PM) – Mar 19, 2026."),
        DateRangeEvent(
            "2026-03-22", "2026-04-01",
            PilgrimDayEvent(
                id = "panguni_utsavam_2026",
                titleTa = "பங்குனி உத்திரம் திருவிழா (சபரிமலை நடை திறப்பு)",
                titleEn = "Sabarimala Annual Utsavam (Panguni Uthram)",
                detailTa = "மார்ச் 22 கொடியேற்றம் முதல் ஏப்ரல் 1 பங்குனி உத்திரம் ஆராட்டு வரை 10 நாள் திருவிழா.",
                detailEn = "10-day annual Utsavam Mar 22 – Apr 1, 2026 concluding with Panguni Uthram Arattu.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026 Sabarimala Calendar (Confirm exact hours with TDB)"
            )
        ),
        monthlyPoojaRange("vishu_2026", "2026-04-11", "2026-04-18", "சித்திரை / மேட விஷு பூஜை (சபரிமலை)", "Meda Vishu & Chithirai Pooja", "ஏப்ரல் 11–18 வரை விஷு சிறப்பு தரிசனம் (விஷு கனி: ஏப்ரல் 15, 2026).", "Special Vishu opening Apr 11 – Apr 18, 2026 (Vishu Kani: Apr 15)."),
        monthlyPoojaRange("edavam_2026", "2026-05-14", "2026-05-19", "வைகாசி / எடவம் மாத பூஜை (சபரிமலை)", "Edavam / Vaikasi Monthly Pooja", "மே 14 மாலை 5 மணி முதல் மே 19 வரை மாதாந்திர பூஜை.", "Monthly opening May 14 – May 19, 2026."),
        monthlyPoojaRange("prathishta_2026", "2026-05-25", "2026-05-26", "பிரதிஷ்டை தின சிறப்பு பூஜை", "Prathishta Day Special Opening", "சபரிமலை பிரதிஷ்டை தின சிறப்பு பூஜை (மே 25–26, 2026).", "Prathishta Day special pooja May 25 – May 26, 2026."),
        monthlyPoojaRange("midhunam_2026", "2026-06-14", "2026-06-19", "ஆனி / மிதுனம் மாத பூஜை (சபரிமலை)", "Midhunam / Aani Monthly Pooja", "ஜூன் 14 மாலை 5 மணி முதல் ஜூன் 19 வரை மாதாந்திர பூஜை.", "Monthly opening Jun 14 – Jun 19, 2026."),
        monthlyPoojaRange("karkkidakam_2026", "2026-07-16", "2026-07-21", "ஆடி / கர்க்கிடகம் மாத பூஜை (சபரிமலை)", "Karkkidakam / Aadi Monthly Pooja", "ஜூலை 16 மாலை 5 மணி முதல் ஜூலை 21 வரை மாதாந்திர பூஜை.", "Monthly opening Jul 16 – Jul 21, 2026."),
        monthlyPoojaRange("chingam_2026", "2026-08-16", "2026-08-21", "ஆவணி / சிங்கம் மாத பூஜை (சபரிமலை)", "Chingam / Aavani Monthly Pooja", "ஆகஸ்ட் 16 மாலை 5 மணி முதல் ஆகஸ்ட் 21 வரை மாதாந்திர பூஜை.", "Monthly opening Aug 16 – Aug 21, 2026."),
        monthlyPoojaRange("onam_2026", "2026-08-24", "2026-08-28", "திருவோணம் சிறப்பு பூஜை (சபரிமலை)", "Onam Festival Special Pooja", "ஆகஸ்ட் 24–28 வரை திருவோணம் சிறப்பு தரிசனம் (திருவோணம்: ஆகஸ்ட் 26).", "Onam special opening Aug 24 – Aug 28, 2026 (Thiruvonam: Aug 26)."),
        monthlyPoojaRange("kanni_2026", "2026-09-16", "2026-09-21", "புரட்டாசி / கன்னி மாத பூஜை (சபரிமலை)", "Kanni / Purattasi Monthly Pooja", "செப்டம்பர் 16 மாலை 5 மணி முதல் செப்டம்பர் 21 வரை மாதாந்திர பூஜை.", "Monthly opening Sep 16 – Sep 21, 2026."),
        monthlyPoojaRange("thulam_2026", "2026-10-17", "2026-10-22", "ஐப்பசி / துலாம் மாத பூஜை (சபரிமலை)", "Thulam / Aippasi Monthly Pooja", "அக்டோபர் 17 மாலை 5 மணி முதல் அக்டோபர் 22 வரை மாதாந்திர பூஜை.", "Monthly opening Oct 17 – Oct 22, 2026."),
        monthlyPoojaRange("chithira_atta_2026", "2026-11-06", "2026-11-07", "சித்திரை ஆட்டத் திருநாள் சிறப்பு பூஜை", "Chithira Atta Thirunal Opening", "நவம்பர் 6 மாலை 5 மணி முதல் நவம்பர் 7 இரவு வரை சிறப்பு நடை திறப்பு.", "Special opening Nov 6 – Nov 7, 2026 for Chithira Atta Thirunal."),
        DateRangeEvent(
            "2026-11-16", "2026-12-27",
            PilgrimDayEvent(
                id = "mandala_season_2026",
                titleTa = "மண்டல பூஜை யாத்திரை காலம் (சபரிமலை நடை திறப்பு)",
                titleEn = "Mandala Pooja Pilgrimage Season (Temple Open)",
                detailTa = "2026 நவம்பர் 16 மாலை 5 மணிக்கு நடை திறந்து, டிசம்பர் 27 மண்டல பூஜையுடன் நிறைவு. தினசரி விரதம் மற்றும் இருமுடி தரிசனம்.",
                detailEn = "Shrine opens Nov 16, 2026 (5 PM) for the 41-day Mandala Kalam through Dec 27, 2026.",
                category = EventCategory.SABARIMALA_SEASON,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars (Confirm exact timings with TDB)"
            )
        ),
        DateRangeEvent(
            "2026-12-30", "2027-01-20",
            PilgrimDayEvent(
                id = "makaravilakku_season_2026_27",
                titleTa = "மகரவிளக்கு மஹோத்ஸவம் (சபரிமலை நடை திறப்பு)",
                titleEn = "Makaravilakku Mahotsavam (Temple Open)",
                detailTa = "2026 டிசம்பர் 30 மாலை 5 மணிக்கு நடை திறந்து, 2027 ஜனவரி 20 வரை மகரவிளக்கு தரிசனம்.",
                detailEn = "Shrine reopens Dec 30, 2026 (5 PM) and remains open through Jan 20, 2027.",
                category = EventCategory.SABARIMALA_SEASON,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars (Confirm exact timings with TDB)"
            )
        )
    )

    private val SPECIFIC_SABARIMALA_DATES: Map<String, List<PilgrimDayEvent>> = mapOf(
        "2026-04-01" to listOf(
            PilgrimDayEvent(
                id = "panguni_arattu_2026",
                titleTa = "பங்குனி உத்திரம் ஆராட்டு (பம்பை நதி)",
                titleEn = "Panguni Uthram Arattu at Pamba",
                detailTa = "சபரிமலை ஆண்டு திருவிழாவின் நிறைவு — பம்பையில் ஆராட்டு.",
                detailEn = "Culmination of the 2026 annual Sabarimala Utsavam with Arattu at Pamba.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026 Sabarimala Calendar"
            )
        ),
        "2026-11-16" to listOf(
            PilgrimDayEvent(
                id = "mandala_opening_2026",
                titleTa = "சபரிமலை மண்டல கால நடை திறப்பு (மாலை 5:00)",
                titleEn = "Sabarimala Mandala Season Opening (5:00 PM)",
                detailTa = "கார்த்திகை முதல் நாளுக்கு முந்தைய மாலை நடை திறப்பு; புதிய மேல்சாந்தி பொறுப்பேற்பு.",
                detailEn = "Shrine opens at 5 PM on the eve of Karthigai 1 / Vrischikam 1.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2026-11-17" to listOf(
            PilgrimDayEvent(
                id = "karthigai_1_vratham_2026",
                titleTa = "கார்த்திகை 1 — மண்டல விரதம் & மாலை அணிதல் ஆரம்பம்",
                titleEn = "Karthigai 1 — 41-Day Mandala Vratham Begins",
                detailTa = "சபரிமலை மண்டல காலத்தின் முதல் நாள்; பக்தர்கள் மாலை அணிந்து 41 நாள் விரதம் தொடங்கும் புனித நாள்.",
                detailEn = "Day 1 of the 41-day Mandala Kalam; auspicious day for Malayidal (wearing Ayyappan Mala).",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                sourceNote = "Verified Tamil Solar Ingress & Sabarimala Calendar"
            )
        ),
        "2026-12-23" to listOf(
            PilgrimDayEvent(
                id = "thanka_anki_start_2026",
                titleTa = "ஆரன்முளா தங்க அங்கி ஊர்வலம் தொடக்கம்",
                titleEn = "Thanka Anki Procession Starts from Aranmula",
                detailTa = "ஆரன்முளா பார்த்தசாரதி கோவிலில் இருந்து தங்க அங்கி ரத ஊர்வலம் சபரிமலை நோக்கி புறப்பாடு.",
                detailEn = "Sacred Golden Attire (Thanka Anki) procession departs Aranmula Parthasarathy Temple.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2026-12-26" to listOf(
            PilgrimDayEvent(
                id = "thanka_anki_arrival_2026",
                titleTa = "தங்க அங்கி சந்நிதானம் வருகை & தீபாராதனை",
                titleEn = "Thanka Anki Arrival & Deeparadhana at Sannidhanam",
                detailTa = "மாலை தங்க அங்கி சந்நிதானம் அடைந்து சிறப்பு தீபாராதனை நடைபெறும்.",
                detailEn = "Thanka Anki reaches Sannidhanam in the evening for ceremonial Deeparadhana.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2026-12-27" to listOf(
            PilgrimDayEvent(
                id = "mandala_pooja_2026",
                titleTa = "மண்டல பூஜை (41-ஆம் நாள் நிறைவு)",
                titleEn = "Mandala Pooja (41st Day Culmination)",
                detailTa = "ஆரன்முளா தங்க அங்கி சாத்தப்பட்டு மண்டல பூஜை நடைபெறும். இரவு நடை அடைக்கப்பட்டு டிசம்பர் 30 மாலை மீண்டும் திறக்கும்.",
                detailEn = "Grand Mandala Pooja with Thanka Anki; shrine closes at night and reopens Dec 30.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Cross-verified: Drik Panchang & Sabarimala Calendars"
            )
        ),
        "2026-12-30" to listOf(
            PilgrimDayEvent(
                id = "makaravilakku_open_2026",
                titleTa = "மகரவிளக்கு கால நடை திறப்பு (மாலை 5:00)",
                titleEn = "Makaravilakku Season Reopening (5:00 PM)",
                detailTa = "மகரவிளக்கு மஹோத்ஸவத்திற்காக சபரிமலை நடை மீண்டும் திறக்கப்படும்.",
                detailEn = "Sabarimala shrine reopens at 5:00 PM for Makaravilakku Mahotsavam.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2027-01-11" to listOf(
            PilgrimDayEvent(
                id = "erumeli_petta_2027",
                titleTa = "எருமேலி பேட்டை துள்ளல் (அம்பலப்புழா & ஆலங்காடு)",
                titleEn = "Erumeli Petta Thullal (Ambalappuzha & Alangadu)",
                detailTa = "மகரவிளக்கு முன்னிட்டு பாரம்பரிய எருமேலி பேட்டை துள்ளல்.",
                detailEn = "Traditional Ambalappuzha & Alangadu Petta Thullal at Erumeli.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2027-01-12" to listOf(
            PilgrimDayEvent(
                id = "thiruvabharanam_2027",
                titleTa = "பந்தளம் திருவாபரண ஊர்வலம் புறப்பாடு",
                titleEn = "Thiruvabharanam Procession Departs Pandalam",
                detailTa = "பந்தளம் வலியகோயிக்கல் கோவிலில் இருந்து திருவாபரணப் பெட்டி ஊர்வலம் புறப்பாடு.",
                detailEn = "Sacred Thiruvabharanam ornaments procession departs Pandalam Palace for Sannidhanam.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2027-01-13" to listOf(
            PilgrimDayEvent(
                id = "pamba_vilakku_2027",
                titleTa = "பம்பை விளக்கு & பம்பை சத்யா",
                titleEn = "Pamba Vilakku & Pamba Sadya",
                detailTa = "மகரவிளக்கு முந்தைய நாள் பம்பையில் பாரம்பரிய சத்யா மற்றும் பம்பை விளக்கு.",
                detailEn = "Traditional Pamba Sadya feast and Pamba Vilakku on the eve of Makaravilakku.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        ),
        "2027-01-14" to listOf(
            PilgrimDayEvent(
                id = "makaravilakku_2027",
                titleTa = "மகரவிளக்கு / மகர சங்கிராந்தி பெயர்ச்சி",
                titleEn = "Makaravilakku Day & Makara Sankranti Transit",
                detailTa = "சபரிமலை கோவில் நாட்காட்டிகளில் மகரவிளக்கு ஜனவரி 14, 2027 எனக் குறிக்கப்பட்டுள்ளது. சூரியன் மகர ராசிக்குள் மாலை அஸ்தமனத்திற்குப் பிறகு (~9:14 PM IST) நுழைவதால் தை 1 / பொங்கல் ஜனவரி 15 அன்று வருகிறது. இறுதி நேரத்தை TDB அறிவிப்பில் உறுதிப்படுத்தவும்.",
                detailEn = "Temple calendars list Makaravilakku on Jan 14, 2027; solar ingress into Makara occurs after sunset (~9:14 PM IST), placing Tamil Thai 1 / Pongal on Jan 15. Confirm final ritual timings with TDB.",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Cross-verified: Drik Panchang (Transit 9:14 PM IST) & TDB Calendars"
            )
        ),
        "2027-01-15" to listOf(
            PilgrimDayEvent(
                id = "thai_pongal_2027",
                titleTa = "தை 1 — தைப்பொங்கல் & மகர சங்கிராந்தி புண்ணிய காலம்",
                titleEn = "Thai 1 — Thai Pongal & Makara Sankranti Punya Kaal",
                detailTa = "உத்தராயண புண்ணிய காலம் மற்றும் தை முதல் நாள் (மகர சங்கிராந்தி அஸ்தமனத்திற்குப் பிறகு நடந்ததால் தை 1 ஜனவரி 15).",
                detailEn = "First day of Tamil month Thai (Uttarayana Punya Kaal & Pongal observed on Jan 15, 2027).",
                category = EventCategory.FESTIVAL,
                verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                sourceNote = "Cross-verified: Astronomical Ingress & Drik Panchang"
            )
        ),
        "2027-01-20" to listOf(
            PilgrimDayEvent(
                id = "makaravilakku_close_2027",
                titleTa = "மகரவிளக்கு யாத்திரை நிறைவு (நடை அடைப்பு)",
                titleEn = "Makaravilakku Season Closing",
                detailTa = "பந்தள ராஜ பிரதிநிதி தரிசனத்திற்குப் பிறகு 2026–27 மகரவிளக்கு சீசன் நிறைவு.",
                detailEn = "Final day of the 2026–27 Mandala–Makaravilakku pilgrimage season.",
                category = EventCategory.SABARIMALA_SEASON,
                verificationStatus = VerificationStatus.VERIFIED_PUBLISHED_CALENDAR,
                sourceNote = "Published 2026–27 Sabarimala Calendars"
            )
        )
    )

    fun isSabarimalaSeasonOpen(isoDate: String): Boolean {
        return SABARIMALA_PUBLISHED_RANGES.any { isoDate >= it.startIso && isoDate <= it.endIso }
    }

    fun getEventsForDate(
        year: Int,
        month: Int,
        day: Int,
        isoDate: String,
        tamilDate: TamilDateInfo,
        tithiIndex: Int,
        nakshatraIndex: Int
    ): List<PilgrimDayEvent> {
        val list = mutableListOf<PilgrimDayEvent>()

        SPECIFIC_SABARIMALA_DATES[isoDate]?.let { list.addAll(it) }

        for (range in SABARIMALA_PUBLISHED_RANGES) {
            if (isoDate >= range.startIso && isoDate <= range.endIso) {
                list.add(range.event)
            }
        }

        if (tamilDate.tamilDay == 1) {
            val isThai = tamilDate.tamilMonthIndex == 9
            val isChithirai = tamilDate.tamilMonthIndex == 0
            if (!isThai || isoDate != "2027-01-15") {
                list.add(
                    PilgrimDayEvent(
                        id = "tamil_month_1_${year}_${month}_$day",
                        titleTa = if (isChithirai) "தமிழ் புத்தாண்டு — ${tamilDate.tamilYearTa} வருடம் (சித்திரை 1)"
                        else "${tamilDate.tamilMonthTa} 1 — மாதப் பிறப்பு",
                        titleEn = if (isChithirai) "Tamil New Year — ${tamilDate.tamilYearEn} (Chithirai 1)"
                        else "${tamilDate.tamilMonthEn} 1 — Tamil Month Begins",
                        detailTa = "மாதப் பிறப்பு பூஜை மற்றும் சபரிமலை மாத வழிபாட்டிற்கு உகந்த நாள்.",
                        detailEn = "First day of Tamil solar month ${tamilDate.tamilMonthEn}; auspicious for temple worship.",
                        category = EventCategory.FESTIVAL,
                        verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                        sourceNote = "Computed via Sidereal Solar Ingress (ICRC Lahiri)"
                    )
                )
            }
        }

        if (nakshatraIndex == 11) {
            list.add(
                PilgrimDayEvent(
                    id = "ayyappan_uthram_$isoDate",
                    titleTa = "உத்திரம் நட்சத்திரம் — சுவாமி ஐயப்பன் ஜென்ம நட்சத்திரம்",
                    titleEn = "Uthram Star — Lord Ayyappan Birth Nakshatra",
                    detailTa = "ஐயப்ப சுவாமிக்கு உகந்த உத்திரம் நட்சத்திரம். மாலை அணிதல் மற்றும் சிறப்பு பூஜைக்கு மிகச் சிறந்த நாள்.",
                    detailEn = "Auspicious monthly Uthram star sacred to Lord Ayyappan; ideal for Malayidal and special pooja.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Nakshatra at Local Sunrise"
                )
            )
        }

        if (nakshatraIndex == 2) {
            list.add(
                PilgrimDayEvent(
                    id = "krittika_$isoDate",
                    titleTa = "மாத கிருத்திகை விரதம்",
                    titleEn = "Masik Karthigai Vratham",
                    detailTa = "கார்த்திகை நட்சத்திர விரதம் மற்றும் தீப வழிபாட்டுக்கு உகந்த நாள்.",
                    detailEn = "Krittika Nakshatra fasting and lamp worship day.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Nakshatra at Local Sunrise"
                )
            )
        }

        if (tithiIndex == 10 || tithiIndex == 25) {
            list.add(
                PilgrimDayEvent(
                    id = "ekadashi_$isoDate",
                    titleTa = "ஏகாதசி விரதம்",
                    titleEn = "Ekadashi Fasting (Vratham)",
                    detailTa = "மகாவிஷ்ணு & ஹரிஹர சுதர் வழிபாட்டிற்கு உகந்த ஏகாதசி விரத நாள்.",
                    detailEn = "Sacred Ekadashi fasting day for spiritual discipline and Harihara worship.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        }

        if (tithiIndex == 12 || tithiIndex == 27) {
            list.add(
                PilgrimDayEvent(
                    id = "pradosham_$isoDate",
                    titleTa = "பிரதோஷம் (திரயோதசி)",
                    titleEn = "Pradosham (Trayodashi)",
                    detailTa = "மாலை பிரதோஷ கால வழிபாட்டிற்கு உகந்த நாள்.",
                    detailEn = "Sacred Trayodashi evening Pradosham worship day.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        }

        if (tithiIndex == 5) {
            list.add(
                PilgrimDayEvent(
                    id = "sashti_$isoDate",
                    titleTa = "சஷ்டி விரதம் (வளர்பிறை)",
                    titleEn = "Shukla Sashti Vratham",
                    detailTa = "வளர்பிறை சஷ்டி விரத நாள்.",
                    detailEn = "Shukla Paksha Shashthi fasting day.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        }

        if (tithiIndex == 18) {
            list.add(
                PilgrimDayEvent(
                    id = "sankatahara_$isoDate",
                    titleTa = "சங்கடஹர சதுர்த்தி",
                    titleEn = "Sankatahara Chaturthi",
                    detailTa = "கன்னிமூல கணபதி வழிபாட்டிற்கு உகந்த சங்கடஹர சதுர்த்தி.",
                    detailEn = "Sacred Krishna Chaturthi for Lord Ganapathi worship before yatra.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        }

        if (tithiIndex == 14) {
            list.add(
                PilgrimDayEvent(
                    id = "pournami_$isoDate",
                    titleTa = "பௌர்ணமி (முழு நிலவு)",
                    titleEn = "Pournami (Full Moon)",
                    detailTa = "பௌர்ணமி சிறப்பு பூஜை மற்றும் விரதத்திற்கு உகந்த நாள்.",
                    detailEn = "Full moon day auspicious for devotional chanting and lamp lighting.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        } else if (tithiIndex == 29) {
            list.add(
                PilgrimDayEvent(
                    id = "amavasya_$isoDate",
                    titleTa = "அமாவாசை",
                    titleEn = "Amavasya (New Moon)",
                    detailTa = "முன்னோர் தர்ப்பணம் மற்றும் பம்பை புனித நீராடலுக்கு உகந்த நாள்.",
                    detailEn = "New moon day sacred for ancestral rites (Tarpanam) and Pamba Snanam.",
                    category = EventCategory.FASTING_VRATHAM,
                    verificationStatus = VerificationStatus.VERIFIED_ASTRONOMICAL,
                    sourceNote = "Astronomical Tithi at Local Sunrise"
                )
            )
        }

        return list
    }

    fun buildPilgrimGuidance(
        dow: Int,
        tithiIndex: Int,
        nakshatraIndex: Int,
        events: List<PilgrimDayEvent>,
        rahu: TimeWindow
    ): Pair<String, String> {
        val isSaturday = (dow == 6)
        val isUthram = (nakshatraIndex == 11)
        val isSeasonOpen = events.any { it.category == EventCategory.SABARIMALA_SEASON || it.category == EventCategory.MONTHLY_POOJA }

        val taParts = mutableListOf<String>()
        val enParts = mutableListOf<String>()

        if (isSaturday || isUthram) {
            taParts.add("சனிக்கிழமை / உத்திரம் நட்சத்திரம் — மாலை அணிதல் (Malayidal) மற்றும் ஐயப்பன் பூஜைக்கு மிகவும் சிறப்பான நாள்.")
            enParts.add("Saturday / Uthram star — highly auspicious for wearing Ayyappan Mala and special pooja.")
        }
        if (isSeasonOpen) {
            taParts.add("சபரிமலை நடை திறந்திருக்கும் காலம்: Virtual Queue டிக்கெட் + அசல் ஆதார் அட்டையுடன் யாத்திரை மேற்கொள்ளவும்.")
            enParts.add("Sabarimala shrine open period: carry Virtual Queue pass and original Aadhaar ID.")
        }
        if (tithiIndex == 10 || tithiIndex == 25 || tithiIndex == 12 || tithiIndex == 27) {
            taParts.add("விரத நாள்: காலை பிரம்ம முகூர்த்தத்தில் நீராடி 108 சரண கோஷம் ஜபிப்பது சிறப்பு.")
            enParts.add("Fasting day: bathing during Brahma Muhurta and chanting 108 Saranam is auspicious.")
        }
        taParts.add("புதிய யாத்திரை / இருமுடி கட்டு தொடங்கும் முன் ராகு காலம் (${rahu.startFormatted} – ${rahu.endFormatted}) தவிர்ப்பது மரபு.")
        enParts.add("Traditionally avoid Rahu Kalam (${rahu.startFormatted} – ${rahu.endFormatted}) when starting Irumudi Kettu or new yatra travel.")

        return Pair(taParts.joinToString(" "), enParts.joinToString(" "))
    }
}
