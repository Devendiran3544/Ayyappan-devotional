package com.sabarimala.yatraguide.data

import com.sabarimala.yatraguide.model.AlertCategory
import com.sabarimala.yatraguide.model.FeedAvailability
import com.sabarimala.yatraguide.model.TrustedSourceReference
import com.sabarimala.yatraguide.model.UpdatesFeedStatus

/**
 * Contract for integrating verified live Sabarimala information feeds in future releases
 * (e.g., official Travancore Devaswom Board, Kerala Police Sabari Portal, IMD Kerala API).
 */
interface TrustedUpdatesProvider {
    fun fetchUpdates(): UpdatesFeedStatus
}

/**
 * Honest default provider used when no verified live backend endpoint is configured.
 * Strictly avoids fabricating live crowd numbers, weather alerts, or emergency notices.
 */
class DefaultOfflineUpdatesProvider(
    private val clock: () -> Long = { System.currentTimeMillis() }
) : TrustedUpdatesProvider {

    override fun fetchUpdates(): UpdatesFeedStatus {
        return UpdatesFeedStatus(
            availability = FeedAvailability.UNAVAILABLE_NO_TRUSTED_SOURCE,
            lastCheckedEpochMs = clock(),
            sourceName = null,
            statusMessageTa = "நம்பகமான நேரடி அரசு / தேவசம் போர்டு தரவு இணைப்பு தற்போது செயலில் இல்லை. தவறான கூட்ட அளவு அல்லது போலி எச்சரிக்கைகள் இங்கே காட்டப்படாது. சரிபார்க்கப்பட்ட நேரடி தகவல்களுக்கு கீழே உள்ள அதிகாரப்பூர்வ இணையதளங்களைப் பார்க்கவும்.",
            statusMessageEn = "Verified live data feed is currently unavailable. This app does not display fabricated crowd levels, weather warnings, or emergency alerts. Use the official reference portals below for live updates until a trusted feed endpoint is connected.",
            alerts = emptyList(),
            officialReferences = listOf(
                TrustedSourceReference(
                    nameTa = "சபரிமலை ஆன்லைன் தரிசனம் (TDB)",
                    nameEn = "Sabarimala Online Virtual Queue (TDB)",
                    roleTa = "அதிகாரப்பூர்வ தரிசன முன்பதிவு & கோவில் அறிவிப்புகள்",
                    roleEn = "Official Virtual Queue booking & temple announcements",
                    url = "https://sabarimalaonline.org"
                ),
                TrustedSourceReference(
                    nameTa = "கேரளா போலீஸ் — சபரிமலை போர்டல்",
                    nameEn = "Kerala Police — Sabarimala Pilgrim Portal",
                    roleTa = "நடைபாதை, பாதுகாப்பு, பார்க்கிங் & கூட்ட நிலை தகவல்கள்",
                    roleEn = "Route guidance, parking, safety & pilgrim advisories",
                    url = "https://sabarimala.keralapolice.gov.in"
                ),
                TrustedSourceReference(
                    nameTa = "இந்திய வானிலை ஆய்வு மையம் (IMD Kerala)",
                    nameEn = "India Meteorological Department (IMD Kerala)",
                    roleTa = "பத்தனம்திட்டா & சபரிமலை வானிலை எச்சரிக்கைகள்",
                    roleEn = "Verified Pathanamthitta & Sabarimala weather alerts",
                    url = "https://mausam.imd.gov.in/thiruvananthapuram/"
                ),
                TrustedSourceReference(
                    nameTa = "கேரளா KSRTC பேருந்து சேவை",
                    nameEn = "Kerala KSRTC Online Portal",
                    roleTa = "நிலக்கல் – பம்பை ஷட்டில் & சிறப்பு பேருந்துகள்",
                    roleEn = "Nilakkal–Pamba chain service & interstate buses",
                    url = "https://onlineksrtcswift.com"
                )
            )
        )
    }
}

class TrustedUpdatesRepository(
    private val provider: TrustedUpdatesProvider = DefaultOfflineUpdatesProvider()
) {
    fun getUpdates(categoryFilter: AlertCategory? = null): UpdatesFeedStatus {
        val status = provider.fetchUpdates()
        if (categoryFilter == null) return status
        return status.copy(alerts = status.alerts.filter { it.category == categoryFilter })
    }
}
