package com.sabarimala.yatraguide.data

import android.content.Context
import com.sabarimala.yatraguide.model.Playlist
import com.sabarimala.yatraguide.model.SongItem
import com.sabarimala.yatraguide.model.SongSourceType
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

interface BundledSongAssetProvider {
    fun listSongFileNames(): List<String>
    fun readCatalogJson(): String?
}

class AndroidAssetSongProvider(private val context: Context) : BundledSongAssetProvider {
    override fun listSongFileNames(): List<String> {
        return try {
            (context.assets.list("songs") ?: emptyArray())
                .filter { isSupportedAudioFile(it) }
                .sorted()
        } catch (_: Exception) {
            emptyList()
        }
    }

    override fun readCatalogJson(): String? {
        return try {
            context.assets.open("songs/catalog.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        } catch (_: Exception) {
            null
        }
    }

    companion object {
        private val SUPPORTED_EXTENSIONS = setOf(".wav", ".mp3", ".ogg", ".m4a", ".flac", ".aac")

        fun isSupportedAudioFile(fileName: String): Boolean {
            val lower = fileName.lowercase(Locale.ROOT)
            return SUPPORTED_EXTENSIONS.any { lower.endsWith(it) }
        }
    }
}

class SongLibraryRepository(
    private val assetProvider: BundledSongAssetProvider,
    private val store: YatraPreferencesStore
) {

    constructor(context: Context, store: YatraPreferencesStore) : this(
        AndroidAssetSongProvider(context.applicationContext),
        store
    )

    fun getBundledSongs(): List<SongItem> {
        val metadataByFile = parseCatalogMetadata(assetProvider.readCatalogJson())
        val discoveredFiles = assetProvider.listSongFileNames()
        val result = mutableListOf<SongItem>()

        // Preserve catalog order first for known songs
        val addedFiles = mutableSetOf<String>()
        for ((fileName, meta) in metadataByFile) {
            if (discoveredFiles.isEmpty() || discoveredFiles.contains(fileName)) {
                result.add(meta)
                addedFiles.add(fileName)
            }
        }

        // Auto-discover any future Ayyappan devotional audio files dropped into assets/songs/
        for (fileName in discoveredFiles) {
            if (addedFiles.contains(fileName)) continue
            val cleanTitle = fileName
                .substringBeforeLast('.')
                .replace('_', ' ')
                .replace('-', ' ')
                .trim()
                .ifEmpty { fileName }
            result.add(
                SongItem(
                    id = fileName,
                    titleTa = cleanTitle,
                    titleEn = cleanTitle,
                    subtitleTa = "சேர்க்கப்பட்ட பக்திப் பாடல் • ஆஃப்லைன்",
                    subtitleEn = "Bundled Devotional Track • Offline",
                    artist = "Sabarimala Devotional",
                    raga = "",
                    lyricsTa = "சுவாமியே சரணம் ஐயப்பா!",
                    sourceType = SongSourceType.ASSET,
                    uriString = "asset:///songs/$fileName",
                    durationMs = 0L,
                    isBundled = true,
                    addedAt = 0L
                )
            )
        }
        return result
    }

    fun getAllSongs(): List<SongItem> {
        return getBundledSongs() + store.getLocalSongs()
    }

    fun getSongById(songId: String): SongItem? {
        return getAllSongs().firstOrNull { it.id == songId }
    }

    fun searchSongs(query: String): List<SongItem> {
        val q = query.trim().lowercase(Locale.ROOT)
        val all = getAllSongs()
        if (q.isEmpty()) return all
        return all.filter { song ->
            song.titleTa.lowercase(Locale.ROOT).contains(q) ||
                song.titleEn.lowercase(Locale.ROOT).contains(q) ||
                song.subtitleTa.lowercase(Locale.ROOT).contains(q) ||
                song.subtitleEn.lowercase(Locale.ROOT).contains(q) ||
                song.artist.lowercase(Locale.ROOT).contains(q) ||
                song.raga.lowercase(Locale.ROOT).contains(q) ||
                song.lyricsTa.lowercase(Locale.ROOT).contains(q)
        }
    }

    fun getFavoriteSongs(): List<SongItem> {
        val favIds = store.getFavorites()
        return getAllSongs().filter { favIds.contains(it.id) }
    }

    fun getRecentlyPlayedSongs(): List<SongItem> {
        val byId = getAllSongs().associateBy { it.id }
        return store.getRecentlyPlayed().mapNotNull { byId[it] }
    }

    fun getSongsForPlaylist(playlistId: String): List<SongItem> {
        val playlist = store.getPlaylists().firstOrNull { it.id == playlistId } ?: return emptyList()
        val byId = getAllSongs().associateBy { it.id }
        return playlist.songIds.mapNotNull { byId[it] }
    }

    fun addLocalAudio(displayName: String, contentUri: String, durationMs: Long = 0L): SongItem {
        val cleanTitle = displayName
            .substringBeforeLast('.')
            .replace('_', ' ')
            .trim()
            .ifEmpty { "Devotional Audio" }
        val now = System.currentTimeMillis()
        val id = "local_${now}_${contentUri.hashCode()}"
        val item = SongItem(
            id = id,
            titleTa = cleanTitle,
            titleEn = cleanTitle,
            subtitleTa = "உங்கள் போனிலிருந்து சேர்க்கப்பட்ட பாடல் • ஆஃப்லைன்",
            subtitleEn = "Local Device Audio • Offline",
            artist = "My Devotional Library",
            raga = "",
            lyricsTa = "சுவாமியே சரணம் ஐயப்பா!

$cleanTitle",
            sourceType = SongSourceType.LOCAL_URI,
            uriString = contentUri,
            durationMs = durationMs,
            isBundled = false,
            addedAt = now
        )
        store.addLocalSong(item)
        return item
    }

    fun buildLibrarySnapshotJson(): JSONObject {
        val allSongs = getAllSongs()
        val favorites = store.getFavorites()
        val recentIds = store.getRecentlyPlayed()
        val playlists: List<Playlist> = store.getPlaylists()

        val songsArr = JSONArray()
        allSongs.forEach { songsArr.put(it.toJson(isFavorite = favorites.contains(it.id))) }

        val favArr = JSONArray()
        favorites.forEach { favArr.put(it) }

        val recentArr = JSONArray()
        recentIds.forEach { recentArr.put(it) }

        val plArr = JSONArray()
        playlists.forEach { plArr.put(it.toJson()) }

        return JSONObject().apply {
            put("songs", songsArr)
            put("favorites", favArr)
            put("recentlyPlayed", recentArr)
            put("playlists", plArr)
        }
    }

    private fun parseCatalogMetadata(catalogJson: String?): LinkedHashMap<String, SongItem> {
        val map = LinkedHashMap<String, SongItem>()
        if (catalogJson.isNullOrBlank()) return map
        try {
            val arr = JSONArray(catalogJson)
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val fileName = obj.optString("fileName", "").trim()
                if (fileName.isEmpty()) continue
                val id = obj.optString("id", fileName).trim().ifEmpty { fileName }
                map[fileName] = SongItem(
                    id = id,
                    titleTa = obj.optString("titleTa", fileName),
                    titleEn = obj.optString("titleEn", fileName),
                    subtitleTa = obj.optString("subtitleTa", ""),
                    subtitleEn = obj.optString("subtitleEn", ""),
                    artist = obj.optString("artist", "Sabarimala Devotional"),
                    raga = obj.optString("raga", ""),
                    lyricsTa = obj.optString("lyricsTa", ""),
                    sourceType = SongSourceType.ASSET,
                    uriString = "asset:///songs/$fileName",
                    durationMs = obj.optLong("durationMs", 0L),
                    isBundled = true,
                    addedAt = 0L
                )
            }
        } catch (_: Exception) {
        }
        return map
    }
}
