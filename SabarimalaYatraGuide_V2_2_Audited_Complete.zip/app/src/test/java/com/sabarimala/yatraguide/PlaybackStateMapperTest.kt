package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.audio.PlaybackStateMapper
import org.junit.Assert.assertEquals
import org.junit.Test

class PlaybackStateMapperTest {

    @Test
    fun repeatModesCycleCleanly() {
        assertEquals(PlaybackStateMapper.REPEAT_ALL, PlaybackStateMapper.nextRepeatMode(PlaybackStateMapper.REPEAT_OFF))
        assertEquals(PlaybackStateMapper.REPEAT_ONE, PlaybackStateMapper.nextRepeatMode(PlaybackStateMapper.REPEAT_ALL))
        assertEquals(PlaybackStateMapper.REPEAT_OFF, PlaybackStateMapper.nextRepeatMode(PlaybackStateMapper.REPEAT_ONE))
    }

    @Test
    fun clampResumePositionRestartsNearEnd() {
        assertEquals(12000L, PlaybackStateMapper.clampResumePosition(12000L, 35000L))
        assertEquals(0L, PlaybackStateMapper.clampResumePosition(34000L, 35000L))
        assertEquals(0L, PlaybackStateMapper.clampResumePosition(-500L, 35000L))
    }

    @Test
    fun formatsDurationsProperly() {
        assertEquals("0:00", PlaybackStateMapper.formatDurationMs(0L))
        assertEquals("0:09", PlaybackStateMapper.formatDurationMs(9000L))
        assertEquals("2:05", PlaybackStateMapper.formatDurationMs(125000L))
    }
}
