package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.util.SecurityValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityValidatorTest {

    @Test
    fun sanitizesPhoneNumbersAndRejectsInvalidInput() {
        assertEquals("04735-14432", SecurityValidator.sanitizePhoneNumber("04735-14432"))
        assertEquals("+91112", SecurityValidator.sanitizePhoneNumber("+91 112;drop"))
        assertNull(SecurityValidator.sanitizePhoneNumber("javascript:alert(1)"))
        assertNull(SecurityValidator.sanitizePhoneNumber("   "))
    }

    @Test
    fun enforcesHttpsOnlyExternalUrls() {
        assertTrue(SecurityValidator.isSafeHttpsUrl("https://sabarimalaonline.org"))
        assertTrue(SecurityValidator.isSafeHttpsUrl("https://mausam.imd.gov.in/thiruvananthapuram/"))
        assertFalse(SecurityValidator.isSafeHttpsUrl("http://example.com"))
        assertFalse(SecurityValidator.isSafeHttpsUrl("file:///etc/passwd"))
        assertFalse(SecurityValidator.isSafeHttpsUrl("javascript:alert(1)"))
        assertFalse(SecurityValidator.isSafeHttpsUrl("intent://scan/#Intent;end"))
    }

    @Test
    fun restrictsMapsBridgeToGoogleMapsHosts() {
        assertTrue(SecurityValidator.isSafeMapsUrl("https://www.google.com/maps/dir/?api=1&destination=Sabarimala"))
        assertTrue(SecurityValidator.isSafeMapsUrl("https://maps.google.com/?q=Sabarimala"))
        assertFalse(SecurityValidator.isSafeMapsUrl("https://evil.example.com/maps"))
        assertFalse(SecurityValidator.isSafeMapsUrl("content://com.android.contacts/data/1"))
    }

    @Test
    fun validatesExternalWebViewSchemes() {
        assertTrue(SecurityValidator.isAllowedWebViewExternalScheme("https"))
        assertTrue(SecurityValidator.isAllowedWebViewExternalScheme("tel"))
        assertFalse(SecurityValidator.isAllowedWebViewExternalScheme("file"))
        assertFalse(SecurityValidator.isAllowedWebViewExternalScheme("content"))
        assertFalse(SecurityValidator.isAllowedWebViewExternalScheme("javascript"))
    }
}
