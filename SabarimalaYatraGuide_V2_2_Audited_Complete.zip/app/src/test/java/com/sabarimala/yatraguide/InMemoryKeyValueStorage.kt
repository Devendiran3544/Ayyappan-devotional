package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.data.KeyValueStorage

class InMemoryKeyValueStorage : KeyValueStorage {
    private val map = mutableMapOf<String, Any?>()

    override fun getString(key: String, defaultValue: String?): String? =
        (map[key] as? String) ?: defaultValue

    override fun putString(key: String, value: String) {
        map[key] = value
    }

    override fun getBoolean(key: String, defaultValue: Boolean): Boolean =
        (map[key] as? Boolean) ?: defaultValue

    override fun putBoolean(key: String, value: Boolean) {
        map[key] = value
    }

    override fun getInt(key: String, defaultValue: Int): Int =
        (map[key] as? Int) ?: defaultValue

    override fun putInt(key: String, value: Int) {
        map[key] = value
    }

    override fun getLong(key: String, defaultValue: Long): Long =
        (map[key] as? Long) ?: defaultValue

    override fun putLong(key: String, value: Long) {
        map[key] = value
    }
}
