package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.data.YatraPreferencesStore
import com.sabarimala.yatraguide.panchangam.PanchangamLocation
import com.sabarimala.yatraguide.panchangam.PanchangamRepository
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class PanchangamRepositoryTest {

    private lateinit var store: YatraPreferencesStore
    private lateinit var repo: PanchangamRepository

    @Before
    fun setup() {
        store = YatraPreferencesStore(InMemoryKeyValueStorage())
        repo = PanchangamRepository(store)
    }

    @Test
    fun defaultsToSabarimalaAndPersistsLocationSelection() {
        assertEquals("sabarimala", repo.getSelectedLocation().id)
        repo.setSelectedLocation("chennai")
        assertEquals("chennai", repo.getSelectedLocation().id)
        assertEquals("chennai", store.getPanchangamLocationId())

        // Unknown location ID safely falls back to Sabarimala
        repo.setSelectedLocation("unknown_city")
        assertEquals(PanchangamLocation.SABARIMALA.id, repo.getSelectedLocation().id)
    }

    @Test
    fun monthCalendarNavigationAndCachingWorkOffline() {
        val dec2026 = repo.getCalendarMonth(2026, 12)
        assertEquals(31, dec2026.days.size)
        assertEquals(2026, dec2026.year)
        assertEquals(12, dec2026.month)
        assertTrue(dec2026.tamilHeaderEn.contains("Karthigai"))
        assertTrue(dec2026.tamilHeaderEn.contains("Margazhi"))

        // Second call hits LRU cache
        val cached = repo.getCalendarMonth(2026, 12)
        assertSame(dec2026, cached)

        // Navigate across year boundary to Jan 2027
        val jan2027 = repo.getCalendarMonth(2027, 1)
        assertEquals(31, jan2027.days.size)
        assertTrue(jan2027.days[13].hasMajorFestival) // Jan 14 Makaravilakku
        assertTrue(jan2027.days[14].hasMajorFestival) // Jan 15 Thai 1 / Pongal
    }

    @Test
    fun dailyPanchangamJsonIncludesSabarimalaEventsAndHandlesInvalidDatesGracefully() {
        val mandalaJson = JSONObject(repo.getDailyPanchangamJsonSafe(2026, 12, 27))
        assertTrue(mandalaJson.getBoolean("ok"))
        val events = mandalaJson.getJSONArray("events")
        assertTrue(events.length() >= 2)

        val invalidDate = JSONObject(repo.getDailyPanchangamJsonSafe(2026, 2, 31))
        assertFalse(invalidDate.getBoolean("ok"))
        assertTrue(invalidDate.getString("error").isNotEmpty())

        val invalidMonth = JSONObject(repo.getCalendarMonthJsonSafe(2026, 13))
        assertFalse(invalidMonth.getBoolean("ok"))
    }
}
