package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.data.TrustedUpdatesProvider
import com.sabarimala.yatraguide.data.TrustedUpdatesRepository
import com.sabarimala.yatraguide.model.AlertCategory
import com.sabarimala.yatraguide.model.AlertSeverity
import com.sabarimala.yatraguide.model.FeedAvailability
import com.sabarimala.yatraguide.model.UpdatesFeedStatus
import com.sabarimala.yatraguide.model.YatraAlert
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TrustedUpdatesRepositoryTest {

    @Test
    fun defaultProviderNeverFabricatesLiveAlerts() {
        val repo = TrustedUpdatesRepository()
        val status = repo.getUpdates()

        assertEquals(FeedAvailability.UNAVAILABLE_NO_TRUSTED_SOURCE, status.availability)
        assertTrue(status.alerts.isEmpty())
        assertTrue(status.officialReferences.isNotEmpty())
    }

    @Test
    fun customTrustedProviderSupportsCategoryFiltering() {
        val customProvider = object : TrustedUpdatesProvider {
            override fun fetchUpdates(): UpdatesFeedStatus {
                return UpdatesFeedStatus(
                    availability = FeedAvailability.LIVE_VERIFIED,
                    lastCheckedEpochMs = 1700000000000L,
                    sourceName = "Official TDB Feed",
                    statusMessageTa = "நேரடி தகவல்",
                    statusMessageEn = "Live verified feed",
                    alerts = listOf(
                        YatraAlert(
                            id = "a1",
                            category = AlertCategory.WEATHER,
                            severity = AlertSeverity.WARNING,
                            titleTa = "மழை எச்சரிக்கை",
                            titleEn = "Rain Advisory",
                            messageTa = "மலைப்பாதையில் கனமழை",
                            messageEn = "Heavy rain on hill route",
                            sourceName = "IMD Kerala",
                            sourceUrl = "https://mausam.imd.gov.in",
                            publishedEpochMs = 1700000000000L
                        ),
                        YatraAlert(
                            id = "a2",
                            category = AlertCategory.TEMPLE_TIMING,
                            severity = AlertSeverity.INFO,
                            titleTa = "நடை திறப்பு",
                            titleEn = "Temple Opening",
                            messageTa = "காலை 3 மணிக்கு நடை திறப்பு",
                            messageEn = "Opens at 3 AM",
                            sourceName = "TDB",
                            sourceUrl = "https://sabarimalaonline.org",
                            publishedEpochMs = 1700000000000L
                        )
                    ),
                    officialReferences = emptyList()
                )
            }
        }

        val repo = TrustedUpdatesRepository(customProvider)
        assertEquals(2, repo.getUpdates().alerts.size)
        val weatherOnly = repo.getUpdates(AlertCategory.WEATHER)
        assertEquals(1, weatherOnly.alerts.size)
        assertEquals("a1", weatherOnly.alerts.first().id)
    }
}
