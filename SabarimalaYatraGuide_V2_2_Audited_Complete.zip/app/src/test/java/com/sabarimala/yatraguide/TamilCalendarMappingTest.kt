package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.panchangam.AstronomicalCalculator
import com.sabarimala.yatraguide.panchangam.PanchangamLocation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class TamilCalendarMappingTest {

    private val sabarimala = PanchangamLocation.SABARIMALA

    @Test
    fun tamilMonthStartsMatchParabhava2026_2027PublishedCalendar() {
        val chithirai1 = AstronomicalCalculator.computeTamilDate(2026, 4, 14, sabarimala)
        assertEquals("Parabhava", chithirai1.tamilYearEn)
        assertEquals("பராபவ", chithirai1.tamilYearTa)
        assertEquals("Chithirai", chithirai1.tamilMonthEn)
        assertEquals(1, chithirai1.tamilDay)
        assertNotNull(chithirai1.sankrantiTodayFormatted)

        val karthigai1 = AstronomicalCalculator.computeTamilDate(2026, 11, 17, sabarimala)
        assertEquals("Karthigai", karthigai1.tamilMonthEn)
        assertEquals(1, karthigai1.tamilDay)

        val karthigai12 = AstronomicalCalculator.computeTamilDate(2026, 11, 28, sabarimala)
        assertEquals("Karthigai", karthigai12.tamilMonthEn)
        assertEquals(12, karthigai12.tamilDay)

        val margazhi1 = AstronomicalCalculator.computeTamilDate(2026, 12, 16, sabarimala)
        assertEquals("Margazhi", margazhi1.tamilMonthEn)
        assertEquals(1, margazhi1.tamilDay)

        val margazhi12 = AstronomicalCalculator.computeTamilDate(2026, 12, 27, sabarimala)
        assertEquals("Margazhi", margazhi12.tamilMonthEn)
        assertEquals(12, margazhi12.tamilDay)
    }

    @Test
    fun tamilYearRemainsContinuousAcrossJan1ToJan14Margazhi() {
        // Regression test for Audit Bug #1:
        // Jan 1–14, 2027 are Margazhi 17–30 of Parabhava (NOT Pilavanga!)
        val jan1 = AstronomicalCalculator.computeTamilDate(2027, 1, 1, sabarimala)
        assertEquals("Parabhava", jan1.tamilYearEn)
        assertEquals("Margazhi", jan1.tamilMonthEn)
        assertEquals(17, jan1.tamilDay)

        val jan14 = AstronomicalCalculator.computeTamilDate(2027, 1, 14, sabarimala)
        assertEquals("Parabhava", jan14.tamilYearEn)
        assertEquals("Margazhi", jan14.tamilMonthEn)
        assertEquals(30, jan14.tamilDay)
        assertNotNull(jan14.sankrantiTodayFormatted)
        assertTrue(jan14.sankrantiTodayFormatted!!.contains("09:14 PM"))

        val jan15 = AstronomicalCalculator.computeTamilDate(2027, 1, 15, sabarimala)
        assertEquals("Parabhava", jan15.tamilYearEn)
        assertEquals("Thai", jan15.tamilMonthEn)
        assertEquals(1, jan15.tamilDay)
    }

    @Test
    fun tamilNewYearTransitionsFromParabhavaToPilavangaOnApr14_2027() {
        val panguniLast = AstronomicalCalculator.computeTamilDate(2027, 4, 13, sabarimala)
        assertEquals("Parabhava", panguniLast.tamilYearEn)
        assertEquals("Panguni", panguniLast.tamilMonthEn)

        val pilavanga1 = AstronomicalCalculator.computeTamilDate(2027, 4, 14, sabarimala)
        assertEquals("Pilavanga", pilavanga1.tamilYearEn)
        assertEquals("Chithirai", pilavanga1.tamilMonthEn)
        assertEquals(1, pilavanga1.tamilDay)
    }
}
