package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.data.BundledSongAssetProvider
import com.sabarimala.yatraguide.data.SongLibraryRepository
import com.sabarimala.yatraguide.data.YatraPreferencesStore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class SongLibraryRepositoryTest {

    private lateinit var store: YatraPreferencesStore
    private lateinit var repository: SongLibraryRepository

    private val fakeCatalog = """
        [
          {
            "id": "01_swamiye_saranam_108.wav",
            "fileName": "01_swamiye_saranam_108.wav",
            "titleTa": "சுவாமியே சரணம் ஐயப்பா",
            "titleEn": "Swamiye Saranam Ayyappa",
            "subtitleTa": "மத்யமாவதி",
            "subtitleEn": "Madhyamavati",
            "artist": "Devotional",
            "raga": "Madhyamavati",
            "durationMs": 33500,
            "lyricsTa": "சுவாமியே சரணம் ஐயப்பா"
          }
        ]
    """.trimIndent()

    @Before
    fun setup() {
        store = YatraPreferencesStore(InMemoryKeyValueStorage())
        val fakeAssets = object : BundledSongAssetProvider {
            override fun listSongFileNames(): List<String> = listOf(
                "01_swamiye_saranam_108.wav",
                "07_future_ayyappa_song.mp3"
            )
            override fun readCatalogJson(): String = fakeCatalog
        }
        repository = SongLibraryRepository(fakeAssets, store)
    }

    @Test
    fun discoversCatalogAndFutureBundledSongs() {
        val bundled = repository.getBundledSongs()
        assertEquals(2, bundled.size)
        assertEquals("Swamiye Saranam Ayyappa", bundled[0].titleEn)
        assertEquals("07 future ayyappa song", bundled[1].titleEn)
        assertEquals("asset:///songs/07_future_ayyappa_song.mp3", bundled[1].uriString)
    }

    @Test
    fun supportsLocalSongsSearchFavoritesAndPlaylists() {
        val local = repository.addLocalAudio("Harivarasanam_Live.mp3", "content://media/audio/123")
        assertEquals(3, repository.getAllSongs().size)

        val tamilResults = repository.searchSongs("சுவாமியே")
        assertEquals(1, tamilResults.size)

        val localResults = repository.searchSongs("Harivarasanam")
        assertEquals(1, localResults.size)
        assertEquals(local.id, localResults.first().id)

        store.toggleFavorite(local.id)
        assertEquals(1, repository.getFavoriteSongs().size)

        val pl = store.createPlaylist("Yatra Mix")!!
        store.addSongToPlaylist(pl.id, local.id)
        assertEquals(1, repository.getSongsForPlaylist(pl.id).size)

        assertTrue(store.removeLocalSong(local.id))
        assertEquals(2, repository.getAllSongs().size)
        assertTrue(repository.getFavoriteSongs().isEmpty())
    }
}
