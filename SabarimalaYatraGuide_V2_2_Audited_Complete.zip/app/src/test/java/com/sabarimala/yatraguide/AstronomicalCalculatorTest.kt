package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.panchangam.AstronomicalCalculator
import com.sabarimala.yatraguide.panchangam.PanchangamLocation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AstronomicalCalculatorTest {

    @Test
    fun sunriseSunsetRahuYamaGulikaiMatchNewDelhiDec27_2026() {
        val delhi = PanchangamLocation.byId("new_delhi")
        val p = AstronomicalCalculator.calculateDailyPanchangam(2026, 12, 27, delhi)

        // Cross-checked against Drik Panchang (New Delhi Dec 27, 2026)
        assertEquals("07:12 AM", p.sunriseFormatted)
        assertEquals("05:32 PM", p.sunsetFormatted)
        assertEquals("04:15 PM", p.rahuKalam.startFormatted)
        assertEquals("05:32 PM", p.rahuKalam.endFormatted)
        assertEquals("12:22 PM", p.yamagandam.startFormatted)
        assertEquals("01:40 PM", p.yamagandam.endFormatted)
        assertEquals("02:57 PM", p.gulikai.startFormatted)
        assertEquals("04:15 PM", p.gulikai.endFormatted)
        // Ratrimana Brahma Muhurta (winter ~54 min muhurta vs spring ~44 min)
        assertEquals("05:23 AM", p.brahmaMuhurta.startFormatted)
        assertEquals("06:17 AM", p.brahmaMuhurta.endFormatted)
        assertFalse(p.isPolarFallback)
    }

    @Test
    fun brahmaMuhurtaAdaptsToSpringNightLength() {
        val delhi = PanchangamLocation.byId("new_delhi")
        val p = AstronomicalCalculator.calculateDailyPanchangam(2026, 4, 14, delhi)
        assertEquals("05:57 AM", p.sunriseFormatted)
        assertEquals("06:46 PM", p.sunsetFormatted)
        assertEquals("04:28 AM", p.brahmaMuhurta.startFormatted)
        assertEquals("05:12 AM", p.brahmaMuhurta.endFormatted)
    }

    @Test
    fun tithiNakshatraYogaKaranaMatchDrikPanchangDec27_2026() {
        val sabarimala = PanchangamLocation.SABARIMALA
        val p = AstronomicalCalculator.calculateDailyPanchangam(2026, 12, 27, sabarimala)

        assertEquals(18, p.tithi.index)
        assertEquals("Chaturthi", p.tithi.nameEn)
        assertEquals("சதுர்த்தி", p.tithi.nameTa)
        assertEquals("05:14 PM", p.tithi.endTimeFormatted)
        assertFalse(p.tithi.endsNextDay)

        assertEquals(8, p.nakshatra.index)
        assertEquals("Ashlesha", p.nakshatra.nameEn)
        assertEquals("ஆயில்யம்", p.nakshatra.nameTa)
        assertEquals("06:05 PM", p.nakshatra.endTimeFormatted)

        assertEquals(0, p.yoga.index)
        assertEquals("Vishkambha", p.yoga.nameEn)
        assertEquals("08:54 PM", p.yoga.endTimeFormatted)

        assertEquals("Balava", p.karana.nameEn)
        assertEquals("Sunday", p.varaEn)
    }

    @Test
    fun panchangamRespectsLocalSunriseRuleAcrossLocations() {
        // On Nov 28, 2026, Krishna Chaturthi ends ~06:40 AM IST.
        // Sabarimala sunrise is 06:21 AM IST -> Krishna Chaturthi.
        // New Delhi sunrise is 06:54 AM IST -> Krishna Panchami.
        val sabarimala = AstronomicalCalculator.calculateDailyPanchangam(
            2026, 11, 28, PanchangamLocation.SABARIMALA
        )
        val delhi = AstronomicalCalculator.calculateDailyPanchangam(
            2026, 11, 28, PanchangamLocation.byId("new_delhi")
        )

        assertEquals(18, sabarimala.tithi.index)
        assertEquals(19, delhi.tithi.index)
        assertNotEquals(sabarimala.sunriseFormatted, delhi.sunriseFormatted)
    }

    @Test
    fun midnightRoundingRolloverMarksNextDayConsistently() {
        // 2026-12-27 23:59:45 IST = 18:29:45 UTC -> rounds to 12:00 AM on Dec 28 (next day!)
        val jdUtc = AstronomicalCalculator.julianDayUtc(2026, 12, 27, 18.0 + 29.0 / 60.0 + 45.0 / 3600.0)
        val (formatted, isNextDay) = AstronomicalCalculator.formatEventTimeWithRollover(
            jdUtc, 2026, 12, 27, "Asia/Kolkata"
        )
        assertEquals("12:00 AM", formatted)
        assertTrue(isNextDay)
    }

    @Test
    fun handlesDstTransitionsLeapYearAndPolarLatitudesGracefully() {
        val nyc = PanchangamLocation("nyc", "நியூயார்க்", "New York", 40.7128, -74.0060, "America/New_York")
        val springForward = AstronomicalCalculator.calculateDailyPanchangam(2026, 3, 8, nyc)
        val fallBack = AstronomicalCalculator.calculateDailyPanchangam(2026, 11, 1, nyc)
        assertNotNull(springForward.sunriseFormatted)
        assertNotNull(fallBack.sunriseFormatted)

        // Leap year Feb 29
        val leapDay = AstronomicalCalculator.calculateDailyPanchangam(2028, 2, 29, PanchangamLocation.SABARIMALA)
        assertEquals("2028-02-29", leapDay.isoDate)
        assertEquals(29, AstronomicalCalculator.daysInGregorianMonth(2028, 2))
        assertEquals(28, AstronomicalCalculator.daysInGregorianMonth(2026, 2))

        // Polar latitude winter (Svalbard 78.22N, Dec 21 -> polar night)
        val svalbard = PanchangamLocation("svalbard", "ஸ்வால்பார்ட்", "Svalbard", 78.2232, 15.6267, "Europe/Oslo")
        val polarDay = AstronomicalCalculator.calculateDailyPanchangam(2026, 12, 21, svalbard)
        assertTrue(polarDay.isPolarFallback)
        assertTrue(polarDay.calculationMethodNoteEn.contains("Polar"))
    }
}
