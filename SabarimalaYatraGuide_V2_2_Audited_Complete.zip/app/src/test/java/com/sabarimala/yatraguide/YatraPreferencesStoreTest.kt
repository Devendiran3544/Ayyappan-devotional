package com.sabarimala.yatraguide

import com.sabarimala.yatraguide.data.YatraPreferencesStore
import com.sabarimala.yatraguide.model.NotificationCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class YatraPreferencesStoreTest {

    private lateinit var store: YatraPreferencesStore

    @Before
    fun setup() {
        store = YatraPreferencesStore(InMemoryKeyValueStorage())
    }

    @Test
    fun favoritesTogglePersistsCorrectly() {
        assertTrue(store.toggleFavorite("song_1"))
        assertTrue(store.getFavorites().contains("song_1"))

        assertFalse(store.toggleFavorite("song_1"))
        assertFalse(store.getFavorites().contains("song_1"))
    }

    @Test
    fun recentlyPlayedDeduplicatesAndCapsAtMax() {
        for (i in 1..35) {
            store.addRecentlyPlayed("song_$i")
        }
        val recent = store.getRecentlyPlayed()
        assertEquals(YatraPreferencesStore.MAX_RECENT_SONGS, recent.size)
        assertEquals("song_35", recent.first())

        store.addRecentlyPlayed("song_20")
        assertEquals("song_20", store.getRecentlyPlayed().first())
        assertEquals(YatraPreferencesStore.MAX_RECENT_SONGS, store.getRecentlyPlayed().size)
    }

    @Test
    fun playlistCrudWorks() {
        val pl = store.createPlaylist("Morning Yatra", nowMs = 1000L)
        assertNotNull(pl)
        val plId = pl!!.id

        assertTrue(store.addSongToPlaylist(plId, "01_swamiye_saranam_108.wav"))
        assertTrue(store.addSongToPlaylist(plId, "02_harivarasanam_madhyamavati.wav"))
        // Adding duplicate should not create duplicate entry
        assertTrue(store.addSongToPlaylist(plId, "01_swamiye_saranam_108.wav"))

        val loaded = store.getPlaylists().first { it.id == plId }
        assertEquals(2, loaded.songIds.size)

        assertTrue(store.removeSongFromPlaylist(plId, "01_swamiye_saranam_108.wav"))
        assertEquals(1, store.getPlaylists().first { it.id == plId }.songIds.size)

        assertTrue(store.deletePlaylist(plId))
        assertTrue(store.getPlaylists().isEmpty())
    }

    @Test
    fun playbackAndNotificationPreferencesPersist() {
        store.savePlaybackState("song_2", 14500L, shuffleEnabled = true, repeatMode = 1)
        val state = store.getPlaybackState()
        assertEquals("song_2", state.lastSongId)
        assertEquals(14500L, state.lastPositionMs)
        assertTrue(state.shuffleEnabled)
        assertEquals(1, state.repeatMode)

        assertTrue(store.isNotificationCategoryEnabled(NotificationCategory.WEATHER_ALERTS))
        store.setNotificationCategoryEnabled(NotificationCategory.WEATHER_ALERTS, false)
        assertFalse(store.isNotificationCategoryEnabled(NotificationCategory.WEATHER_ALERTS))
    }
}
