# Keep JavascriptInterface bridge methods for WebView
-keepclassmembers class com.sabarimala.yatraguide.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
